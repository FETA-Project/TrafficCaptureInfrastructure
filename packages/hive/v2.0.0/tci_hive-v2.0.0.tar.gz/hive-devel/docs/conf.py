"""
Configuration file for the Sphinx documentation builder.
All configuration has been moved from this file into the pyproject.toml file for
convenience.
"""

import os
import sys
from sphinx_pyproject import SphinxConfig

sys.path.insert(0, os.path.abspath("../src/hive"))

config = SphinxConfig("../pyproject.toml", globalns=globals())
