#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Configuration module
====================

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Contains all the main configuration options for the web app.
"""

import logging
import os
from logging import FileHandler, StreamHandler, getLogger
from logging.handlers import TimedRotatingFileHandler

import toml

# default toml config file path
_toml_conf_name = "config.toml"  # pylint: disable=invalid-name
_toml_conf_paths = [
    os.path.join(os.path.dirname(__file__), _toml_conf_name),
    os.path.join("/etc/tcigui/", _toml_conf_name),
]

# load the config file (gets the first file that exists)
_toml_conf = {}
for path in _toml_conf_paths:
    try:
        _toml_conf = toml.load(path)
        break
    except FileNotFoundError:
        continue

if not _toml_conf:
    print(f'No configuration file found in "{_toml_conf_paths}"')

# set default values (empty dictionaries)
_conf = {
    "db": _toml_conf.get("db", {}),
    "ldap": _toml_conf.get("ldap", {}),
    "api": _toml_conf.get("api", {}),
    "gui": _toml_conf.get("gui", {}),
    "processing": _toml_conf.get("processing", {}),
    "log": _toml_conf.get("log", {}),
    "tci": _toml_conf.get("tci", {}),
}


def _generate_database_uri(default_uri: str) -> str:
    """Generate an alternative database URI.

    Args:
        default_uri (str): The URI to use if the URI can't be generated.

    Returns:
        A new database URI or the default_uri if a new one can't be generated.
    """
    for key in ["type", "user", "pass", "host", "path", "options"]:
        if key not in _conf["db"]:
            return default_uri

    conf = _conf["db"]

    return (
        f"{conf.get('type')}://{conf.get('user')}:{conf.get('pass')}@"
        f"{conf.get('host')}/{conf.get('path')}?{conf.get('options')}"
    )


class Config:
    """
    The base configuration options of the TCIGUI web application.
    """

    # Basic configuration options for the web application.
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    #: str: The secret key used for hashing and application security.
    SECRET_KEY = _toml_conf.get("secret_key", "hard to guess string")
    JWT_SECRET_KEY = SECRET_KEY
    #: int: API Token expiry time in seconds (defaults to 1 hour).
    API_ACCESS_TOKEN_EXPIRY_TIME = _conf["api"].get(
        "access_token_expiry_time", 3600
    )  # noqa: E501
    #: int: API Refresh Token expiry time in seconds (defaults to 7 days).
    API_REFRESH_TOKEN_EXPIRY_TIME = _conf["api"].get(
        "refresh_token_expiry_time", 604800
    )

    #: str: The IP address of the TCIGUI application.
    HOST = _conf["gui"].get("host", "127.0.0.1")
    #: str: The port on which the app should be launched.
    PORT = _conf["gui"].get("port", 8080)
    #: bool: Whether the application should be threaded.
    THREADED = _conf["gui"].get("threaded", True)
    #: str: Inform the application what host it is bound to. (ie myserver.com)
    SERVER_URL = _conf["gui"].get("url", f"{HOST}:{PORT}")
    #: str: Inform the application what scheme to use. (http or https)
    SERVER_URL_SCHEME = _conf["gui"].get("url_scheme", "http")

    # TCI backend configuration options
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    #: str: The hostname on which the TCI master runs.
    TCI_HOST = _conf["tci"].get("host", "localhost")
    #: str: The port on which the TCI master listens.
    TCI_PORT = _conf["tci"].get("port", 4000)
    #: str: The path to the local certificate.
    TCI_CERT_PATH = _conf["tci"].get("cert_path")
    #: str: The path to the local CA Certificate.
    TCI_CA_CERT_PATH = _conf["tci"].get("ca_cert_path")
    #: bool: Whether to use TLS when connecting to TCI.
    TCI_TLS = _conf["tci"].get("tls", False)

    # Database settings
    # ~~~~~~~~~~~~~~~~~

    #: str: The URI of the database to connect to.
    SQLALCHEMY_DATABASE_URI = _generate_database_uri("sqlite:///")
    #: bool: Track all changes of the database.
    SQLALCHEMY_TRACK_MODIFICATIONS = _conf["db"].get(
        "track_modifications", False
    )  # noqa: E501
    #: bool: Keep track of all the queries made to the database.
    SQLALCHEMY_RECORD_QUERIES = _conf["db"].get("track_record_queries", False)

    # LDAP Settings
    # ~~~~~~~~~~~~~

    #: str: The URI of the LDAP server.
    LDAP_SERVER_URI = _conf["ldap"].get("uri", "ldap://localhost:389")

    """
    PCAP Processing settings
    ~~~~~~~~~~~~~~~~~~~~~~~~
    """
    #: str: The path to the folder where job PCAPs should be saved.
    PCAP_FOLDER = _conf["processing"].get(
        "pcap_folder", os.path.join(os.path.abspath(os.path.dirname(__file__)), "pcaps")
    )
    #: str: The path to the folder where temporary files are stored.
    TMP_FOLDER = _conf["processing"].get(
        "tmp_folder", os.path.join(os.path.abspath(os.path.dirname(__file__)), "tmp")
    )
    #: bool: Whether to use Docker for processing the captured data.
    USE_DOCKER = _conf["processing"].get("use_docker", True)

    # Log settings
    # ~~~~~~~~~~~~

    class UserLogFilter(logging.Filter):
        """Create a logging filter which shows only messages
           containing the specified parameter.

        Using filters with the logging dictConfig is not obvious,
        the official documentation can be found at:
        https://docs.python.org/3/howto/logging-cookbook.html#configuring-filters-with-dictconfig
        """

        def __init__(self, param: str, show: bool) -> None:
            super().__init__()
            self.param = param
            self.show = show

        def filter(self, record: logging.LogRecord) -> bool:
            """Decide whether to show the record or not.

            Args:
                record (logging.LogRecord): The record to filter.

            Returns:
                bool: Whether to show the record or not.
            """
            # If the record level is ERROR or CRITICAL,
            # automatically save the message.
            if record.levelno > 30:  # noqa: PLR2004
                return True
            # Else decide whether to show it based on the show parameter.
            allow = not self.show
            if self.param in record.msg:
                allow = self.show
            return allow

    @staticmethod
    def init_app(_):
        """Initialize the application logging levels."""
        getLogger("werkzeug").setLevel(logging.ERROR)
        getLogger("app").setLevel(logging.INFO)


class DevelopmentConfig(Config):
    """Flask options suitable for development."""

    ENV = "development"

    LOG_FILE_DIR = _conf["log"].get("directory", ".")
    DEFAULT_LOG_NAME = _conf["log"].get("default_name", "tcigui.log")
    __LOG_FILE_BASENAME = f"{LOG_FILE_DIR}/{DEFAULT_LOG_NAME}"

    DEBUG = True

    USE_DOCKER = False

    @classmethod
    def init_app(cls, app):
        super().init_app(app)

        file_handler = FileHandler(filename=cls.__LOG_FILE_BASENAME, mode="a+")
        file_formatter = logging.Formatter("[%(asctime)s] - %(message)s")
        file_filter = cls.UserLogFilter("USER", True)

        file_handler.addFilter(file_filter)
        file_handler.setLevel(logging.INFO)
        file_handler.setFormatter(file_formatter)

        app.logger.addHandler(file_handler)


class TestingConfig(Config):
    """Flask options suitable for testing."""

    ENV = "testing"

    TESTING = True
    WTF_CSFR_ENABLE = False

    LOG_FILE_DIR = _conf["log"].get("directory", ".")
    DEFAULT_LOG_NAME = _conf["log"].get("default_name", "tcigui.log")
    __LOG_FILE_BASENAME = f"{LOG_FILE_DIR}/{DEFAULT_LOG_NAME}"

    USE_DOCKER = False

    SQLALCHEMY_DATABASE_URI = "sqlite:///"

    @classmethod
    def init_app(cls, app):
        super().init_app(app)

        file_handler = FileHandler(filename=cls.__LOG_FILE_BASENAME, mode="a+")
        file_formatter = logging.Formatter("[%(asctime)s] - %(message)s")
        file_filter = cls.UserLogFilter("USER", True)

        file_handler.addFilter(file_filter)
        file_handler.setLevel(logging.INFO)
        file_handler.setFormatter(file_formatter)

        app.logger.addHandler(file_handler)

        # When running automated tests, the StreamHandler gets in the way
        # of the test output.
        for handler in app.logger.handlers:
            if isinstance(handler, StreamHandler):
                app.logger.removeHandler(handler)


class ProductionConfig(Config):
    """Flask options suitable for production deployment."""

    ENV = "production"

    LOG_FILE_DIR = _conf["log"].get("directory", "/var/log/tcigui")
    DEFAULT_LOG_NAME = _conf["log"].get("default_name", "tcigui.log")
    __LOG_FILE_BASENAME = f"{LOG_FILE_DIR}/{DEFAULT_LOG_NAME}"

    @classmethod
    def init_app(cls, app):
        super().init_app(app)

        file_handler = TimedRotatingFileHandler(
            filename=cls.__LOG_FILE_BASENAME, when="W0", backupCount=4
        )

        file_formatter = logging.Formatter("[%(asctime)s] - %(message)s")

        file_filter = cls.UserLogFilter("USER", True)

        file_handler.addFilter(file_filter)
        file_handler.setLevel(logging.INFO)
        file_handler.setFormatter(file_formatter)

        app.logger.addHandler(file_handler)


config = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "testing": TestingConfig,
    "default": DevelopmentConfig,
}
