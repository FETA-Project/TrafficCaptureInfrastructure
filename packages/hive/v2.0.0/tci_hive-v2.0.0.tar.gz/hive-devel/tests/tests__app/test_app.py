#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import unittest

from os import path
from flask import current_app

from app import create_app, db


class BasicTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app("testing")
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.drop_all()
        db.create_all()

    @classmethod
    def tearDownClass(cls) -> None:
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_app_exists(self):
        self.assertTrue(current_app is not None)

    def test_app_is_testing(self):
        self.assertTrue(current_app.config["TESTING"])


class LoggingTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app("testing")
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.create_all()

    @classmethod
    def tearDownClass(cls) -> None:
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_logging_file_exists(self):
        self.app.logger.info("LOGGINGTEST - USER test - foobar")
        self.assertTrue(path.exists(current_app.config["DEFAULT_LOG_NAME"]))

    def test_logging_file_contents(self):
        self.app.logger.info("LOGGINGTEST - USER test - foobar")
        with open(current_app.config["DEFAULT_LOG_NAME"], "r") as logfile:
            logline = logfile.readline()
            self.assertNotEqual(logline, "")
