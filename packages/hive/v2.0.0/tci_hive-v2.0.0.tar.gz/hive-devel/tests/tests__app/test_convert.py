#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from datetime import datetime
import pytz
import unittest
import random

from app.convert import parse_byte_size, parse_duration, set_local_tz


class ConvertTest(unittest.TestCase):
    def test_parse_duration(self):
        days = random.randint(0, 100)
        hours = random.randint(0, 100)
        minutes = random.randint(0, 100)
        seconds = random.randint(0, 100)

        expected_time = seconds + minutes * 60 + hours * 60 * 60 + days * 60 * 60 * 24

        time_string = f"{days}D{hours}H{minutes}M{seconds}S"
        returned_time = parse_duration(time_string)

        self.assertTrue(returned_time[0])
        self.assertEqual(expected_time, returned_time[1])

    def test_parse_duration_float(self):
        time_string = "0.1D"
        returned_time = parse_duration(time_string)
        self.assertFalse(returned_time[0])

    def test_parse_byte_size(self):
        gigabytes = random.randint(0, 100)
        megabytes = random.randint(0, 100)
        kilobytes = random.randint(0, 100)
        bytes = random.randint(0, 100)

        expected_size = (
            bytes + kilobytes * 1000 + megabytes * 1000**2 + gigabytes * 1000**3
        )  # noqa: E501

        size_string = f"{gigabytes}GB{megabytes}MB{kilobytes}KB{bytes}B"
        returned_size = parse_byte_size(size_string)

        self.assertTrue(returned_size[0])
        self.assertEqual(expected_size, returned_size[1])

    def test_parse_byte_size_float(self):
        size_string = "0.1GB"
        returned_size = parse_duration(size_string)
        self.assertFalse(returned_size[0])

    def test_parse_byte_size_negative(self):
        size_string = "-4GB"
        returned_size = parse_duration(size_string)
        self.assertFalse(returned_size[0])

    def test_set_local_tz(self):
        date_format = "%Y-%m-%d %H:%M:%S"
        tz = "Europe/Prague"
        local_tz = pytz.timezone(tz)

        date_now = datetime.utcnow()
        date_local = date_now.astimezone(local_tz).strftime(date_format)

        test_date = set_local_tz(date_now.strftime(date_format), tz)

        self.assertEqual(date_local, test_date)

    def test_set_local_tz_none(self):
        test_date = set_local_tz(None)
        self.assertIsNone(test_date)
