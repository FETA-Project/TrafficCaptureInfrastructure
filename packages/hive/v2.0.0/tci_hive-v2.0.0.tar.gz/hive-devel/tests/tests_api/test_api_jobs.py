#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
from time import sleep
import unittest

from . import get_api_headers
from app import create_app, db
from app.models import AuthorizationLevel, User, Permission, Drone
from werkzeug.security import generate_password_hash

# FIXME: tests should not depend on each other


class JobsTestApi(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app("testing")
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.drop_all()
        db.create_all()

        cls.lvl = AuthorizationLevel(
            level=1, name="admin_level", permissions=int(Permission.SCRIPT_MASTER)
        )
        other_level = AuthorizationLevel(level=2, name="other_level", permissions=0)
        cls.password = "test_password"
        cls.user1 = User(
            username="test_user",
            email="test_user@foo.bar",
            authorization_level=cls.lvl.level,
            password=cls.password,
        )
        cls.user2 = User(
            username="other_test_user",
            email="other_test_user@foo.bar",
            authorization_level=other_level.level,
            password=cls.password,
        )

        drone = Drone(
            name="TestDrone",
            description="TestDrone description",
            token_hash=generate_password_hash("token"),
        )

        db.session.add(cls.lvl)
        db.session.add(other_level)
        db.session.commit()
        db.session.add(cls.user1)
        db.session.add(cls.user2)
        db.session.commit()
        db.session.add(drone)
        db.session.commit()

        cls.client = cls.app.test_client(use_cookies="True")

        response = cls.client.get(
            "/api/v1/token", headers=get_api_headers(cls.user1.username, cls.password)
        )
        cls.user1_token = response.json["access_token"]

        response = cls.client.get(
            "/api/v1/token", headers=get_api_headers(cls.user2.username, cls.password)
        )
        cls.user2_token = response.json["access_token"]

    @classmethod
    def tearDownClass(cls) -> None:
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_01_get_jobs(self):
        response = self.client.get(
            "/api/v1/jobs", headers=get_api_headers(self.user1_token)
        )

        self.assertEqual(response.status_code, 204)

    def test_02_empty_request(self):
        response = self.client.post(
            "/api/v1/jobs", headers=get_api_headers(self.user1_token)
        )

        self.assertEqual(response.status_code, 400)

    def test_03_create_job_wrong_params(self):
        # Missing info
        response = self.client.post(
            "/api/v1/jobs",
            headers=get_api_headers(self.user1_token),
            data=json.dumps({"name": "test_job_name"}),
        )

        self.assertEqual(response.status_code, 400)

        # Wrong keys
        response = self.client.post(
            "/api/v1/jobs",
            headers=get_api_headers(self.user1_token),
            data=json.dumps(
                {
                    "name": "test_job_name",
                    "filter": "filter",
                    "duration": 123,
                    "foobar": "123GB",
                }
            ),
        )

        self.assertEqual(response.status_code, 400)

        # Wrong key values
        response = self.client.post(
            "/api/v1/jobs",
            headers=get_api_headers(self.user1_token),
            data=json.dumps(
                {
                    "name": 123,
                    "filter": 123,
                    "duration": 123,
                    "max_capture_data": "123GB",
                    "script_name": "BLABLA",
                    "script_args": "BLABLA",
                    "drones": ["foobar"],
                }
            ),
        )

        self.assertEqual(response.status_code, 400)

        # Wrong drone
        response = self.client.post(
            "/api/v1/jobs",
            headers=get_api_headers(self.user1_token),
            data=json.dumps(
                {
                    "name": "test_job",
                    "filter": "port 69",
                    "duration": 100,
                    "max_capture_data": 100,
                    "script_name": None,
                    "script_args": None,
                    "drones": ["foobar"],
                }
            ),
        )

        self.assertEqual(response.status_code, 400)

        # No drones
        response = self.client.post(
            "/api/v1/jobs",
            headers=get_api_headers(self.user1_token),
            data=json.dumps(
                {
                    "name": "test_job",
                    "filter": "port 69",
                    "duration": 100,
                    "max_capture_data": 100,
                    "script_name": None,
                    "script_args": None,
                    "drones": [],
                }
            ),
        )

        self.assertEqual(response.status_code, 400)

    def test_04_create_job_correct(self):
        # Getting the drones
        response = self.client.get(
            "/api/v1/drones", headers=get_api_headers(self.user1_token)
        )
        self.assertEqual(response.status_code, 200)
        drone = response.json[0]

        response = self.client.post(
            "/api/v1/jobs",
            headers=get_api_headers(self.user1_token),
            data=json.dumps(
                {
                    "name": "test_job",
                    "filter": "port 69",
                    "duration": 100,
                    "max_capture_data": 100,
                    "script_name": None,
                    "script_args": None,
                    "drones": [drone["name"]],
                }
            ),
        )
        sleep(1)
        self.assertEqual(response.status_code, 200)

    def test_05_get_all_jobs(self):
        response = self.client.get(
            "/api/v1/jobs", headers=get_api_headers(self.user1_token)
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json[0]["name"], "test_job")

    def test_06_get_job_info(self):
        response = self.client.get(
            "/api/v1/jobs/1", headers=get_api_headers(self.user1_token)
        )
        self.assertEqual(response.status_code, 200)

    def test_07_get_job_info_no_auth(self):
        response = self.client.get(
            "/api/v1/jobs/1", headers=get_api_headers(self.user2_token)
        )

        self.assertEqual(response.status_code, 403)

    def test_08_stop_job_incorrect(self):
        # Wrong job
        response = self.client.put(
            "/api/v1/jobs/123",
            headers=get_api_headers(self.user1_token),
        )
        self.assertEqual(response.status_code, 404)

        # Wrong authorization
        response = self.client.put(
            "/api/v1/jobs/1",
            headers=get_api_headers(self.user2_token),
        )
        self.assertEqual(response.status_code, 403)

    def test_09_stop_job_correct(self):
        response = self.client.put(
            "/api/v1/jobs/1",
            headers=get_api_headers(self.user1_token),
        )
        sleep(1)
        self.assertEqual(response.status_code, 204)

    def test_10_process_job_incorrect(self):
        # Wrong ID
        response = self.client.patch(
            "/api/v1/jobs/123", headers=get_api_headers(self.user1_token)
        )
        self.assertEqual(response.status_code, 404)

        # Wrong authorization
        response = self.client.patch(
            "/api/v1/jobs/1", headers=get_api_headers(self.user2_token)
        )
        self.assertEqual(response.status_code, 403)

    def test_98_delete_job_incorrect(self):
        # Wrong job
        response = self.client.delete(
            "/api/v1/jobs/123", headers=get_api_headers(self.user1_token)
        )
        self.assertEqual(response.status_code, 404)

        # No auth
        response = self.client.delete(
            "/api/v1/jobs/1", headers=get_api_headers(self.user2_token)
        )
        self.assertEqual(response.status_code, 403)

    def test_99_delete_job_correct(self):
        response = self.client.delete(
            "/api/v1/jobs/1", headers=get_api_headers(self.user1_token)
        )
        sleep(1)
        self.assertEqual(response.status_code, 204)

    # TODO: test job download
    # TODO: test job process correct
