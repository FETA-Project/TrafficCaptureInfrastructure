#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import unittest

from . import get_api_headers
from app import create_app, db
from app.models import AuthorizationLevel, User


class AuthenticationApiTest(unittest.TestCase):
    """
    Used for testing the authentication capabilities of the API module.
    """

    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app("testing")
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.drop_all()
        db.create_all()

        # Creating a test user and authorization
        auth = AuthorizationLevel(level=1, name="test_level")
        user1 = User(
            username="test_user",
            email="test_user@foo.bar",
            authorization_level=auth.level,
            password="test_password",
        )
        user2 = User(
            username="test_user_2",
            email="test_user_2@foo.bar",
            authorization_level=auth.level,
            password="test_password",
        )
        user3 = User(
            username="test_user_3",
            email="test_user_3@foo.bar",
            authorization_level=auth.level,
            password="test_password",
        )
        db.session.add(auth)
        db.session.commit()
        db.session.add(user1)
        db.session.add(user2)
        db.session.add(user3)
        db.session.commit()

        cls.client = cls.app.test_client()

    @classmethod
    def tearDownClass(cls) -> None:
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_not_logged_in(self):
        response = self.client.get("/api/v1/jobs", content_type="application/json")
        self.assertEqual(response.status_code, 401)

    def test_no_login(self):
        response = self.client.get(
            "/api/v1/token", headers=get_api_headers("", "test_password")
        )
        self.assertEqual(response.status_code, 401)

    def test_no_password(self):
        response = self.client.get(
            "/api/v1/token", headers=get_api_headers("test_user", "")
        )
        self.assertEqual(response.status_code, 401)

    def test_wrong_user_password(self):
        response = self.client.get(
            "/api/v1/token", headers=get_api_headers("test_user", "foobar")
        )
        self.assertEqual(response.status_code, 401)

    def test_wrong_user_name(self):
        response = self.client.get(
            "/api/v1/token", headers=get_api_headers("foobar", "test_password")
        )
        self.assertEqual(response.status_code, 401)

    def test_wrong_token(self):
        response = self.client.get("/api/v1/jobs", headers=get_api_headers("foobar"))
        self.assertEqual(response.status_code, 401)

    def test_empty_token(self):
        response = self.client.get("/api/v1/jobs", headers=get_api_headers(""))
        self.assertEqual(response.status_code, 401)

    def test_get_token(self):
        response = self.client.get(
            "/api/v1/token", headers=get_api_headers("test_user", "test_password")
        )

        self.assertEqual(response.status_code, 200)
        access_token = response.json["access_token"]

        response = self.client.get(
            "/api/v1/jobs", headers=get_api_headers(access_token)
        )

        self.assertEqual(response.status_code, 204)

    def test_token_expiry(self):
        self.app.config["API_ACCESS_TOKEN_EXPIRY_TIME"] = 2

        response = self.client.get(
            "/api/v1/token", headers=get_api_headers("test_user_3", "test_password")
        )

        self.assertEqual(response.status_code, 200)
        access_token = response.json["access_token"]

        response = self.client.get(
            "/api/v1/jobs", headers=get_api_headers(access_token)
        )

        self.assertEqual(response.status_code, 204)
        time.sleep(3)

        response = self.client.get(
            "/api/v1/jobs", headers=get_api_headers(access_token)
        )

        self.assertEqual(response.status_code, 401)

    def test_token_refresh(self):
        self.app.config["API_ACCESS_TOKEN_EXPIRY_TIME"] = 2

        response = self.client.get(
            "/api/v1/token", headers=get_api_headers("test_user_3", "test_password")
        )

        self.assertEqual(response.status_code, 200)
        access_token = response.json["access_token"]
        refresh_token = response.json["refresh_token"]

        time.sleep(3)

        response = self.client.get(
            "/api/v1/jobs", headers=get_api_headers(access_token)
        )

        self.assertEqual(response.status_code, 401)

        response = self.client.post(
            "/api/v1/token", headers=get_api_headers(refresh_token)
        )

        self.assertEqual(response.status_code, 200)

        new_access_token = response.json["access_token"]
        new_refresh_token = response.json["refresh_token"]

        self.assertNotEqual(new_access_token, access_token)
        self.assertNotEqual(new_refresh_token, refresh_token)

        response = self.client.get(
            "/api/v1/jobs", headers=get_api_headers(new_access_token)
        )

        self.assertEqual(response.status_code, 204)

    def test_token_refresh_bad_header(self):
        response = self.client.post("/api/v1/token", headers=get_api_headers(""))

        self.assertEqual(response.status_code, 422)

    def test_token_refresh_access_token_in_header(self):
        response = self.client.get(
            "/api/v1/token", headers=get_api_headers("test_user_3", "test_password")
        )

        access_token = response.json["access_token"]

        response = self.client.post(
            "/api/v1/token", headers=get_api_headers(access_token)
        )

        self.assertEqual(response.status_code, 422)

    def test_using_system_user(self):
        response = self.client.get(
            "/api/v1/token", headers=get_api_headers("System", "systempassword")
        )
        self.assertEqual(response.status_code, 401)

    def test_no_auth_header(self):
        response = self.client.get("/api/v1/token")
        self.assertEqual(response.status_code, 401)
