#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import unittest

from . import get_api_headers
from app import create_app, db
from app.models import AuthorizationLevel, Drone, Permission, User
from werkzeug.security import generate_password_hash


class DronesApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app("testing")
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.drop_all()
        db.create_all()

        # admin user
        cls.auth1 = AuthorizationLevel(
            level=1, name="test_level_1", permissions=Permission.ADMIN
        )
        cls.user1 = User(
            username="test_user_1",
            email="test_user@foo.bar",
            authorization_level=cls.auth1.level,
            password="test_password",
        )

        # not admin user
        cls.auth2 = AuthorizationLevel(level=2, name="test_level_2", permissions=0)
        cls.user2 = User(
            username="test_user_2",
            email="test_user2@foo.bar",
            authorization_level=cls.auth2.level,
            password="test_password",
        )

        cls.test_drone = Drone(
            name="TestDrone",
            description="TestDrone description",
            token_hash=generate_password_hash("token"),
        )

        db.session.add(cls.auth1)
        db.session.add(cls.auth2)
        db.session.commit()
        db.session.add(cls.user1)
        db.session.add(cls.user2)
        db.session.commit()
        db.session.add(cls.test_drone)
        db.session.commit()

        cls.client = cls.app.test_client(use_cookies="True")

        response = cls.client.get(
            "/api/v1/token",
            headers=get_api_headers(cls.user1.username, "test_password"),
        )
        cls.user1_token = response.json["access_token"]

        response = cls.client.get(
            "/api/v1/token",
            headers=get_api_headers(cls.user2.username, "test_password"),
        )
        cls.user2_token = response.json["access_token"]

    @classmethod
    def tearDownClass(cls) -> None:
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_01_create_drone(self):
        # Creating a drone with admin user
        response = self.client.post(
            "/api/v1/drones",
            headers=get_api_headers(self.user1_token),
            data=json.dumps({"name": "Drone1", "description": "Drone1 Description"}),
        )
        self.assertEqual(response.status_code, 200)
        self.assertDictContainsSubset(
            {
                "name": "Drone1",
                "description": "Drone1 Description",
                "status": "Pending",
                "capture_backend": "unknown",
            },
            response.json,
        )
        self.assertIn("token", response.json.keys())

    def test_02_create_drone_other_user(self):
        # Creating a drone with basic user
        response = self.client.post(
            "/api/v1/drones",
            headers=get_api_headers(self.user2_token),
            data=json.dumps({"name": "Drone2", "description": "Drone2 Description"}),
        )
        self.assertEqual(response.status_code, 403)

    def test_03_get_drones(self):
        # Get all drones
        response = self.client.get(
            "/api/v1/drones", headers=get_api_headers(self.user1_token)
        )
        self.assertEqual(response.status_code, 200)

        # Testing the contents of the response
        __expected_response = [drone.to_dict() for drone in Drone.query.all()]
        for drone in __expected_response:
            drone["status"] = drone["status"].value
            drone["capture_backend"] = drone["capture_backend"].value
            drone["jobs"] = []

        for drone in response.json:
            self.assertIn(drone, __expected_response)

    def test_04_generate_new_token(self):
        # Wrong drone name
        response = self.client.put(
            "/api/v1/drones/foobar", headers=get_api_headers(self.user1_token)
        )
        self.assertEqual(response.status_code, 404)

        # Correct drone name
        response = self.client.put(
            f"/api/v1/drones/{self.test_drone.name}",
            headers=get_api_headers(self.user1_token),
        )
        self.assertEqual(response.status_code, 200)
        self.assertTrue("token" in response.json.keys())

    def test_05_change_color(self):
        # Wrong permissions
        response = self.client.patch(
            f"/api/v1/drones/{self.test_drone.name}",
            data=json.dumps({"color": "#000000"}),
            headers=get_api_headers(self.user2_token),
        )
        self.assertEqual(response.status_code, 403)

        # wrong color
        response = self.client.patch(
            f"/api/v1/drones/{self.test_drone.name}",
            data=json.dumps({"color": "wrong_color"}),
            headers=get_api_headers(self.user1_token),
        )
        self.assertEqual(response.status_code, 400)

        # color not in rgb
        response = self.client.patch(
            f"/api/v1/drones/{self.test_drone.name}",
            data=json.dumps({"color": "#qqqppp"}),
            headers=get_api_headers(self.user1_token),
        )
        self.assertEqual(response.status_code, 400)

        # non existent drone
        response = self.client.patch(
            "/api/v1/drones/Drone_not_found",
            data=json.dumps({"color": "#000000"}),
            headers=get_api_headers(self.user1_token),
        )
        self.assertEqual(response.status_code, 400)

        # correct color
        response = self.client.get(
            f"/api/v1/drones/{self.test_drone.name}",
            headers=get_api_headers(self.user1_token),
        )

        _color = response.json["color"]
        _new_color = _color
        while _new_color == _color:
            _new_color = Drone.generate_color()

        response = self.client.patch(
            f"/api/v1/drones/{self.test_drone.name}",
            data=json.dumps({"color": _new_color}),
            headers=get_api_headers(self.user1_token),
        )

        self.assertNotEqual(response.json["color"], _color)

    def test_06_generate_new_token_other_user(self):
        response = self.client.put(
            f"/api/v1/drones/{self.test_drone.name}",
            headers=get_api_headers(self.user2_token),
        )
        self.assertEqual(response.status_code, 403)

    def test_07_delete_drone_other_user(self):
        response = self.client.delete(
            f"/api/v1/drones/{self.test_drone.name}",
            headers=get_api_headers(self.user2_token),
        )
        self.assertEqual(response.status_code, 403)

    def test_08_delete_drone(self):
        # Wrong drone name
        response = self.client.delete(
            "/api/v1/drones/foobar", headers=get_api_headers(self.user1_token)
        )
        self.assertEqual(response.status_code, 404)

        # Correct drone name
        response = self.client.delete(
            f"/api/v1/drones/{self.test_drone.name}",
            headers=get_api_headers(self.user1_token),
        )
        self.assertEqual(response.status_code, 204)

        # Checking that no drones exist
        response = self.client.get(
            "/api/v1/drones", headers=get_api_headers(self.user1_token)
        )
        self.assertEqual(response.status_code, 200)
        self.assertNotIn(self.test_drone, response.json)
