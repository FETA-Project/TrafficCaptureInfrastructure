#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import unittest

from . import get_api_headers
from app import create_app, db
from app.models import AuthorizationLevel, Application, User


class ApplicationsApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app("testing")
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.drop_all()
        db.create_all()

        cls.password = "test_password"

        cls.auth = AuthorizationLevel.create(level=1, name="test_level", permissions=0)

        cls.user1 = User.create(
            username="test_user",
            email="test_user@foo.bar",
            authorization_level=cls.auth.level,
            password=cls.password,
        )

        cls.user2 = User.create(
            username="test_user2",
            email="test_user2@foo.bar",
            authorization_level=cls.auth.level,
            password=cls.password,
        )

        cls.user_app, _ = Application.create(name="test_app", owner=cls.user1.username)

        cls.user_app_regen, cls.user_app_regen_token = Application.create(
            name="regen_app", owner=cls.user1.username
        )

        cls.user_app_delete, _ = Application.create(
            name="delete_app", owner=cls.user1.username
        )

        cls.client = cls.app.test_client(use_cookies="True")
        response = cls.client.get(
            "/api/v1/token", headers=get_api_headers(cls.user1.username, cls.password)
        )
        cls.user1_token = response.json["access_token"]

        response = cls.client.get(
            "/api/v1/token", headers=get_api_headers(cls.user2.username, cls.password)
        )
        cls.user2_token = response.json["access_token"]

    @classmethod
    def tearDownClass(cls) -> None:
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_get_application_overview(self):
        # Test that the user can get the overview of all their applications.
        response = self.client.get(
            "/api/v1/applications", headers=get_api_headers(self.user1_token)
        )
        self.assertEqual(response.status_code, 200)

        __expected_response = [
            app.to_dict()
            for app in Application.query.filter_by(owner=self.user1.username).all()
        ]
        self.assertEqual(response.json, __expected_response)
        self.assertNotIn("token", response.json[0])

        # Test that the user cannot see other users applications
        response = self.client.get(
            "/api/v1/applications", headers=get_api_headers(self.user2_token)
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json, [])

    def test_create_application(self):
        response = self.client.post(
            "/api/v1/applications",
            headers=get_api_headers(self.user1_token),
            data=json.dumps(
                {
                    "name": "test_app2",
                }
            ),
        )
        self.assertEqual(response.status_code, 200)

        self.assertEqual(response.json["name"], "test_app2")
        self.assertEqual(response.json["owner"], self.user1.username)
        self.assertIn("token", response.json)
        _token = response.json["token"]

        response = self.client.get(
            "/api/v1/applications", headers=get_api_headers(_token)
        )
        self.assertEqual(response.status_code, 200)

    def test_create_application_other_user(self):
        # Cannot create for other user
        response = self.client.post(
            "/api/v1/applications",
            headers=get_api_headers(self.user1_token),
            data=json.dumps({"name": "test_app1234", "owner": self.user2.username}),
        )
        # check that the created app is owned by user initiating the request
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["owner"], self.user1.username)

    def create_application_no_name(self):
        # No name
        response = self.client.post(
            "/api/v1/applications",
            headers=get_api_headers(self.user1_token),
            data=json.dumps({}),
        )
        self.assertEqual(response.status_code, 400)

    def create_application_with_token(self):
        # Cannot create with token
        response = self.client.post(
            "/api/v1/applications",
            headers=get_api_headers(self.user1_token),
            data=json.dumps({"name": "test_app1234", "token": "test_token"}),
        )
        self.assertEqual(response.status_code, 200)
        self.assertNotEqual(response.json["token"], "test_token")

    def test_regenerate_token(self):
        # token works
        response = self.client.get(
            "/api/v1/applications", headers=get_api_headers(self.user_app_regen_token)
        )
        self.assertEqual(response.status_code, 200)

        # regenerate token
        response = self.client.put(
            f"/api/v1/applications/{self.user_app_regen.id}",
            headers=get_api_headers(self.user_app_regen_token),
        )
        # new token is different
        _new_token = response.json["token"]
        self.assertNotEqual(_new_token, self.user_app_regen_token)

        # old token is no longer valid
        response = self.client.get(
            "/api/v1/applications", headers=get_api_headers(self.user_app_regen_token)
        )
        self.assertEqual(response.status_code, 401)

        # new token works
        response = self.client.get(
            "/api/v1/applications", headers=get_api_headers(_new_token)
        )
        self.assertEqual(response.status_code, 200)

    def test_regenerate_token_non_existent_app(self):
        response = self.client.put(
            "/api/v1/applications/non_existent_app",
            headers=get_api_headers(self.user1_token),
        )
        self.assertEqual(response.status_code, 404)

    def test_regenerate_token_for_other_user(self):
        response = self.client.put(
            f"/api/v1/applications/{self.user_app_regen.id}",
            headers=get_api_headers(self.user2_token),
        )
        self.assertEqual(response.status_code, 403)

    def test_delete_application(self):
        response = self.client.delete(
            f"/api/v1/applications/{self.user_app_delete.id}",
            headers=get_api_headers(self.user1_token),
        )
        self.assertEqual(response.status_code, 204)

        self.assertNotIn(self.user_app_delete, Application.query.all())

    def test_delete_nonexistent_app(self):
        response = self.client.delete(
            "/api/v1/applications/non_existent_app",
            headers=get_api_headers(self.user1_token),
        )
        self.assertEqual(response.status_code, 404)

    def test_delete_app_for_other_user(self):
        response = self.client.delete(
            f"/api/v1/applications/{self.user_app_delete.id}",
            headers=get_api_headers(self.user2_token),
        )
        self.assertEqual(response.status_code, 403)
