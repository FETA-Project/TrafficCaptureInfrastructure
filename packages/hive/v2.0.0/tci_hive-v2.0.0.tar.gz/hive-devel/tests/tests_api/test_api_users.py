#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import unittest

from . import get_api_headers
from app import create_app, db
from app.models import AuthorizationLevel, User, Permission


class UsersApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app("testing")
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.drop_all()
        db.create_all()

        cls.password = "test_password"
        cls.auth1 = AuthorizationLevel(level=10, name="test_level_1", permissions=0)
        cls.auth2 = AuthorizationLevel(
            level=2, name="test_level_2", permissions=int(Permission.MODIFY_USERS)
        )
        cls.auth3 = AuthorizationLevel(level=1, name="test_level_3", permissions=0)
        cls.user1 = User(
            username="test_user_1",
            email="test_user_1@foo.bar",
            authorization_level=cls.auth1.level,
            password=cls.password,
        )
        cls.user2 = User(
            username="test_user_2",
            email="test_user_2@foo.bar",
            authorization_level=cls.auth2.level,
            password=cls.password,
        )
        cls.user3 = User(
            username="test_user_3",
            email="test_user_3@foo.bar",
            authorization_level=cls.auth3.level,
            password=cls.password,
        )
        cls.user_to_edit = User(
            username="test_user_to_edit",
            email="user_to_edit@foo.bar",
            authorization_level=cls.auth1.level,
            password=cls.password,
        )
        cls.user_to_delete = User(
            username="test_user_to_delete",
            email="user_to_delete@foo.bar",
            authorization_level=cls.auth1.level,
            password=cls.password,
        )

        db.session.add(cls.auth1)
        db.session.add(cls.auth2)
        db.session.add(cls.auth3)
        db.session.commit()
        db.session.add(cls.user1)
        db.session.add(cls.user2)
        db.session.add(cls.user3)
        db.session.add(cls.user_to_edit)
        db.session.add(cls.user_to_delete)
        db.session.commit()

        cls.client = cls.app.test_client(use_cookies="True")

        response = cls.client.get(
            "/api/v1/token", headers=get_api_headers(cls.user1.username, cls.password)
        )
        cls.user1_token = response.json["access_token"]

        response = cls.client.get(
            "/api/v1/token", headers=get_api_headers(cls.user2.username, cls.password)
        )
        cls.user2_token = response.json["access_token"]

    @classmethod
    def tearDownClass(cls) -> None:
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_get_users(self):
        response = self.client.get(
            "/api/v1/users", headers=get_api_headers(self.user1_token)
        )
        self.assertEqual(response.status_code, 200)

    def test_get_unauthorized_user(self):
        response = self.client.get(
            f"/api/v1/users/{self.user2.username}",
            headers=get_api_headers(self.user1_token),
        )
        self.assertEqual(response.status_code, 403)

    def test_get_nonexistent_user(self):
        response = self.client.get(
            "/api/v1/users/foobar", headers=get_api_headers(self.user1_token)
        )
        self.assertEqual(response.status_code, 404)

    def test_get_correct_user(self):
        response = self.client.get(
            f"/api/v1/users/{self.user1.username}",
            headers=get_api_headers(self.user1_token),
        )
        self.assertEqual(response.status_code, 200)

    def test_create_user_correct(self):
        response = self.client.post(
            "/api/v1/users",
            headers=get_api_headers(self.user2_token),
            data=json.dumps(
                {
                    "username": "new_user",
                    "email": "new.user@foo.bar",
                    "authorization_level": self.user2.authorization_level,
                    "password": "longpassword",
                }
            ),
        )
        self.assertEqual(response.status_code, 200)

    def test_create_user_incorrect(self):
        # Repeated username/email
        response = self.client.post(
            "/api/v1/users",
            headers=get_api_headers(self.user2_token),
            data=json.dumps(
                {
                    "username": "test_user_2",
                    "email": "new.user@foo.bar",
                    "authorization_level": self.user2.authorization_level,
                    "password": "foobar",
                }
            ),
        )
        self.assertEqual(response.status_code, 400)

        # No privileges
        response = self.client.post(
            "/api/v1/users",
            headers=get_api_headers(self.user1_token),
            data=json.dumps(
                {
                    "username": "new_user",
                    "email": "new.user@foo.bar",
                    "authorization_level": 20,
                    "password": "foobar",
                }
            ),
        )
        self.assertEqual(response.status_code, 403)

        # higher level
        response = self.client.post(
            "/api/v1/users",
            headers=get_api_headers(self.user2_token),
            data=json.dumps(
                {
                    "username": "new_user123",
                    "email": "new_user123@foo.bar",
                    "authorization_level": 1,
                    "password": "foobar",
                }
            ),
        )
        self.assertEqual(response.status_code, 403)

    def test_edit_user_correct(self):
        response = self.client.put(
            f"/api/v1/users/{self.user_to_edit.username}",
            headers=get_api_headers(self.user2_token),
            data=json.dumps({"password": self.password}),
        )
        self.assertEqual(response.status_code, 200)

    def test_edit_user_incorrect(self):
        # Wrong permissions
        response = self.client.put(
            f"/api/v1/users/{self.user2.username}",
            headers=get_api_headers(self.user1_token),
            data=json.dumps({"email": "foobaremail@email.foo"}),
        )
        self.assertEqual(response.status_code, 403)

        # Non existent user
        response = self.client.put(
            "/api/v1/users/foobar",
            headers=get_api_headers(self.user2_token),
            data=json.dumps({"email": "new_mail@email.bar"}),
        )
        self.assertEqual(response.status_code, 400)

        # Higher level
        response = self.client.put(
            f"/api/v1/users/{self.user3.username}",
            headers=get_api_headers(self.user2_token),
            data=json.dumps({"email": "random@mail.foo"}),
        )
        self.assertEqual(response.status_code, 403)

        # Email exists
        response = self.client.put(
            f"/api/v1/users/{self.user1.username}",
            headers=get_api_headers(self.user2_token),
            data=json.dumps({"email": self.user2.email}),
        )
        self.assertEqual(response.status_code, 400)

    def test_delete_user_correct(self):
        response = self.client.delete(
            f"/api/v1/users/{self.user_to_delete.username}",
            headers=get_api_headers(self.user2_token),
        )
        self.assertEqual(response.status_code, 204)

    def test_delete_user_incorrect(self):
        # No authorization
        response = self.client.delete(
            f"/api/v1/users/{self.user2.username}",
            headers=get_api_headers(self.user1_token),
        )
        self.assertEqual(response.status_code, 403)

        # Deleting yourself
        response = self.client.delete(
            f"/api/v1/users/{self.user2.username}",
            headers=get_api_headers(self.user2_token),
        )
        self.assertEqual(response.status_code, 400)

        # Deleting nonexistent user
        response = self.client.delete(
            "/api/v1/users/foobar", headers=get_api_headers(self.user2_token)
        )
        self.assertEqual(response.status_code, 400)

        # Deleting user with higher level
        response = self.client.delete(
            f"/api/v1/users/{self.user3.username}",
            headers=get_api_headers(self.user2_token),
        )
        self.assertEqual(response.status_code, 403)
