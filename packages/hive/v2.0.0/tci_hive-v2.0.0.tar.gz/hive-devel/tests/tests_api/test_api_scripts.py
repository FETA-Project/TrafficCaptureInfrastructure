#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import unittest

from base64 import b64encode

from . import get_api_headers
from app import create_app, db
from app.models import AuthorizationLevel, Permission, User, ScriptType, Script


class ScriptApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app("testing")
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.drop_all()
        db.create_all()

        cls.test_script_content = b64encode(
            "#!/bin/sh\necho test".encode("utf-8")
        ).decode("utf-8")

        cls.password = "test_password"
        cls.auth1 = AuthorizationLevel(level=10, name="test_level_1", permissions=0)
        cls.auth2 = AuthorizationLevel(
            level=5, name="test_level_2", permissions=int(Permission.SCRIPT_MASTER)
        )
        cls.user1 = User(
            username="test_user_1",
            email="test_user_1@foo.bar",
            authorization_level=cls.auth1.level,
            password=cls.password,
        )
        cls.user2 = User(
            username="test_user_2",
            email="test_user_2@foo.bar",
            authorization_level=cls.auth2.level,
            password=cls.password,
        )

        cls.script_to_delete = Script(
            name="ScriptToDelete",
            authorization_level=cls.auth1.level,
            file_contents=cls.test_script_content.encode("utf-8"),
        )

        db.session.add(cls.auth1)
        db.session.add(cls.auth2)
        db.session.commit()
        db.session.add(cls.user1)
        db.session.add(cls.user2)
        db.session.commit()
        db.session.add(cls.script_to_delete)
        db.session.commit()

        cls.client = cls.app.test_client(use_cookies="True")

        response = cls.client.get(
            "/api/v1/token", headers=get_api_headers(cls.user1.username, cls.password)
        )
        cls.user1_token = response.json["access_token"]

        response = cls.client.get(
            "/api/v1/token", headers=get_api_headers(cls.user2.username, cls.password)
        )
        cls.user2_token = response.json["access_token"]

    @classmethod
    def tearDownClass(cls) -> None:
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_create_script_correct(self):
        new_script_dict = {
            "name": "TestScript",
            "authorization_level": self.auth1.level,
            "file_contents": self.test_script_content,
        }

        response = self.client.post(
            "/api/v1/scripts",
            headers=get_api_headers(self.user2_token),
            data=json.dumps(new_script_dict),
        )

        new_script_dict["filetype"] = str(ScriptType.SHELL)
        new_script_dict["description"] = None

        self.assertEqual(response.status_code, 200)
        self.assertDictEqual(new_script_dict, response.json)

        response = self.client.get(
            "/api/v1/scripts/TestScript", headers=get_api_headers(self.user2_token)
        )
        self.assertEqual(response.status_code, 200)
        self.assertDictEqual(new_script_dict, response.json)

    def test_create_script_incorrect(self):
        # Wrong file type
        response = self.client.post(
            "/api/v1/scripts",
            headers=get_api_headers(self.user2_token),
            data=json.dumps(
                {
                    "name": "NewScript",
                    "authorization_level": self.auth1.level,
                    "file_contents": b64encode(
                        "some random text".encode("utf-8")
                    ).decode("utf-8"),
                }
            ),
        )
        self.assertEqual(response.status_code, 400)

        # Not enough privileges
        response = self.client.post(
            "/api/v1/scripts",
            headers=get_api_headers(self.user1_token),
            data=json.dumps(
                {
                    "name": "NewScript",
                    "authorization_level": self.auth1.level,
                    "file_contents": self.test_script_content,
                }
            ),
        )
        self.assertEqual(response.status_code, 403)

        # Wrong JSON format
        response = self.client.post(
            "/api/v1/scripts",
            headers=get_api_headers(self.user2_token),
            data=json.dumps(
                {
                    "name": "NewScript",
                    "authorization_level": "test",
                    "file_contents": self.test_script_content,
                }
            ),
        )
        self.assertEqual(response.status_code, 400)

        # FIXME: for some reason this works, script name is too long
        # but the script is created.
        # When using the API (with curl) it works fine
        # (throws error on long name).
        # Long Name
        # response = self.client.post(
        #     '/api/v1/scripts',
        #     headers=get_api_headers(self.user2_token),
        #     data=json.dumps({
        #         "name": "123456789012345678901",
        #         "authorization_level": self.auth1.level,
        #         "file_contents": self.test_script_content
        #     })
        # )
        # self.assertEqual(response.status_code, 400)

    def test_getting_script_incorrect(self):
        # Wrong name
        response = self.client.get(
            "/api/v1/scripts/FooBar", headers=get_api_headers(self.user2_token)
        )
        self.assertEqual(response.status_code, 400)

    def test_04_getting_all_scripts(self):
        response = self.client.get(
            "/api/v1/scripts", headers=get_api_headers(self.user2_token)
        )
        self.assertTrue(response.status_code, 200)

    def test_delete_script_incorrect(self):
        # Name doesn't exist
        response = self.client.delete(
            "/api/v1/scripts/foobar", headers=get_api_headers(self.user2_token)
        )
        self.assertTrue(response.status_code, 400)
        # No privileges
        response = self.client.delete(
            "/api/v1/scripts/ScriptToDelete", headers=get_api_headers(self.user1_token)
        )
        self.assertTrue(response.status_code, 403)

    def test_delete_script_correct(self):
        response = self.client.delete(
            "/api/v1/scripts/ScriptToDelete", headers=get_api_headers(self.user2_token)
        )
        self.assertTrue(response.status_code, 204)

    # TODO: test download script
