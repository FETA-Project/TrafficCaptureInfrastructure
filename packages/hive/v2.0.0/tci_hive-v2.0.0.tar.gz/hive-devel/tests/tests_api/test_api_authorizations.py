#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import unittest

from . import get_api_headers
from app import create_app, db
from app.models import AuthorizationLevel, Permission, User


class AuthorizationsApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app("testing")
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.drop_all()
        db.create_all()

        # Creating a test user and authorization without sufficient rights
        cls.password = "test_password"
        cls.auth1 = AuthorizationLevel(level=1, name="test_level_1", permissions=0)
        cls.user1 = User(
            username="test_user_1",
            email="test_user@foo.bar",
            authorization_level=cls.auth1.level,
            password=cls.password,
        )

        # Creating a test user and authorization with sufficient rights
        cls.auth2 = AuthorizationLevel(level=20, name="test_level_2", permissions=2)
        cls.user2 = User(
            username="test_user_2",
            email="test_user@bar.foo",
            authorization_level=cls.auth2.level,
            password=cls.password,
        )

        cls.auth_to_change = AuthorizationLevel(
            level=30, name="test_level_to_change", permissions=7
        )
        cls.auth_to_delete = AuthorizationLevel(
            level=99, name="test_level_to_delete", permissions=0
        )

        db.session.add(cls.auth1)
        db.session.add(cls.auth2)
        db.session.add(cls.auth_to_delete)
        db.session.add(cls.auth_to_change)
        db.session.commit()
        db.session.add(cls.user1)
        db.session.add(cls.user2)
        db.session.commit()

        cls.client = cls.app.test_client(use_cookies="True")

        response = cls.client.get(
            "/api/v1/token", headers=get_api_headers(cls.user1.username, cls.password)
        )
        cls.user1_token = response.json["access_token"]

        response = cls.client.get(
            "/api/v1/token", headers=get_api_headers(cls.user2.username, cls.password)
        )
        cls.user2_token = response.json["access_token"]

    @classmethod
    def tearDownClass(cls) -> None:
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_get_authorization_overview(self):
        # Getting the response
        response = self.client.get(
            "/api/v1/authorizations", headers=get_api_headers(self.user1_token)
        )
        self.assertEqual(response.status_code, 200)

        # Testing the contents of the response
        __expected_response = [
            auth.to_dict() for auth in AuthorizationLevel.query.all()
        ]
        self.assertEqual(response.json, __expected_response)

    def test_create_authorization(self):
        __new_auth = {"level": 123, "name": "test_auth_123", "permissions": 0}
        response = self.client.post(
            "/api/v1/authorizations",
            headers=get_api_headers(self.user2_token),
            data=json.dumps(__new_auth),
        )
        self.assertEqual(response.status_code, 200)

    def test_create_authorization_with_no_params(self):
        response = self.client.post(
            "/api/v1/authorizations", headers=get_api_headers(self.user2_token)
        )
        self.assertEqual(response.status_code, 400)

    def test_create_authorization_with_wrong_params(self):
        # Getting the current levels
        lvls = self.client.get(
            "/api/v1/authorizations", headers=get_api_headers(self.user1_token)
        )

        # Incorrect level
        response = self.client.post(
            "/api/v1/authorizations",
            headers=get_api_headers(self.user2_token),
            data=json.dumps(
                {
                    "level": self.user2.authorization_level + 0.1,
                    "name": "name",
                    "permission": 0,
                }
            ),
        )
        self.assertEqual(response.status_code, 400)

        # Incorrect name
        response = self.client.post(
            "/api/v1/authorizations",
            headers=get_api_headers(self.user2_token),
            data=json.dumps(
                {
                    "level": 5,
                    "name": "very long random name that doesn't fit",
                    "permission": 0,
                }
            ),
        )
        self.assertEqual(response.status_code, 400)

        # Incorrect permission
        response = self.client.post(
            "/api/v1/authorizations",
            headers=get_api_headers(self.user2_token),
            data=json.dumps({"level": 5, "name": "name", "permission": "test"}),
        )
        self.assertEqual(response.status_code, 400)

        # TODO: Test unusual characters in parameters.

        response = self.client.get(
            "/api/v1/authorizations", headers=get_api_headers(self.user2_token)
        )
        self.assertEqual(response.json, lvls.json)

    def test_create_auth_with_existing_params(self):
        # existing level
        response = self.client.post(
            "/api/v1/authorizations",
            headers=get_api_headers(self.user2_token),
            data=json.dumps(
                {
                    "level": self.auth_to_delete.level,
                    "name": "super_new_random_name",
                    "permission": 0,
                }
            ),
        )
        self.assertEqual(response.status_code, 400)

        # existing name
        response = self.client.post(
            "/api/v1/authorizations",
            headers=get_api_headers(self.user2_token),
            data=json.dumps({"level": 500, "name": self.auth1.name, "permission": 0}),
        )
        self.assertEqual(response.status_code, 400)

    def test_create_auth_insufficient_permissions(self):
        # Higher level then the current user
        response = self.client.post(
            "/api/v1/authorizations",
            headers=get_api_headers(self.user2_token),
            data=json.dumps({"level": 10, "name": "test_level_10", "permissions": 0}),
        )
        self.assertEqual(response.status_code, 403)

    def test_edit_auth(self):
        # edit name
        response = self.client.put(
            "/api/v1/authorizations/30",
            headers=get_api_headers(self.user2_token),
            data=json.dumps({"name": "new_name"}),
        )
        _expected_auth = {
            "level": self.auth_to_change.level,
            "name": "new_name",
            "permissions": self.auth_to_change.permissions,
        }
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json, _expected_auth)

        # edit permissions
        response = self.client.put(
            "/api/v1/authorizations/30",
            headers=get_api_headers(self.user2_token),
            data=json.dumps({"permissions": 2}),
        )
        _expected_auth = {
            "level": self.auth_to_change.level,
            "name": "new_name",
            "permissions": 2,
        }
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json, _expected_auth)

    def test_edit_auth_higher_level(self):
        response = self.client.put(
            "/api/v1/authorizations/1",
            headers=get_api_headers(self.user2_token),
            data=json.dumps({"name": "new_name_wrong_perms"}),
        )
        self.assertEqual(response.status_code, 403)

    def test_edit_auth_with_wrong_perms(self):
        response = self.client.put(
            "/api/v1/authorizations/30",
            headers=get_api_headers(self.user2_token),
            data=json.dumps({"permissions": 8}),
        )
        self.assertEqual(response.status_code, 403)

    def test_edit_auth_existing_name(self):
        response = self.client.put(
            "/api/v1/authorizations/30",
            headers=get_api_headers(self.user2_token),
            data=json.dumps({"name": self.auth1.name}),
        )
        self.assertEqual(response.status_code, 400)

    def test_wrong_path(self):
        response = self.client.put(
            "/api/v1/authorizations/wrong",
            headers=get_api_headers(self.user2_token),
            data=json.dumps({"name": "new_name"}),
        )
        self.assertEqual(response.status_code, 404)

    def test_edit_primary_key(self):
        lvls = self.client.get(
            "/api/v1/authorizations", headers=get_api_headers(self.user2_token)
        )

        response = self.client.put(
            "/api/v1/authorizations/1",
            headers=get_api_headers(self.user2_token),
            data=json.dumps({"level": 123}),
        )
        self.assertEqual(response.status_code, 400)

        response = self.client.get(
            "/api/v1/authorizations", headers=get_api_headers(self.user2_token)
        )
        self.assertEqual(response.json, lvls.json)

    def test_get_authorization_info(self):
        response = self.client.get(
            "/api/v1/authorizations/1", headers=get_api_headers(self.user2_token)
        )
        self.assertEqual(response.status_code, 200)

        __expected_response = self.auth1.to_dict()
        self.assertEqual(response.json, __expected_response)

    def test_get_wrong_authorization_info(self):
        response = self.client.get(
            "/api/v1/authorizations/wrong", headers=get_api_headers(self.user2_token)
        )
        self.assertEqual(response.status_code, 404)

    def test_get_permissions(self):
        response = self.client.get(
            "/api/v1/authorizations/permissions",
            headers=get_api_headers(self.user2_token),
        )
        self.assertEqual(response.status_code, 200)

        __expected_response = [  # all permissions without admin
            {"name": perm.name, "value": int(perm)}
            for perm in Permission
            if perm != Permission.ADMIN
        ]
        self.assertEqual(response.json, __expected_response)

    def test_delete_authorization(self):
        response = self.client.delete(
            "/api/v1/authorizations/99", headers=get_api_headers(self.user2_token)
        )
        self.assertEqual(response.status_code, 204)

        response = self.client.get(
            "/api/v1/authorizations", headers=get_api_headers(self.user2_token)
        )
        self.assertNotIn(self.auth_to_delete, response.json)

    def test_delete_authorization_wrong_permissions(self):
        response = self.client.delete(
            "/api/v1/authorizations/1", headers=get_api_headers(self.user1_token)
        )
        self.assertEqual(response.status_code, 403)

    def test_delete_authorization_higher_level(self):
        response = self.client.delete(
            "/api/v1/authorizations/2", headers=get_api_headers(self.user2_token)
        )
        self.assertEqual(response.status_code, 403)

    def test_delete_wrong_authorization(self):
        response = self.client.delete(
            "/api/v1/authorizations/42", headers=get_api_headers(self.user2_token)
        )
        self.assertEqual(response.status_code, 400)
