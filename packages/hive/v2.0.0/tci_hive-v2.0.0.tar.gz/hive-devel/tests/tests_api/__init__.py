#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from base64 import b64encode


def get_api_headers(username, password=None):
    headers = {"Accept": "application/json", "Content-Type": "application/json"}

    if password is None:
        headers["Authorization"] = "Bearer " + username
    else:
        headers["Authorization"] = "Basic " + b64encode(
            (username + ":" + password).encode("utf-8")
        ).decode("utf-8")

    return headers
