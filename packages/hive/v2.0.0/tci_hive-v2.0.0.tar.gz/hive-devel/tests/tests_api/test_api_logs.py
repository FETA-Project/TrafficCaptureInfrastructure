#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import unittest

from . import get_api_headers
from app import create_app, db
from app.models import AuthorizationLevel, User


class LogApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app("testing")
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.drop_all()
        db.create_all()

        cls.password = "test_password"
        cls.auth = AuthorizationLevel(level=10, name="test_level", permissions=0)
        cls.user = User(
            username="test_user",
            email="test_user@foo.bar",
            authorization_level=cls.auth.level,
            password=cls.password,
        )

        db.session.add(cls.auth)
        db.session.commit()
        db.session.add(cls.user)
        db.session.commit()

        cls.client = cls.app.test_client(use_cookies="True")

        response = cls.client.get(
            "/api/v1/token", headers=get_api_headers(cls.user.username, cls.password)
        )
        cls.user_token = response.json["access_token"]

    @classmethod
    def tearDownClass(cls) -> None:
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_get_logs(self):
        response = self.client.get(
            "/api/v1/logs",
            headers=get_api_headers(self.user_token),
        )

        self.assertEqual(response.status_code, 200)

    # TODO: test log download
