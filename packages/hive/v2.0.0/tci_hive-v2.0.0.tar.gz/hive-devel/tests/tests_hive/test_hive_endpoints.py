#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import unittest

from app import create_app, db, sio
from app.models import Drone, DroneStatus, DroneCaptureBackend


class HiveEndpointsTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app("testing")
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.drop_all()
        db.create_all()

        _, cls.token = Drone.create(name="test_drone", description="test_description")
        cls.client = sio.test_client(
            app=cls.app,
            auth={"token": cls.token},
            flask_test_client=cls.app.test_client(),
        )

        cls.client.connect()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.client.disconnect()
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_01_drone_invalid_init(self):
        self.client.emit("drone_init", "invalid_backend")
        drone = Drone.query.get("test_drone")
        self.assertEqual(drone.capture_backend, DroneCaptureBackend.UNKNOWN)

    def test_02_drone_init(self):
        self.client.emit("drone_init", DroneCaptureBackend.NDP.value)
        drone = Drone.query.get("test_drone")
        self.assertEqual(drone.capture_backend, DroneCaptureBackend.NDP)

        self.client.emit("drone_init", DroneCaptureBackend.TCPDUMP.value)
        drone = Drone.query.get("test_drone")
        self.assertEqual(drone.capture_backend, DroneCaptureBackend.TCPDUMP)

    def test_03_drone_update_status_invalid(self):
        self.client.emit(
            "drone_update_status", {"status": "unknown status", "active_job": None}
        )
        drone = Drone.query.get("test_drone")
        self.assertEqual(drone.status, DroneStatus.ERROR)

    def test_04_drone_update_status(self):
        self.client.emit(
            "drone_update_status",
            {"status": DroneStatus.WORKING.value, "active_job": None},
        )
        drone = Drone.query.get("test_drone")
        self.assertEqual(drone.status, DroneStatus.WORKING)

    # TODO: test update drone status with active job
    # TODO: test update job
    # TODO: test upload
