#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import unittest

from app import create_app, db, sio
from app.models import Drone


class HiveAuthenticationTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app("testing")
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.drop_all()
        db.create_all()

        _, cls.token = Drone.create(name="test_drone", description="test_description")
        cls.client = sio.test_client(
            app=cls.app,
            auth={"token": cls.token},
            flask_test_client=cls.app.test_client(),
        )

    @classmethod
    def tearDownClass(cls) -> None:
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_01_drone_connect(self):
        self.client.connect()
        self.assertTrue(self.client.is_connected())

        drone = Drone.query.get("test_drone")
        self.assertIsNotNone(drone.socketio_id)

    def test_02_drone_disconnect(self):
        self.client.disconnect()
        self.assertFalse(self.client.is_connected())

        drone = Drone.query.get("test_drone")
        self.assertIsNone(drone.socketio_id)
