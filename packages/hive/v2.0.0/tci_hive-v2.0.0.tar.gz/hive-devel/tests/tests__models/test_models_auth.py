#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import unittest

from app import create_app, db
from app.models import AuthorizationLevel, Permission


class AuthorizationLevelModelTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app("testing")
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.drop_all()
        db.create_all()

        cls.auth1 = AuthorizationLevel(
            level=2, name="TestAuth1", permissions=int(Permission.ADMIN)
        )

        cls.auth_to_edit = AuthorizationLevel(
            level=3, name="TestAuthToEdit", permissions=0
        )

        cls.auth_to_delete = AuthorizationLevel(
            level=99, name="TestAuthToDelete", permissions=0
        )

        db.session.add(cls.auth1)
        db.session.add(cls.auth_to_edit)
        db.session.add(cls.auth_to_delete)
        db.session.commit()

    @classmethod
    def tearDownClass(cls) -> None:
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_insert_auths(self):
        ins_auths = AuthorizationLevel.insert_authorizations()
        self.assertEqual(ins_auths[0].name, "Admin")

        ins_auths = AuthorizationLevel.insert_authorizations()
        self.assertCountEqual(ins_auths, [])

    def test_create_auths(self):
        auth = AuthorizationLevel.create(
            level=10, name="TestAuth10", permissions=int(Permission.ADMIN)
        )

        self.assertEqual(auth.level, 10)
        self.assertEqual(auth.name, "TestAuth10")
        self.assertEqual(auth.permissions, int(Permission.ADMIN))

    def test_create_auth_duplicate(self):
        # Duplicate level
        with self.assertRaises(ValueError):
            AuthorizationLevel.create(
                level=self.auth1.level, name="foobar", permissions=int(Permission.ADMIN)
            )

        # Duplicate name
        with self.assertRaises(ValueError):
            AuthorizationLevel.create(
                level=10, name=self.auth1.name, permissions=int(Permission.ADMIN)
            )

    def test_create_auth_wrong_args(self):
        with self.assertRaises(ValueError):
            AuthorizationLevel.create(
                level=-1, name="TestAuth1", permissions=int(Permission.ADMIN)
            )

    def test_edit(self):
        auth = AuthorizationLevel.edit(level=self.auth_to_edit.level, name="FooBar")
        self.assertEqual(auth.name, "FooBar")

    def test_edit_incorrect(self):
        # Wrong level
        with self.assertRaises(ValueError):
            AuthorizationLevel.edit(level=123, name="foobar")

        # Duplicate name
        with self.assertRaises(ValueError):
            AuthorizationLevel.edit(level=self.auth_to_edit.level, name=self.auth1.name)

    def test_delete_incorrect(self):
        # Wrong level
        with self.assertRaises(ValueError):
            AuthorizationLevel.delete(level=123)

    def test_delete_correct(self):
        AuthorizationLevel.delete(level=self.auth_to_delete.level)

    def test_permission_functions(self):
        level = AuthorizationLevel.create(level=123, name="TestLevel")

        self.assertFalse(level.has_permission(Permission.MODIFY_USERS))

        level.add_permission(Permission.MODIFY_USERS)
        self.assertTrue(level.has_permission(Permission.MODIFY_USERS))

        level.remove_permission(Permission.MODIFY_USERS)
        self.assertFalse(level.has_permission(Permission.MODIFY_USERS))

        level.add_permissions(
            [Permission.MODIFY_USERS, Permission.MODIFY_AUTHORIZATIONS]
        )
        self.assertTrue(level.has_permission(Permission.MODIFY_USERS))
        self.assertTrue(level.has_permission(Permission.MODIFY_AUTHORIZATIONS))

        level.reset_permissions()
        self.assertEqual(level.permissions, 0)
