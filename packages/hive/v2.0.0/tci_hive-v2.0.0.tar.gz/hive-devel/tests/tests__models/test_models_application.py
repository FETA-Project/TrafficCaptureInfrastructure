#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import unittest

from app import create_app, db
from app.models import Application, User, AuthorizationLevel
from werkzeug.security import generate_password_hash


class ApplicationModelTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app("testing")
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.drop_all()
        db.create_all()

        cls.app1_token = "app1_token"
        cls.app1_token_hash = generate_password_hash(cls.app1_token)

        cls.auth = AuthorizationLevel.create(level=1, name="TestLevel", permissions=0)

        cls.user = User.create(
            username="test",
            email="test@mail.cz",
            authorization_level=cls.auth.level,
            password="test_password_123",
        )

        cls.app1 = Application(
            name="TestApp1",
            owner=cls.user.username,
            token_hash=cls.app1_token_hash,
        )

        cls.app_regen = Application(
            name="TestAppRegen",
            owner=cls.user.username,
            token_hash=generate_password_hash("app_regen_token"),
        )

        cls.app_delete = Application(
            name="TestAppDelete",
            owner=cls.user.username,
            token_hash=generate_password_hash("app_delete_token"),
        )

        db.session.add(cls.app1)
        db.session.add(cls.app_regen)
        db.session.add(cls.app_delete)
        db.session.commit()

    @classmethod
    def tearDownClass(cls) -> None:
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_create_application(self):
        _app, _token = Application.create(
            name="TestApp2",
            owner=self.user.username,
        )
        self.assertEqual(_app.name, "TestApp2")
        self.assertEqual(_app.owner, self.user.username)
        self.assertIsNotNone(_token)
        self.assertIsNotNone(_app.token_hash)

    def test_create_application_nonexistent_user(self):
        with self.assertRaises(ValueError):
            Application.create(
                name="TestApp2",
                owner="nonexistent_user",
            )

    def test_regenerate_token(self):
        _old_hash = self.app_regen.token_hash
        self.app_regen.regenerate_token()
        self.assertNotEqual(self.app_regen.token_hash, _old_hash)

    def test_delete_application(self):
        Application.delete(self.app_delete.id)
        self.assertNotIn(self.app_delete, Application.query.all())

    def test_delete_nonexistent_application(self):
        with self.assertRaises(ValueError):
            Application.delete("nonexistent_application")

    def test_find_application_by_token(self):
        app = Application.find_by_token(self.app1_token)
        self.assertEqual(app.name, self.app1.name)
        self.assertEqual(app.owner, self.app1.owner)
        self.assertEqual(app.token_hash, self.app1.token_hash)

    def test_find_application_by_token_nonexistent(self):
        app = Application.find_by_token("nonexistent_token")
        self.assertIsNone(app)
