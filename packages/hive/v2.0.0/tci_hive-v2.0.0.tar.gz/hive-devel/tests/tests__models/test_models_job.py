#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import unittest

from app import create_app, db
from app.models import AuthorizationLevel, Permission, User, Script, Drone, Job
from werkzeug.security import generate_password_hash


class JobModelTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app("testing")
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.drop_all()
        db.create_all()

        cls.auth_level_basic = AuthorizationLevel.create(
            level=10, name="AuthLevelBasic", permissions=0
        )

        cls.auth_level_admin = AuthorizationLevel.create(
            level=1, name="AuthLevelAdmin", permissions=int(Permission.ADMIN)
        )

        db.session.add(cls.auth_level_basic)
        db.session.add(cls.auth_level_admin)
        db.session.flush()

        cls.user_basic = User.create(
            username="TestUserBasic",
            email="test_1@email.cz",
            authorization_level=cls.auth_level_basic.level,
            password="password",
        )

        cls.user_admin = User.create(
            username="TestUserAdmin",
            email="test_2@email.cz",
            authorization_level=cls.auth_level_admin.level,
            password="password",
        )

        cls.script = Script.create(
            name="TestScript",
            file_contents="#!/bin/sh echo foobar",
            authorization_level=cls.auth_level_basic.level,
        )

        drone = Drone(
            name="TestDrone",
            description="TestDrone description",
            token_hash=generate_password_hash("token"),
        )

        db.session.add(cls.user_basic)
        db.session.add(cls.script)
        db.session.commit()
        db.session.add(drone)
        db.session.commit()

    @classmethod
    def tearDownClass(cls) -> None:
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_01_create_job_correct(self):
        self.job = Job.create(
            owner=self.user_basic.username,
            name="TestJob1",
            filter="port 42",
            duration=100,
            max_capture_data=100,
            drones=[drone.name for drone in Drone.query.all()],
            script_name=self.script.name,
            script_args="foobar",
        )

    def test_04_delete_job_correct(self):
        try:
            Job.delete(self.job.id)
        except AttributeError:
            pass
