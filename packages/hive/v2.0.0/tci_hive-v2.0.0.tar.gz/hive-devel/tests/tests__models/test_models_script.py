#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import unittest

from app import create_app, db
from app.models import AuthorizationLevel, Permission, Script, ScriptType


class ScriptModelTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app("testing")
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.drop_all()
        db.create_all()

        cls.auth1 = AuthorizationLevel(
            level=10, name="TestLevel", permissions=int(Permission.MODIFY_USERS)
        )

        cls.auth2 = AuthorizationLevel(
            level=69, name="NewAuthLevel", permissions=int(Permission.ADMIN)
        )

        cls.test_script_content = '#!/bin/sh\necho "test"'

        cls.script1 = Script(
            name="TestScript",
            file_contents=cls.test_script_content.encode("utf-8"),
            authorization_level=cls.auth1.level,
        )

        cls.script_to_edit = Script(
            name="ScriptToEdit",
            file_contents=cls.test_script_content.encode("utf-8"),
            authorization_level=cls.auth1.level,
        )

        db.session.add(cls.auth1)
        db.session.add(cls.auth2)
        db.session.commit()
        db.session.add(cls.script1)
        db.session.add(cls.script_to_edit)
        db.session.commit()

    @classmethod
    def tearDownClass(cls) -> None:
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_insert_scripts(self):
        ins_scripts = Script.insert_scripts()
        self.assertEqual(ins_scripts[0].name, "None")

        ins_scripts = Script.insert_scripts()
        self.assertCountEqual(ins_scripts, [])

    def test_create_script(self):
        script = Script.create(
            name="NewScript",
            file_contents=self.test_script_content,
            authorization_level=self.auth1.level,
        )

        self.assertEqual(script.name, "NewScript")
        self.assertEqual(script.filetype, ScriptType.SHELL)
        self.assertEqual(script.authorization_level, self.auth1.level)

    def test_create_script_incorrect(self):
        # Non existent authorization level
        with self.assertRaises(ValueError):
            Script.create(
                name="testscript",
                file_contents=self.test_script_content,
                authorization_level=1234,
            )

        # Unknown file type
        with self.assertRaises(ValueError):
            Script.create(
                name="testname",
                file_contents="foobar",
                authorization_level=self.auth1.level,
            )

        # Null file contents
        with self.assertRaises(ValueError):
            Script.create(
                name="testscript",
                file_contents=None,
                authorization_level=self.auth1.level,
            )

        # Duplicate script name
        with self.assertRaises(ValueError):
            Script.create(
                name=self.script1.name,
                file_contents=self.test_script_content,
                authorization_level=self.auth1.level,
            )

        # FIXME: For some reason this works, script name is too long
        # but the script is created
        # Name too long
        # with self.assertRaises(ValueError):
        #     Script.create(
        #         name="123456789012345678901",
        #         file_contents=self.test_script_content,
        #         authorization_level=10
        #     )

    def test_edit_script(self):
        script = Script.edit(
            name=self.script_to_edit.name, authorization_level=self.auth2.level
        )

        self.assertEqual(script.authorization_level, self.auth2.level)

    def test_edit_script_incorrect(self):
        # Wrong script name
        with self.assertRaises(ValueError):
            Script.edit(name="foobar", authorization_level=123)

        # Wrong authorization level
        with self.assertRaises(ValueError):
            Script.edit(name=self.script_to_edit.name, authorization_level=12345)

    def test_delete_script_incorrect(self):
        with self.assertRaises(ValueError):
            Script.delete("foobar")

    def test_delete_script_correct(self):
        Script.delete("TestScript")
