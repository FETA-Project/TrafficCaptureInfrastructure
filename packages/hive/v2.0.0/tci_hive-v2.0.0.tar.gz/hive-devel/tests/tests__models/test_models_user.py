#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import unittest
import random

from app import create_app, db
from app.models import AuthorizationLevel, User, Permission


class UserModelTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app("testing")
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.drop_all()
        db.create_all()

        cls.auth1 = AuthorizationLevel(
            level=1, name="TestLevel", permissions=int(Permission.MODIFY_USERS)
        )

        cls.auth2 = AuthorizationLevel(level=2, name="TestLevel2", permissions=0)

        cls.user1 = User(
            username="TestUser",
            email="testuser1@foo.bar",
            authorization_level=cls.auth1.level,
            password="TestPassword",
        )

        cls.user_to_edit = User(
            username="TestUserToEdit",
            email="test_user_to_edit@foo.bar",
            authorization_level=cls.auth1.level,
            password="TestPassword123",
        )

        cls.user_to_delete = User(
            username="TestUserToDelete",
            email="test_user_to_delete@foo.bar",
            authorization_level=cls.auth1.level,
            password="TestPassword123",
        )

        db.session.add(cls.auth1)
        db.session.add(cls.auth2)
        db.session.commit()
        db.session.add(cls.user1)
        db.session.add(cls.user_to_edit)
        db.session.add(cls.user_to_delete)
        db.session.commit()

    @classmethod
    def tearDownClass(cls) -> None:
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_insert_users(self):
        ins_users = User.insert_users()
        self.assertEqual(len(ins_users), 2)

        ins_users = User.insert_users()
        self.assertCountEqual(ins_users, [])

    def test_create_user(self):
        user = User.create(
            username="NewUser",
            email="new_test@email.cz",
            authorization_level=self.auth1.level,
            password="TestPassword",
        )

        self.assertEqual(user.username, "NewUser")
        self.assertEqual(user.email, "new_test@email.cz")
        self.assertEqual(user.authorization_level, self.auth1.level)

    def test_create_user_incorrect(self):
        # Password and LDAP
        with self.assertRaises(ValueError):
            User.create(
                username="FooBar",
                email="foo@bar.fb",
                authorization_level=self.auth1.name,
                password="foobar",
                uses_ldap=True,
            )

        # No password and no LDAP
        with self.assertRaises(ValueError):
            User.create(
                username="FooBar",
                email="foo@bar.fb",
                authorization_level=self.auth1.name,
                uses_ldap=False,
            )

        # Duplicate email
        with self.assertRaises(ValueError):
            User.create(
                username="TestUser2",
                email=self.user1.email,
                authorization_level=self.auth1.name,
                password="TestPassword",
            )

        # Duplicate name
        with self.assertRaises(ValueError):
            User.create(
                username=self.user1.username,
                email="test1231241251@mail.c",
                authorization_level=self.auth1.level,
                password="TestPassword",
            )

        # Reserved name
        with self.assertRaises(ValueError):
            User.create(
                username="@me",
                email="me@mail.c",
                authorization_level=self.auth1.name,
                password="TestPassword",
            )

        # Unknown auth level
        with self.assertRaises(ValueError):
            User.create(
                username="TestUser2",
                email="foo@bar.fb",
                authorization_level=12345,
                password="TestPassword",
            )

    def test_reading_password(self):
        with self.assertRaises(AttributeError):
            user = User.query.get("TestUser")
            password = user.password
            del password

    def test_wrong_password_length(self):
        # Password too short
        with self.assertRaises(ValueError):
            User.create(
                username="TestUser12345",
                email="foobar@foobar.cz",
                authorization_level=self.auth1.level,
                password=str(random.randint(1, 7)),
            )

        # Password too long
        with self.assertRaises(ValueError):
            User.create(
                username="TestUser12345",
                email="foobar@foobar.cz",
                authorization_level=self.auth1.level,
                password=str(random.randint(501, 1000)),
            )

    def test_has_permission(self):
        user = User.query.get(self.user1.username)
        self.assertTrue(user.has_permission(Permission.MODIFY_USERS))
        self.assertFalse(user.has_permission(Permission.SCRIPT_MASTER))

    def test_edit_user(self):
        # Edit email
        user = User.edit(
            username=self.user_to_edit.username, email="new_mail123@mail.mail"
        )
        self.assertEqual(user.email, "new_mail123@mail.mail")

        # Edit password
        user = User.edit(username=self.user_to_edit.username, password="NewPassword123")

        # Edit authorization level
        user = User.edit(
            username=self.user_to_edit.username, authorization_level=self.auth2.level
        )
        self.assertEqual(user.authorization_level, self.auth2.level)

        # Edit everything
        user = User.edit(
            username=self.user_to_edit.username,
            email="123@mail.com",
            password="NewPassword123",
            authorization_level=self.auth1.level,
        )
        self.assertEqual(user.email, "123@mail.com")
        self.assertEqual(user.authorization_level, self.auth1.level)

    def test_edit_user_incorrect(self):
        # Duplicate email
        with self.assertRaises(ValueError):
            User.edit(username=self.user_to_edit.username, email=self.user1.email)

        # Password too short
        with self.assertRaises(ValueError):
            User.edit(
                username=self.user_to_edit.username, password=str(random.randint(1, 7))
            )

        # Password too long
        with self.assertRaises(ValueError):
            User.edit(
                username=self.user_to_edit.username,
                password=str(random.randint(501, 1000)),
            )

        # Unknown auth level
        with self.assertRaises(ValueError):
            User.edit(
                username=self.user_to_edit.username,
                authorization_level=12345,
            )

        # User not found
        with self.assertRaises(ValueError):
            User.edit(username="Nonexistent", email="awefohaweoifhawe@awoiefh.cz")

    def test_delete_user(self):
        User.delete(self.user_to_delete.username)

        user = User.query.get(self.user_to_delete.username)
        self.assertIsNone(user)

    def test_delete_non_existent_user(self):
        with self.assertRaises(ValueError):
            User.delete("NonExistentUser")
