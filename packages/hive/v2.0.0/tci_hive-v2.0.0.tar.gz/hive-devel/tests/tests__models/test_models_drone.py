#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import unittest
import random

from . import generate_random_string
from app import create_app, db
from app.models import Drone


class DroneModelTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = create_app("testing")
        cls.app_context = cls.app.app_context()
        cls.app_context.push()
        db.drop_all()
        db.create_all()

    @classmethod
    def tearDownClass(cls) -> None:
        db.session.remove()
        db.drop_all()
        cls.app_context.pop()

    def test_01_create_and_delete_drone(self):
        # Name too long
        with self.assertRaises(ValueError):
            _ = Drone.create(generate_random_string(100))

        # Valid create
        random_name = generate_random_string(random.randint(1, 30))
        drone, _ = Drone.create(random_name)

        # Duplicate name
        with self.assertRaises(ValueError):
            _ = Drone.create(random_name)

        # Delete nonexistent drone
        with self.assertRaises(ValueError):
            Drone.delete(generate_random_string(30))

        # Correct delete
        Drone.delete(drone.name)

    def test_02_token_generation(self):
        # Creating the drone
        drone, token_initial = Drone.create(
            generate_random_string(random.randint(1, 30))
        )

        # Generating a new token
        token_new = drone.regenerate_token()

        # Making sure they are distinct
        self.assertNotEqual(token_initial, token_new)

    def test_03_find_by_token(self):
        # Creating 5 drones
        for _ in range(6):
            _, token = Drone.create(generate_random_string(random.randint(1, 30)))

        # Finding the drone
        drone = Drone.find_by_token(token)
        self.assertIsNotNone(drone)

    def test_drone_change_color(self):
        drone = Drone.query.first()

        _new_color = drone.color
        while _new_color == drone.color:
            _new_color = Drone.generate_color()

        Drone.change_color(drone.name, _new_color)
        self.assertEqual(drone.color, _new_color)

    def test_nonexistent_drone_change_color(self):
        with self.assertRaises(ValueError):
            Drone.change_color("nonexistent_drone", "#000000")

    def test_drone_change_wrong_color(self):
        drone = Drone.query.first()

        with self.assertRaises(ValueError):
            Drone.change_color(drone.name, "#weoifh")

        with self.assertRaises(ValueError):
            Drone.change_color(drone.name, "000000")

        with self.assertRaises(ValueError):
            Drone.change_color(drone.name, "#000")

        with self.assertRaises(ValueError):
            Drone.change_color(drone.name, "#000")
