#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import random
import string


def generate_random_string(length: int) -> str:
    return "".join(random.choices(string.ascii_letters, k=length))
