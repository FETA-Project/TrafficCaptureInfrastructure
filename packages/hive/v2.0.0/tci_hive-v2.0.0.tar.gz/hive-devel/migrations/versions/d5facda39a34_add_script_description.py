"""add_script_description

Revision ID: d5facda39a34
Revises: 12ba8d1bebf6
Create Date: 2022-08-10 13:16:29.324046

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import mysql

# revision identifiers, used by Alembic.
revision = "d5facda39a34"
down_revision = "12ba8d1bebf6"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("Script", sa.Column("description", sa.Text(), nullable=True))


def downgrade():
    op.drop_column("Script", "description")
