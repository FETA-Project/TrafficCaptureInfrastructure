#!/bin/sh

# This file is used to deploy and launch the Flask app in one simple command.

while true; do
    if ! flask deploy; then
        break
    fi
    echo Deploy command failed, retrying in 5 seconds...
    sleep 5
done

exec python3 tcigui.py
