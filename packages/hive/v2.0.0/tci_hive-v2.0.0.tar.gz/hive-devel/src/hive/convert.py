#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Convertor for duration and data size
====================================

**Authors**

- Jiří Havránek

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Used for converting sizes and times between human-readable and machine formats.
"""

import re
from datetime import datetime
from typing import List, Optional, Tuple

from pytz import timezone


class Conversions:
    """Store time and data conversion factors.

    .. warning::
       Currently, there is no difference between ``b`` and ``B`` when talking
       about file and capture sizes.
    """

    time = {
        "D": 24 * 60 * 60,
        "d": 24 * 60 * 60,
        "H": 60 * 60,
        "h": 60 * 60,
        "M": 60,
        "m": 60,
        "S": 1,
        "s": 1,
    }
    data = {
        "GiB": 1024**3,
        "GB": 1000**3,
        "gb": 1000**3,
        "G": 1000**3,
        "g": 1000**3,
        "MiB": 1024**2,
        "MB": 1000**2,
        "mb": 1000**2,
        "M": 1000**2,
        "m": 1000**2,
        "KiB": 1024,
        "KB": 1000,
        "kb": 1000,
        "K": 1000,
        "k": 1000,
        "B": 1,
        "b": 1,
    }


def convert_split_tokens(
    tokens: List[str], conversions: dict
) -> Tuple[bool, int]:  # noqa: E501
    """
    Convert tokens by rules from conversions

    Args:
        tokens (List[str]): list of tokens to convert
        conversions (dict): conversion rules

    Returns:
        (bool, int): A tuple containing the status and return values.
    """
    value = 0
    parsed_num = 0
    expect_number = True
    for token in tokens:
        if not token:
            continue
        if expect_number:
            expect_number = False
            try:
                parsed_num = int(token)
            except ValueError:
                return False, 0
            if parsed_num < 0:
                return False, 0
        else:
            expect_number = True
            try:
                value += parsed_num * conversions[token]
            except KeyError:
                return False, 0
    return expect_number, value


def parse_duration(duration: str) -> Tuple[bool, int]:
    """
    Parse duration with convert_split_tokens

    Args:
        duration (str): The input duration which should be converted.

    Returns:
        (bool, int): A tuple containing the status and the return values.
    """
    tokens = re.split("([Dd])|([Hh])|([Mm])|([Ss])", duration)
    return convert_split_tokens(tokens, Conversions.time)


def parse_byte_size(size: str) -> Tuple[bool, int]:
    """
    Parse byte size with convert_split_tokens

    Args:
        size (str): The input size which should be converted to bytes.

    Returns:
        (bool, int): A tuple containing the status and the return values.
    """
    tokens = re.split("(GiB|GB|gb|G|g)|(MiB|MB|mb|M|m)|(KiB|KB|kb|K|k)|([Bb])", size)
    return convert_split_tokens(tokens, Conversions.data)


def set_local_tz(date: str, time_zone: str = "Europe/Prague") -> Optional[str]:
    """Convert a date string to the local timezone.

    Args:
        date (str): The datetime string in YYYY-MM-DD HH-MM-SS format.
        time_zone (str): The timezone to convert to. Defaults to Europe/Prague.

    Returns:
        str: The datetime string in the current timezone.

    .. versionadded:: 1.0.0
    .. versionchanged:: 1.2.1
        Added timezone parameter.
    """
    if date is None:
        return None

    local_tz = timezone(time_zone)
    return (
        datetime.fromisoformat(date).astimezone(local_tz).strftime("%Y-%m-%d %H:%M:%S")
    )
