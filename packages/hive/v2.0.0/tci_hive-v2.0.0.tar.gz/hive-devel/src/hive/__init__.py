#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# pylint: disable=invalid-name, global-statement, import-outside-toplevel

"""
App package
===========

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Implementation of the TCI Web application.
"""

# ruff: noqa: PLW0603

from flask import Flask
from flask_jwt_extended import jwt_manager
from flask_socketio import SocketIO
from flask_sqlalchemy import SQLAlchemy
from flask_wtf.csrf import CSRFProtect

from config import config
from .pcap_script_api import PCAPScript
from .tciapi import TCI

csrf = CSRFProtect()
db = SQLAlchemy()
pcap_script = None
sio = SocketIO()
tci = None

jwt = jwt_manager.JWTManager()


def create_app(config_name: str) -> Flask:
    """Create the Flask application from the given config.

    Args:
        config_name (str): The name of the configuration class to use.
    """
    app = Flask(__name__)
    app.config.from_object(config[config_name])
    config[config_name].init_app(app)

    csrf.init_app(app)
    db.init_app(app)
    jwt.init_app(app)
    sio.init_app(app)

    global tci
    tci = TCI(
        config[config_name].TCI_HOST,
        config[config_name].TCI_PORT,
        config[config_name].TCI_CERT_PATH,
        config[config_name].TCI_CA_CERT_PATH,
        config[config_name].TCI_TLS,
    )

    global pcap_script
    pcap_script = PCAPScript(
        pcap_folder=config[config_name].PCAP_FOLDER,
        tmp_folder=config[config_name].TMP_FOLDER,
        use_docker=config[config_name].USE_DOCKER,
    )

    from .api import api as api_blueprint

    app.register_blueprint(api_blueprint, url_prefix="/api/v1")
    csrf.exempt(api_blueprint)

    from .hive import hive_blueprint

    app.register_blueprint(hive_blueprint, url_prefix="/hive/v1")

    return app
