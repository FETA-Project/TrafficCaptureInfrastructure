#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Users module
============

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Implementation of user functionality for the API.

**Functions**

.. automethod:: app.api.users.get_users()
.. automethod:: app.api.users.get_user_info(username)
.. automethod:: app.api.users.create_user()
.. automethod:: app.api.users.edit_user(username)
.. automethod:: app.api.users.delete_user(username)
"""

from flask import Response, current_app, g, jsonify, request
from flask_expects_json import expects_json

from ..decorators import permission_required
from ..models import Permission, User
from . import Schemas, api, log
from .errors import bad_request, forbidden, internal_error


@api.route("/users")
def get_users() -> Response:
    """Get all existing users.

    **Example response**:

    .. code-block:: json

       [
           {
               "username": "User1",
               "email": "user1@email.cz",
               "authorization_level": 123
           },
           {
               "username": "User2",
               "email": "user2@email.com",
               "authorization_level": 321
           }
       ]

    Returns:
        Response: A JSON containing the list of all the existing users.

    .. versionadded:: 1.2.0

    .. :quickref: User; Get all users.
    """
    log("Getting all users")
    users = User.query.order_by(User.username).all()
    return jsonify([user.to_dict() for user in users])


@api.route("/users/<string:username>")
def get_user_info(username: str) -> Response:
    """Get further info about a specific user.

    **Example response**:

    .. code-block:: json

       {
           "username": "User1",
           "email": "foo@bar.fb",
           "authorization_level": 42,
       }

    Args:
        username (str): The username of the user.

    Returns:
        Response: A dictionary with more user information.

    .. note::
       This function returns user information only if the current user
       has the same or higher authorization level.

    .. versionadded:: 1.2.0

    .. :quickref: User; Get info about a specific user.
    """
    log(f"Getting user {username} info")

    username = g.current_user.username if username == "@me" else username

    user = User.query.get_or_404(username)

    if user.authorization_level < g.current_user.authorization_level:
        return forbidden(
            "The user you are trying to access has higher authorization than you!"
        )
    return jsonify(user.to_dict())


@api.route("/users", methods=["POST"])
@expects_json(Schemas.new_user_schema)
@permission_required(Permission.MODIFY_USERS)
def create_user() -> Response:
    """Create a new user.

    **Example request**:

    .. code-block:: json

       {
           "username": "foobar",
           "email": "foo@bar.fb",
           "authorization_level": 123,
           "password": "password"
       }

    Returns:
        Response: An error message or the new user as JSON.

    .. note::
        It is not possible to manually create an instance of an LDAP user.
        LDAP users are automatically created when they attempt to log in with
        their LDAP credentials.

    .. versionadded:: 1.2.0

    .. :quickref: User; Create a new user.
    """
    log("Creating a new user")

    if (
        request.json["authorization_level"] < g.current_user.authorization_level
    ):  # noqa: E501
        return forbidden(
            "Can't create a user with a higher authorization level than yourself!"
        )

    try:
        user = User.create(
            username=request.json["username"],
            email=request.json["email"],
            authorization_level=request.json["authorization_level"],
            password=request.json["password"],
        )
    except ValueError as err:
        return bad_request(str(err))
    except RuntimeError as err:
        current_app.logger.error(str(err))
        return internal_error(str(err))

    return jsonify(user.to_dict())


@api.route("/users/<string:username>", methods=["PUT"])
def edit_user(username: str) -> Response:
    """Edit a user.

    **Example request**:

    .. code-block:: json

       {
           "email": "new_email@foobar.cz",
           "password": "new_password"
       }

    Args:
        username (str): The username of the user.

    Returns:
        Response: Error message or edited user as JSON.

    .. versionadded:: 1.2.0

    .. :quickref: User; Edit a user.
    """
    log(f"Editing the user {username}")

    username = g.current_user.username if username == "@me" else username

    if username != g.current_user.username and not g.current_user.has_permission(
        Permission.MODIFY_USERS
    ):
        return forbidden("You don't have permissions to edit other users!")

    user = User.query.get(username)
    if user is None:
        return bad_request("Couldn't find the specified user!")

    if user.authorization_level < g.current_user.authorization_level:
        return forbidden("Can't edit a user with higher authorization!")

    try:
        user = User.edit(
            username=username,
            email=request.json.get("email", None),
            password=request.json.get("password", None),
            authorization_level=request.json.get("authorization_level", None),
        )
    except ValueError as err:
        return bad_request(str(err))
    except RuntimeError as err:
        current_app.logger.error(str(err))
        return internal_error(str(err))

    return jsonify(user.to_dict())


@api.route("/users/<string:username>", methods=["DELETE"])
@permission_required(Permission.MODIFY_USERS)
def delete_user(username: str) -> Response:
    """Delete an existing user.

    Args:
        username (str): The username of the User to delete.

    Returns:
        Response: Status code or error message.

    .. versionadded:: 1.2.0

    .. :quickref: User; Delete a user.
    """
    log(f"Deleting the user {username}")

    username = g.current_user.username if username == "@me" else username

    if username == g.current_user.username:
        return bad_request("Can't delete yourself!")

    user = User.query.get(username)

    if user is None:
        return bad_request("Couldn't find the specified user!")

    if user.authorization_level < g.current_user.authorization_level:
        return forbidden("Can't edit a user with higher authorization!")

    try:
        User.delete(username)
    except ValueError as err:
        return bad_request(str(err))
    except RuntimeError as err:
        current_app.logger.error(str(err))
        return internal_error(str(err))

    return Response(status=204)
