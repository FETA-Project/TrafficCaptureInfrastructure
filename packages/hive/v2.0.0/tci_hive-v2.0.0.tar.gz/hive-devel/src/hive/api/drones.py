#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Drones module
=============

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Implementation of drone functionality for the API.

**Functions**

.. automethod:: app.api.drones.get_drones()
.. automethod:: app.api.drones.new_drone()
.. automethod:: app.api.drones.generate_new_token(drone_name)
.. automethod:: app.api.drones.delete_drone(drone_name)
"""

from flask import jsonify, request, Response
from flask_expects_json import expects_json

from . import api, log, Schemas
from .errors import bad_request, internal_error
from ..decorators import permission_required
from ..models import Drone, Permission


@api.route("/drones")
def get_drones() -> Response:
    """Get all the existing drones.

    **Example response**:

    .. code-block:: json

       [
            {
                "name": "Drone1",
                "description": "Drone 1 description",
                "capture_backend": "TCPDUMP",
                "status": "capturing",
                "color": "#0000ff",
                "jobs": [
                    {
                        "job_id": 1,
                        "drone_name": "Drone1",
                        "captured_data": 123,
                        "status": "capturing",
                        "status_msg": "Capturing..."
                    }
                ]
            }
       ]

    Returns:
        Response: A JSON containing the list of all the drones.

    .. versionadded:: 2.0.0

    .. :quickref: Drone; Get all the drones.
    """
    log("Getting all the drones")

    drones = Drone.query.order_by(Drone.name).all()
    drone_list = []
    for drone in drones:
        drone_dict = drone.to_dict()
        drone_dict["jobs"] = [job.to_dict() for job in drone.jobs]
        drone_list.append(drone_dict)
    return jsonify(drone_list)


@api.route("/drones/<string:drone_name>")
def get_drone_info(drone_name: str) -> Response:
    """Get specific drone info.

    **Example response**:

    .. code-block:: json

       {
           "name": "drone1",
           "description": "Info about drone1",
           "capture_backend": "NDP",
           "status": "capturing"
       }

    Args:
        drone_name (str): The name of the drone.

    Returns:
        Response: Specific info about the drone.

    .. versionadded:: 2.0.0

    .. :quickref: Drone; Get info about a specific drone.
    """
    log(f"Getting {drone_name} drone info")

    drone = Drone.query.get_or_404(drone_name)
    return jsonify(drone.to_dict())


@api.route("/drones", methods=["POST"])
@expects_json(Schemas.new_drone_schema)
@permission_required(Permission.ADMIN)
def new_drone() -> Response:
    """Create a new drone.

    Returns:
        Response: A JSON containg the created drone information and an
            authentication token, which can be accessed only one time.

    .. versionadded:: 2.0.0
    .. :quickref: Drone; Create a new drone.
    """
    log("Creating a new drone")

    try:
        drone, token = Drone.create(
            name=request.json["name"],
            description=request.json["description"],
        )
    except ValueError as err:
        return bad_request(str(err))

    drone_dict = drone.to_dict()
    drone_dict["token"] = token
    return jsonify(drone_dict)


@api.route("/drones/<string:drone_name>", methods=["PUT"])
@permission_required(Permission.ADMIN)
def generate_new_token(drone_name: str) -> Response:
    """Generate a new authentication token for the drone.

    Args:
        drone_name (str): The name of the drone for which to generate
        the authentication token.

    Returns:
        Response: A JSON containing the authentication token.

    .. versionadded:: 2.0.0
    .. :quickref: Drone; Generate a new authentication token.
    """
    log(f"Regenerating token for drone {drone_name}.")
    drone = Drone.query.get_or_404(drone_name)
    token = drone.regenerate_token()
    return jsonify({"token": token})


@api.route("/drones/<string:name>", methods=["PATCH"])
@expects_json(Schemas.edit_drone_color_schema)
@permission_required(Permission.ADMIN)
def change_drone_color(name: str) -> Response:
    """Change drone color.

    **Example request**:

        .. code-block:: json

            {"color": "#0000ff"}

    Args:
        name (str): The name of the drone.

    Returns:
        Response: Changed drone or error message.

    .. versionadded:: 2.0.0

    .. :quickref: Drone, Change color of a drone.
    """
    log("Changing drone color")

    try:
        drone = Drone.change_color(name, request.json["color"])
    except ValueError as err:
        return bad_request(str(err))

    return jsonify(drone.to_dict())


@api.route("/drones/<string:drone_name>/queue", methods=["GET"])
def show_drone_queue(drone_name: str) -> Response:
    """Show drone queue.

    Args:
        drone_name (str): The name of the drone.

    Returns:
        Response: A JSON containing the drone queue.

    .. versionadded:: 2.0.0

    .. :quickref: Drone; Show drone queue.
    """
    log(f"Showing drone {drone_name} queue.")

    drone = Drone.query.get_or_404(drone_name)

    return jsonify({"active": drone.active_job, "queue": drone.job_queue})


@api.route("/drones/<string:drone_name>", methods=["DELETE"])
@permission_required(Permission.ADMIN)
def delete_drone(drone_name: str) -> Response:
    """Delete a drone.

    Args:
        drone_name (str): The name of the drone to delete.

    Raises:
        internal_error: On RuntimeError from `Drone.delete`.

    Returns:
        Response: Stratus code or error message.

    .. versionadded:: 2.0.0
    .. :quickref: Drone; Delete a drone.
    """
    log(f"Deleting the drone {drone_name}")

    # Querying the drone to see if it exists.
    _ = Drone.query.get_or_404(drone_name)

    try:
        Drone.delete(drone_name)
    except ValueError as err:
        return bad_request(str(err))
    except RuntimeError as err:
        raise internal_error(str(err)) from err

    return Response(status=204)
