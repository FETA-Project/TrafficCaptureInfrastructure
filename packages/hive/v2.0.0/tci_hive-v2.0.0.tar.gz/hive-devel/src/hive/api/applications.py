#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Applications module
===================

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Implements user applications functionality for the API.

**Functions**

.. automethod:: app.api.applications.get_applications()
.. automethod:: app.api.applications.new_application()
.. automethod:: app.api.applications.delete_application()
"""

from flask import Response, g, jsonify, request
from flask_expects_json import expects_json

from ..models import Application
from . import Schemas, api, log
from .errors import bad_request, forbidden, internal_error


@api.route("/applications")
def get_applications() -> Response:
    """Get all the user applications.

    Returns:
        Response: A JSON containing the list of all the user applications.

    .. versionadded:: 1.3.0
    .. :quickref: Applications; Get all user applications.
    """
    log("Getting all user applications")

    apps = Application.query.all()
    return jsonify(
        [app.to_dict() for app in apps if app.owner == g.current_user.username]
    )


@api.route("/applications", methods=["POST"])
@expects_json(Schemas.new_application)
def new_application() -> Response:
    """Create a new user application.

    Returns:
        Response: A JSON containing the created user application and an
            authentication token, which can be accessed only one time.

    .. versionadded:: 1.3.0
    .. :quickref: Applications; Create a new user application.
    """
    log("Creating a new user application")

    try:
        app, token = Application.create(
            name=request.json["name"], owner=g.current_user.username
        )
    except ValueError as err:
        return bad_request(str(err))

    app_dict = app.to_dict()
    app_dict["token"] = token
    return jsonify(app_dict)


@api.route("/applications/<int:app_id>", methods=["PUT"])
def regenerate_token(app_id: int) -> Response:
    """Regenerate token for user application.

    Args:
        app_id (int): The ID of the application to renegerate token for.

    .. versionadded:: 1.3.0

    .. :quickref: Application; Regenerate token.
    """
    log(f"Regenerating token for application {app_id}")
    app = Application.query.get_or_404(app_id)

    if app.owner != g.current_user.username:
        return forbidden("You are not the owner of this application.")

    token = app.regenerate_token()
    return jsonify({"token": token})


@api.route("/applications/<int:app_id>", methods=["DELETE"])
def delete_application(app_id: int) -> Response:
    """Delete a user application.

    Args:
        app_id (int): The ID of the application to remove.

    Returns:
        Response: Status code or error message.

    .. versionadded:: 1.3.0

    .. :quickref: Application; Delete user application.
    """
    log(f"Deleting the application {app_id}")
    app = Application.query.get_or_404(app_id)

    if app.owner != g.current_user.username:
        return forbidden("You can't delete other user applications.")

    try:
        Application.delete(app_id)
    except ValueError as err:
        return bad_request(str(err))
    except RuntimeError as err:
        return internal_error(str(err))

    return Response(status=204)
