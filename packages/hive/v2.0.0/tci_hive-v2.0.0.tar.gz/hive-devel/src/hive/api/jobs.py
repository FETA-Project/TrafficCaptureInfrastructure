#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Jobs module
===========

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Implementation of jobs functionality for the API.

**Functions**

.. automethod:: app.api.jobs.check_job_authorization(owner)
.. automethod:: app.api.jobs.get_jobs()
.. automethod:: app.api.jobs.get_job_info(id)
.. automethod:: app.api.jobs.create_job()
.. automethod:: app.api.jobs.delete_job(id)
.. automethod:: app.api.jobs.process_job(id)
.. automethod:: app.api.jobs.stop_job(id)
.. automethod:: app.api.jobs.send_capture_data(job, raw)
.. automethod:: app.api.jobs.get_file(token)
.. automethod:: app.api.jobs.generate_job_url(id)
.. automethod:: app.api.jobs.download_job(id)
"""

from os import path
from typing import NoReturn

from flask import Response, current_app, g, jsonify, request, stream_with_context
from flask.helpers import make_response, url_for
from flask_expects_json import expects_json

# from pytz import timezone
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from werkzeug.utils import secure_filename

from .. import pcap_script
from ..convert import set_local_tz
from ..models import Job, JobStatus, Permission, User
from ..tciapi import TCIException
from . import Schemas, api, log, read_file_chunks
from .errors import bad_request, forbidden, internal_error


def check_job_authorization(owner: User) -> NoReturn:
    """
    Check authorization of current user with owner of a job.

    Args:
      owner (User):

    Raises:
        PermissionError: If user is not authorized to access the job.

    .. versionadded:: 1.2.0
    """
    if g.current_user == owner:
        return
    if owner.authorization_level > g.current_user.authorization_level:
        return
    if g.current_user.has_permission(Permission.JOB_MASTER):
        return

    raise PermissionError("Insufficient permissions.")


@api.route("/jobs")
def get_jobs() -> Response:
    """Get a list of all the jobs.

    **Example response**:

    .. code-block:: json

       [
           {
               "id": 123,
               "owner": "AdminUser",
               "name": "ExampleJob",
               "status": "Done",
               "start_time": 123456789,
               "end_time": 123456789
           }
       ]

    Returns:
        A JSON list of all the jobs that the user has access to. The
        returned JSON has the following format:

        .. code-block:: json

        [
            {
                "id": 7,
                "name": "TestJob",
                "owner": "Admin",
                "status": "Done",
                "start_time":"2022-08-04 10:04:37",
                "end_time": "2022-08-04 10:04:48"
            }
        ]

    .. note::

       This method only returns jobs which the user has permission to see.
       That is, if the user doesn't have the JobMaster authorization level,
       it will return only his own jobs. If the user has the JobMaster
       authorization, this method will return all jobs created by users with
       the same or lower authorization level as the user himself.

    .. versionadded:: 1.2.0

    .. :quickref: Job; Get all jobs.

    .. todo::
       * Add support for the processing queue
       * Make sure the times are returned in the local time zone
    """
    log("Getting all jobs")

    if g.current_user.has_permission(Permission.JOB_MASTER):
        jobs = [
            job
            for job in Job.query.all()
            if g.current_user.authorization_level
            <= User.query.get(job.owner).authorization_level
        ]
    else:
        jobs = Job.query.filter_by(owner=g.current_user.username).all()

    if not jobs:
        return make_response("", 204)

    return jsonify(
        [
            {
                "id": job.id,
                "owner": job.owner,
                "name": job.name,
                "status": job.status,
                "start_time": set_local_tz(job.start_time),
                "end_time": set_local_tz(job.end_time),
            }
            for job in jobs
        ]
    )


@api.route("/jobs/<int:job_id>")
def get_job_info(job_id: int) -> Response:
    """Get detailed info about a specific job.

    **Example response**:

    .. code-block:: json

        {
            "id": 7,
            "name": "TestJob",
            "owner": "Admin",
            "status": "Done",
            "filter": "",
            "status_msg": null,
            "duration": 10,
            "duration_human": "10 seconds",
            "max_capture_data": 10000000,
            "max_capture_data_human": "10.0 MB",
            "start_time": "2022-08-04 10:04:37",
            "end_time": "2022-08-04 10:04:48",
            "drones": [
                {
                    "name": "DEMO-DRONE1",
                    "description": "local ethernet interface",
                    "color": "#4e08cf",
                    "status": "Done",
                    "status_msg": "End time has been exceeded (duration 10)",
                    "captured_data": "12288",
                    "captured_data_human": "12.3 kB"
                }
            ],
            "script_args": "",
            "script_name": null,
        }

    Args:
        job_id (int): The ID of the job.

    Returns:
        Response: A JSON with specific Job info.

    .. versionadded:: 1.2.0

    .. :quickref: Job; Get info about a specific job.
    """
    log(f"Getting info about job {job_id}")

    job = Job.query.get_or_404(job_id)
    try:
        check_job_authorization(User.query.get(job.owner))
    except PermissionError as exc:
        return forbidden(str(exc))
    return jsonify(job.to_dict())


@api.route("/jobs", methods=["POST"])
@expects_json(Schemas.new_job_schema)
def create_job() -> Response:
    """Create a new Job.

    The duration of the job is specified in seconds, and the max_capture_data
    is specified in bytes.

    .. important::

        Even when no filter is specified by the user, the JSON is expected to
        contain an empty string, not `None`. This is because captures without
        a filter could result in very large data files, and it is therefore
        important to ensure that the user didn't forget to enter a filter but
        entered an empty filter on purpose.

    **Example request**:

    .. code-block:: json

       {
           "name": "FooBar",
           "filter": "port 69",
           "duration": 12345,
           "max_capture_data": 12345,
           "script_name": "foo",
           "script_args": "bar",
           "drones": ["drone1", "drone2"]
       }

    Returns:
        Response: Created job as JSON or an error string.

    .. versionadded:: 1.2.0

    .. :quickref: Job; Create a new job.
    """
    log("Creating a new job")

    if len(request.json["drones"]) == 0:
        return bad_request("No drones specified.")

    script_name = None
    if "script_name" in request.json:
        script_name = request.json["script_name"]
    elif not g.current_user.has_permission(Permission.SCRIPT_MASTER):
        return forbidden("No script specified.")

    script_args = ""
    if "script_args" in request.json:
        script_args = request.json["script_args"]

    try:
        job = Job.create(
            owner=g.current_user.username,
            name=request.json["name"],
            filter=request.json["filter"],
            duration=request.json["duration"],
            max_capture_data=request.json["max_capture_data"],
            script_name=script_name,
            script_args=script_args,
            drones=request.json["drones"],
        )
    except ValueError as err:
        return bad_request(str(err))
    except RuntimeError as err:
        return internal_error(str(err))

    return jsonify(job.to_dict())


@api.route("/jobs/<int:job_id>", methods=["DELETE"])
def delete_job(job_id: int) -> Response:
    """Delete a job.

    Args:
        job_id (int): The ID of the job to remove.

    Returns:
        Response: Status code or error message.

    .. versionadded:: 1.2.0

    .. :quickref: Job; Delete a job.
    """
    log(f"Deleting the job {job_id}")

    job = Job.query.get_or_404(job_id)
    try:
        check_job_authorization(User.query.get(job.owner))
    except PermissionError as exc:
        return forbidden(str(exc))

    try:
        Job.delete(job_id)
    except (ValueError, AssertionError) as err:
        return bad_request(str(err))
    except RuntimeError as err:
        return internal_error(str(err))

    return Response(status=204)


@api.route("/jobs/<int:job_id>", methods=["PATCH"])
def process_job(job_id: int) -> Response:
    """Process a job.

    Args:
        job_id (int): The ID of the job to process.

    Returns:
        Response: Status code or error string.

    .. versionadded:: 1.2.0

    .. :quickref: Job; Process a job.

    .. todo::
        Consider processing the job in a new thread.
    """
    log(f"Processing the job {job_id}")

    job = Job.query.get_or_404(job_id)
    try:
        check_job_authorization(User.query.get(job.owner))
    except PermissionError as exc:
        return forbidden(str(exc))

    try:
        pcap_script.process(job)
    except TCIException as exc:
        job.update_status(JobStatus.TO_PROCESS)
        return internal_error(str(exc))

    return Response(status=200)


@api.route("/jobs/<int:job_id>", methods=["PUT"])
def stop_job(job_id: int) -> Response:
    """Stop a job.

    Args:
        job_id (int): The ID of the job to stop.

    Returns:
        Response: Status code or error string.

    .. versionadded:: 1.2.0

    .. :quickref: Job; Stop a job.
    """
    log(f"Stopping the job {job_id}")

    job = Job.query.get_or_404(job_id)
    try:
        check_job_authorization(User.query.get(job.owner))
    except PermissionError as exc:
        return forbidden(str(exc))

    try:
        Job.stop(job_id)
    except (RuntimeError, ValueError) as exc:
        return internal_error(str(exc))

    return Response(status=204)


def send_capture_data(job: Job, raw: bool = False) -> Response:
    """
    Send capture data from job.

    Args:
        job (Job): The job to send.
        raw (bool): Process the data if True, otherwise don't.

    Returns:
        Response: The download file.

    .. versionadded:: 1.0.0

    .. versionchanged:: 1.2.0
        Can download processed and/or raw data from job.
    """

    if raw:
        file = pcap_script.get_output_file(job.id, pcap_script.raw_extensions)
    else:
        file = pcap_script.get_output_file(job.id, ["zip"])

    if file is None:
        raise Exception(  # pylint: disable=broad-exception-raised
            f"Cannot download file of job (id:{job.id}) {job.name}."
            " The file does not exist!"
        )

    download_name = f"{secure_filename(job.name)}{path.splitext(file)[1]}"
    return Response(
        stream_with_context(read_file_chunks(file)),
        headers={"Content-Disposition": f"attachment; filename={download_name}"},
    )


@api.route("/jobs/file/<string:token>")
def get_file(token: str) -> Response:
    """Download the PCAP file for the job.

    Args:
        token (str): The download token.

    Returns:
        Response: The download file.

    .. versionadded:: 1.0.0

    .. :quickref: Job; Get a job file with a temporary token.
    """
    log(f"Downloading the file from token: {token}", log_username=False)

    serializer = Serializer(current_app.config["SECRET_KEY"])

    try:
        job_id = serializer.loads(token).get("job_id")
    except (ValueError, AttributeError):
        return bad_request("Invalid download token.")

    if job_id is None:
        return bad_request("Job ID not in request.")

    job = Job.query.get_or_404(job_id)

    if not job:
        return bad_request("Invalid download token.")

    return send_capture_data(job, raw=job.script_name is None)


@api.route("/jobs/<int:job_id>/url", methods=["GET"])
def generate_job_url(job_id: int) -> Response:
    """Generate a URL of a job.

    Args:
        job_id (int): The ID of the job to generate a URL.

    Returns:
        Response: Status code or error string.

    .. versionadded:: 1.2.0

    .. caution::

        The generated URL is a public endpoint, and it requires no
        authorization to access the captured data.

    .. :quickref: Job; Generate a URL of a job.
    """
    log(f"Generating a URL of the job {job_id}")

    job = Job.query.get_or_404(job_id)
    try:
        check_job_authorization(User.query.get(job.owner))
    except PermissionError as exc:
        return forbidden(str(exc))

    serializer = Serializer(current_app.config["SECRET_KEY"], 24 * 60 * 60)
    token = serializer.dumps({"job_id": job_id}).decode("utf-8")
    url = url_for(
        "api.get_file",
        token=token,
        _external=True,
        _scheme=current_app.config["SERVER_URL_SCHEME"],
    )

    if "SERVER_URL" in current_app.config:
        url = url.replace(
            f"127.0.0.1:{current_app.config['PORT']}", current_app.config["SERVER_URL"]
        )
        url = url.replace(
            f"localhost:{current_app.config['PORT']}", current_app.config["SERVER_URL"]
        )

    return jsonify({"url": url})


@api.route("/jobs/<int:job_id>/file")
def download_job(job_id: int) -> Response:
    """Download job file

    Args:
        job_id (int): The ID of the job to download.

    Returns:
        Response: Status code or error string.

    .. versionadded:: 1.2.0

    .. :quickref: Job; Download a job file.
    """
    log(f"Downloading the job {job_id}")

    job = Job.query.get_or_404(job_id)
    try:
        check_job_authorization(User.query.get(job.owner))
    except PermissionError as exc:
        return forbidden(str(exc))

    return send_capture_data(job)
