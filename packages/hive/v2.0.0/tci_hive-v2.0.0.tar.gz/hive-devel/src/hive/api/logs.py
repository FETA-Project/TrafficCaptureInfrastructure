#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Logs module
===========

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Implementation of logs functionality for the API.

**Functions**

.. automethod:: app.api.jobs.get_logs()
.. automethod:: app.api.jobs.download_log(name)
"""

from os import listdir
from os.path import isfile, join

from flask import Response, current_app, g, jsonify, stream_with_context

from ..models import Permission
from . import api, log, read_file_chunks
from .errors import bad_request, forbidden


@api.route("/logs")
def get_logs() -> Response:
    """Get a list of all the logs.

    **Example response**:

    .. code-block:: json

       [
           {
               "name": "tciguilog",
           },
           {
                "name": "tciguilog.2022-01-01",
           }
       ]

    Returns:
        Response: A JSON list of all the logs.

    .. versionadded:: 1.2.0

    .. :quickref: Log; Get all logs.

    """
    log("Getting all logs")

    logs = [
        {"name": f}
        for f in listdir(current_app.config["LOG_FILE_DIR"])
        if isfile(join(current_app.config["LOG_FILE_DIR"], f))
        and current_app.config["DEFAULT_LOG_NAME"] in f
    ]

    return jsonify(logs)


@api.route("/logs/<string:name>/file")
def download_log(name: str) -> Response:
    """Download a log file.

    Args:
        name (str): The name of the log file.

    Returns:
        Response: A file stream of the log file.

    .. versionadded:: 1.2.0

    .. :quickref: Log; Download a log file.

    """
    log(f"Downloading a log file {name}")

    if not g.current_user.has_permission(Permission.VIEW_LOG):
        return forbidden("You do not have permission to view logs.")

    log_file = f"{current_app.config['LOG_FILE_DIR']}/{name}"
    if not isfile(log_file):
        return bad_request("Log file does not exist.")

    return Response(
        stream_with_context(read_file_chunks(log_file)),
        headers={"Content-Disposition": f"attachment; filename={name}"},
    )
