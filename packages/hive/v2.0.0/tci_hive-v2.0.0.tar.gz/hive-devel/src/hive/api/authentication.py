#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Authentication module
=====================

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Implementation of HTTP user authentication for the API.

**Functions**

.. automethod:: app.api.authentication.before_request()
.. automethod:: app.api.authentication.create_tokens(user)
.. automethod:: app.api.authentication.get_token()
.. automethod:: app.api.authentication.refresh_token()

"""

from datetime import timedelta
from typing import Dict, Optional

from flask import Response, current_app, g, jsonify, request
from flask_jwt_extended import (
    create_access_token,
    create_refresh_token,
    get_jwt_identity,
    jwt_required,
    verify_jwt_in_request,
)
from flask_jwt_extended.exceptions import NoAuthorizationError

from ..models import Application, User
from . import api, api_public_routes, log
from .errors import internal_error, unauthorized


@api.before_request
def before_request() -> Optional[Response]:
    """Check that the user is logged in before every request.

    Note:
        This function serves as a single point of entry for all requests
        made to the API blueprint. Because it also contains the login_required
        decorator, all requests made to the API blueprint require a logged-in
        user.

        Because the login_required is from the multi_auth object, all
        authentication methods from the mutli_auth object will be tried before
        and error is raised.

    Returns:
        Response: Doesn't return anything or unauthorized response.

    .. versionadded:: 1.2.0
    """

    if request.endpoint in api_public_routes:
        return None

    try:
        verify_jwt_in_request()
        g.current_user = User.query.get(get_jwt_identity())
    except NoAuthorizationError:
        return unauthorized("No authorization token provided.")
    except Exception:  # pylint: disable=broad-except
        _token = request.headers["Authorization"].removeprefix("Bearer ")
        app = Application.find_by_token(_token)

        if not app:
            return unauthorized("Invalid token")

        g.current_user = User.query.get(app.owner)

    if g.current_user is None:
        return internal_error("User not found")

    return None


def create_tokens(user: User) -> Dict[str, str]:
    """Create a new access and refresh token for the specified user.

    Generate JSON Web Tokens for the specified user.

    Args:
        user (User): User to create tokens for.

    Returns:
        Dict[str, str]: Dictionary containing the access and refresh tokens
            and their expiration times.

    .. versionadded:: 1.2.0
    """
    access_exp = current_app.config["API_ACCESS_TOKEN_EXPIRY_TIME"]
    access_token = create_access_token(
        identity=user.username, expires_delta=timedelta(seconds=access_exp)
    )

    refresh_exp = current_app.config["API_REFRESH_TOKEN_EXPIRY_TIME"]
    new_refresh_token = create_refresh_token(
        identity=user.username, expires_delta=timedelta(seconds=refresh_exp)
    )

    return {
        "access_token": access_token,
        "access_token_expires_in": access_exp,
        "refresh_token": new_refresh_token,
        "refresh_token_expires_in": refresh_exp,
        "identity": user.to_dict(),
    }


@api.route("/token", methods=["GET"])
def get_token() -> Response:
    """Return access and refresh tokens (see :ref:`create_tokens` for details.)

    Returns:
        Response: A response containing the access and refresh token.

    .. versionadded:: 1.2.0

    .. :quickref: Authentication; Generate access and refresh tokens.
    """
    auth = request.authorization

    if not auth:
        return unauthorized("No credentials provided.")

    if not auth.username or not auth.password:
        return unauthorized("Missing credentials.")

    try:
        user = User.login(auth.username, auth.password)
        return jsonify(create_tokens(user))
    except Exception as exc:  # pylint: disable=broad-except
        log(str(exc), log_username=False)
        if isinstance(exc, RuntimeError):
            current_app.logger.error(str(exc))

    return unauthorized("Invalid credentials.")


@api.route("/token", methods=["POST"])
@jwt_required(refresh=True)
def refresh_token() -> Response:
    """Refresh access token.

    Returns:
        Response: A response containing the access token.

    .. versionadded:: 1.2.0

    .. :quickref: Authentication; Refresh access token.
    """

    g.current_user = User.query.get(get_jwt_identity())

    if not g.current_user:
        return unauthorized("Invalid credentials.")

    return jsonify(create_tokens(g.current_user))
