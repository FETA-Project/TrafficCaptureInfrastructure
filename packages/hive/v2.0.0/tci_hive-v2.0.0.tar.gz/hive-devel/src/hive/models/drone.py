#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Drone model
===========

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>
"""

# pylint: disable=line-too-long,missing-class-docstring,no-method-argument

from enum import Enum
from random import randint
from secrets import token_urlsafe
from typing import Optional, Tuple

from werkzeug.security import check_password_hash, generate_password_hash

from . import create_database_object, delete_database_object, update_database
from .. import db, hive, models


class DroneCaptureBackend(str, Enum):
    """The possible capture types of the drone."""

    UNKNOWN = "unknown"
    TCPDUMP = "tcpdump"
    NDP = "ndp"

    @classmethod
    def _missing_(cls, _):
        return cls.UNKNOWN


class DroneStatus(str, Enum):
    """The possible states of the drones.

    .. graphviz::
        :caption: DroneStatus state diagram.

        digraph StateDiagram {
            node [style=filled];
            Created [shape=Mdiamond];

            Created -> Pending [label=" The drone was created,\n waiting for first connection."];
            Pending -> Sleeping [label=" The drone connected and\n is waiting for commands."];

            Sleeping -> Working [label=" A new capture\n command was issued."];
            Sleeping -> Disconnected [label=" Unable to communicate\n with the drone."];
            Sleeping -> Error [label=" Error on the side\n of the drone."];

            Working -> Sleeping [label=" Capture command\n finished, waiting."];
            Working -> Disconnected [label=" Unable to communicate\n with the drone."];
            Working -> Error [label=" Error on the side\n of the drone."];

            Disconnected -> Sleeping [label=" Drone reconnected,\n sleeping."];
            Disconnected -> Error [label=" Drone reconnected,\n but raised an error."];
        }
    """

    ERROR = "Error"
    PENDING = "Pending"
    SLEEPING = "Sleeping"
    WORKING = "Working"
    DISCONNECTED = "Disconnected"
    UNKNOWN = "Unknown"

    @classmethod
    def _missing_(cls, _):
        return cls.UNKNOWN


class Drone(db.Model):
    __tablename__ = "Drone"

    def generate_token() -> str:  # pylint: disable=no-method-argument
        """Generate a new authentication token for the Drone.

        Returns:
            str: The new token.

        .. versionadded:: 2.0.0
        """
        return token_urlsafe(32)

    def generate_color() -> str:
        """Generate a random color for a new drone.

        Returns:
            str: The random color, generated in the `#RRGGBB` format.

        .. versionadded:: 2.0.0
        """
        color: int = randint(0, 16_777_215)
        return f"#{color:0>6x}"

    #: The name of the drone.
    name = db.Column(
        db.String(30),
        primary_key=True,
    )

    #: The description of the drone.
    description = db.Column(
        db.Text(),
        nullable=True,
    )

    #: The access token for the drone to access the Hive.
    token_hash = db.Column(
        db.String(128),
        nullable=False,
    )

    #: A unique ID of the drone when working with SocketIO.
    socketio_id = db.Column(
        db.Text(20),
        nullable=True,
    )

    #: The capture type of the drone.
    capture_backend = db.Column(
        db.Enum(DroneCaptureBackend),
        nullable=False,
        default=DroneCaptureBackend.UNKNOWN,
    )

    #: The current status of the drone.
    status = db.Column(
        db.Enum(DroneStatus),
        nullable=False,
        default=DroneStatus.PENDING,
    )

    #: The color of the capture drone.
    color = db.Column(db.String(7), nullable=False, unique=True, default=generate_color)

    #: A relation back to the JobDroneAssociation table. Can be used to view
    #: Jobs which are using this drone, or waiting for it to be available.
    jobs = db.relationship("JobDroneAssociation", back_populates="drone")

    #: A relation to Job table, representing the currently active job.
    active_job = db.Column(
        db.Integer,
        db.ForeignKey("Job.id"),
        default=None,
    )

    #: A simple list of job IDs
    #: waiting for the drone to be available.
    job_queue = []

    def regenerate_token(self) -> str:
        """Generate a new authentication token for the drone.

        Returns:
            str: The new authentication token.

        .. versionadded:: 2.0.0
        """
        token = Drone.generate_token()
        self.token_hash = generate_password_hash(token)
        update_database()
        return token

    def to_dict(self) -> dict:
        """Convert the drone to dict.

        Returns:
            dict: The drone representation as dict.

        .. versionadded:: 2.0.0
        """
        return {
            "name": self.name,
            "description": self.description,
            "capture_backend": self.capture_backend,
            "status": self.status,
            "color": self.color,
        }

    def update_status(self, status: DroneStatus) -> None:
        """Update the status of the drone.

        Args:
            status (DroneStatus): The new status of the drone.

        .. versionadded:: 2.0.0
        """
        self.status = DroneStatus(status)
        update_database()

    def set_active_job(self, job_id: Optional[int]) -> None:
        """Set the active job of the drone.

        Args:
            job_id (Optional[int]): The ID of the job to set as active.
                                    None to clear the active job.

        .. versionadded:: 2.0.0
        """
        self.active_job = job_id
        if job_id is not None:
            self.dequeue_job(job_id)
        else:
            hive.api.start_next_job()
        update_database()

    def enqueue_job(self, job_id: int, insert_first: bool = False) -> int:
        """Add a job to the job queue.

        Args:
            job_id (int): The ID of the job to add to the queue.

        Raises:
            ValueError: If the job is already in the queue.
            ValueError: When job is not found.

        Returns:
            int: The position of the job in the queue.
                 (-1 if set as active job)

        .. versionadded:: 2.0.0
        """

        if job_id == self.active_job:
            return -1

        if job_id in self.job_queue:
            return self.job_queue.index(job_id)

        found = models.Job.query.get(job_id)
        if not found:
            raise ValueError(f"Job with ID {job_id} not found.")

        found.update_status(models.JobStatus.WAITING)

        if insert_first:
            self.job_queue.insert(0, job_id)
        else:
            self.job_queue.append(job_id)
        update_database()

        return len(self.job_queue) - 1

    def dequeue_job(self, job_id: Optional[int]) -> None:
        """Remove a job from the job queue.

        Args:
            job_id (int): The ID of the job to remove from the queue.
                If not specified, the first job in the queue will be removed.

        Raises:
            ValueError: If the job is not in the queue.
            ValueError: When no job in queue.

        .. versionadded:: 2.0.0
        """

        if not job_id:
            self.job_queue.pop(0)
        elif job_id in self.job_queue:
            self.job_queue.remove(job_id)

        update_database()
        if not self.active_job:
            hive.api.start_next_job()

    def queue_length(self) -> int:
        """Get number of jobs in job queue.

        Returns:
            int: The number of jobs in queue.

        .. versionadded:: 2.0.0
        """
        return len(self.job_queue)

    def pos_in_queue(self, job_id: int) -> int:
        """Check if job_id is in job queue

        Returns:
            int: Position in queue (-1 if not found).

        .. versionadded:: 2.0.0
        """
        if job_id in self.job_queue:
            return self.job_queue.index(job_id)

        return -1

    def first_in_queue(self) -> Optional[int]:
        """Get the first job in the queue.

        Returns:
            int: The ID of the first job in the queue or None.

        .. versionadded:: 2.0.0
        """
        if self.queue_length() == 0:
            return None

        return self.job_queue[0]

    @staticmethod
    def create(
        name: str, description: Optional[str] = None
    ) -> Tuple["Drone", str]:  # noqa: E501
        """Create a new drone.

        Args:
            name (str): The name of the drone. Must be unique and be between
                1 and 30 characters.
            description (Optional[str]): The description of the drone. Defaults
                to None.

        Raises:
            ValueError: When the drone name is not between 1 and 30 characters.
            ValueError: When the drone name is already taken.

        Returns:
            (Drone, str): A tuple of the drone instance and the authorization
                token for the created drone.

        .. versionadded:: 2.0.0
        """

        if len(name) > 30 or len(name) < 1:  # noqa: PLR2004
            raise ValueError(f'The name "{name}" is not valid.')

        exists = Drone.query.filter_by(name=name).first()
        if exists:
            raise ValueError(f'The name "{name}" is already taken.')

        token = Drone.generate_token()
        drone = Drone(
            name=name,
            description=description if description is not None else "None",
            token_hash=generate_password_hash(token),
        )
        create_database_object(drone)
        return drone, token

    @staticmethod
    def delete(name: str) -> None:
        """Delete the drone.

        Args:
            name (str): The name of the drone to delete.

        Raises:
            ValueError: When the drone to be deleted doesn't exist.

        .. versionadded:: 2.0.0
        """
        drone = Drone.query.get(name)
        if not drone:
            raise ValueError("Drone does not exist.")

        delete_database_object(drone)

    @staticmethod
    def change_color(drone_name: str, color: str) -> None:
        """Change drone color.

        Raises:
            ValueError: Drone not found.
            ValueError: Color is not in the right format (#RRGGBB).

        .. versionadded:: 2.0.0
        """

        found = Drone.query.get(drone_name)
        if not found:
            raise ValueError("Couldn't find the specified drone!")

        if not color.startswith("#") or len(color) != 7:  # noqa: PLR2004
            raise ValueError("Color must be in the format #RRGGBB!")

        try:
            int(color[1:], 16)
        except ValueError as err:
            raise ValueError("Color must be in the format #RRGGBB!") from err

        found.color = color
        update_database()

        return found

    @staticmethod
    def find_by_token(token: str) -> Optional["Drone"]:
        """Find a drone given an authorization token.

        Returns:
            Optional[Drone]: The drone instance corresponding to the token or
                None if the drone was not found.

        .. versionadded:: 2.0.0
        """
        drones = Drone.query.all()
        for drone in drones:
            if check_password_hash(drone.token_hash, token):
                return drone
        return None

    @staticmethod
    def init_drones():
        """
        Initialize drone queues from database.
        Check jobs and their status and enqueue them in the appropriate drones.

        .. versionadded:: 2.0.0
        """
        drones = Drone.query.all()
        for drone in drones:
            job_drone_assoc = models.JobDroneAssociation.query.filter_by(
                drone_name=drone.name
            ).all()  # noqa: E501
            for assoc in job_drone_assoc:
                if assoc.status == models.JobStatus.WAITING.value:
                    _ = drone.enqueue_job(assoc.job_id)
                elif assoc.status == models.JobStatus.IN_PROGRESS.value:
                    assoc.update_status(models.JobStatus.IN_PROGRESS)
                    job = models.Job.query.get(assoc.job_id)
                    if not job:
                        raise ValueError(f"Job {assoc.job_id} not found")
                    job.update_status(models.JobStatus.IN_PROGRESS)
                    drone.set_active_job(assoc.job_id)
                else:
                    pass
