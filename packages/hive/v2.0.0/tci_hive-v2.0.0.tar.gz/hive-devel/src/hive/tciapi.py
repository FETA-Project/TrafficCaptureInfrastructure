#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
TCI API module
==============

**Author**

- Lukáš Hejcman <hejcman@cesnet.cz>

**Description**

Contains the classes used for communicating with the TCI Client.
"""

import json
from typing import List

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.SecurityWarning)
urllib3.disable_warnings(urllib3.exceptions.SubjectAltNameWarning)


class TCIException(Exception):  # noqa: N818
    """TCI Exception."""

    def __init__(self, error_message: str, status_code: int = 0):
        """
        Represent a TCI exception.

        Args:
            error_message (str): The message to explain the error.
            status_code (int): The status code for the exception. By default,
                set to 0, which is a generic error code.
        """
        self.error_message = error_message
        self.status_code = status_code
        super().__init__(self.error_message)

    def __str__(self) -> str:
        """
        Create a string representation of the TCIException.

        Returns:
            str: String representation of the TCIException.
        """
        return f"Status code {self.status_code}: {self.error_message}"


class TCI:
    """Represents a TCI server to connect to."""

    def __init__(
        self,
        tci_host: str,
        tci_port: str,
        cert_path: str = None,
        ca_cert_path: str = None,
        use_tls: bool = False,
    ) -> None:
        """
        Initialize a TCI object.

        This is a wrapper around the REST API calls supported by TCI-CLI.

        Args:
            tci_host (str): The URI of the running TCI-CLI.
            tci_port (str): The port at which the TCI-CLI is listening.
            cert_path (str): The path to the certificate used for
                             connecting to the TCI-CLI. Defaults to None.
            ca_cert_path(str): The path to the CA certificate used for
                               connecting to the TCI-CLI. Defaults to None.
            use_tls(bool): Enable/Disable TLS connection via TCI API.
                           Defaults to False.
        """
        self.session = requests.Session()
        if cert_path:
            self.session.cert = cert_path
        if ca_cert_path:
            self.session.verify = ca_cert_path
        schema = "https" if use_tls is True else "http"
        self.url = f"{schema}://{tci_host}:{tci_port}"

    def __send_request(
        self, req_type: str, req_str: str, req_data: str = None, stream: bool = False
    ) -> requests.Response:
        """
        Send request to TCI-CLI.

        This is an internal function which is used to directly communicate with
        the TCI-CLI. All other function in the TCI object wrap around this
        function, and use it to send their specific request.

        Args:
            req_type (str): A HTTP request type. Supported request types
                            are GET, POST, PUT, and DELETE.
            req_str (str): The URI to which the request should be sent.
            req_data (str): Data, which should be sent to the TCI-CLI,
                            defaults to None
            stream (bool): Whether the reply from TCI-CLI should be handled as
                           a Stream (usually for large PCAP files), defaults to
                           False

        Returns:
            requests.Response: The reply from TCI-CLI. This is wrapped by a
                               TCIException if an error occurs.

        Raises:
            ValueError: Caused by an unsupported HTTP request type.
            TCIException: Caused by a return code from TCI-CLI if it is
                          other than 200 or 202.
            TCIException: Raised instead of a generic exception if
                          other error occurs.

        """
        uri = f"{self.url}{req_str}"
        try:
            if req_type == "GET":
                response = self.session.get(uri, json=req_data, stream=stream)
            elif req_type == "POST":
                response = self.session.post(uri, json=req_data)
            elif req_type == "PUT":
                response = self.session.put(uri, json=req_data)
            elif req_type == "DELETE":
                response = self.session.delete(uri, json=req_data)
            else:
                raise ValueError(f"Unknown type <{req_type}> for request <{req_str}>")

            if response.status_code not in (200, 202):
                raise TCIException(response.text, response.status_code)

            return response
        except Exception as exc:
            # raise TCIException(str(exc), 500) from exc
            raise exc

    def create_job(
        self,
        job_id: str,
        job_filter: str,
        job_type: str,
        job_duration: int,
        job_max_capture_data: int,
        job_lines: List[str],
    ) -> str:
        """
        Create a job on TCI-CLI.

        Args:
            job_id (str): The ID of the job to create. Cannot be a duplicate.
            job_filter( str): The HANIC filter for the job.
                              This function does not check its correctness.
            job_type (str): The type of the job to create.
                            Currently, only 'pcap' is supported.
            job_duration (int): The duration of the job in seconds.
            job_max_capture_data (int): The maximum amount of data to
                                        capture in Bytes.
            job_lines (List[str]): The IDs of the lines on which to capture.

        Returns:
            str: The message returned by TCI-CLI.

        Raises:
            Exception: Re-raises an exception from __send_request.

        .. versionchanged:: 1.3.2
            Send `None` as filter if the filter is an empty string.
        """
        to_send = {
            "id": job_id,
            "filter": job_filter if job_filter != "" else None,  # noqa: PLC1901
            "type": job_type,
            "duration": job_duration,
            "max_capture_data": job_max_capture_data,
            "lines": job_lines,
        }

        try:
            return self.__send_request("POST", f"/jobs/{job_id}", to_send).text
        except Exception as exc:
            raise exc

    def stop_job(self, job_id: str) -> None:
        """
        Stop a job.

        Args:
            job_id (str): The ID of the job.

        Returns:
            dict: Dictionary containing the return message and code.

        Raises:
            Exception: Re-raises an exception from __send_request.
        """
        try:
            self.__send_request("PUT", f"/jobs/{job_id}", {"id": job_id})
        except Exception as exc:
            raise exc

    def get_job_status(self, job_id: str) -> dict:
        """
        Get the status of the job.

        Args:
            job_id (str): The ID of the job.

        Returns:
            dict: Dictionary containing the job information.

        Raises:
            Exception: Re-raises an exception from __send_request.
        """
        try:
            return json.loads(
                self.__send_request("GET", f"/jobs/{job_id}", {"id": job_id}).text
            )
        except Exception as exc:
            raise exc

    def remove_job(self, job_id: str) -> None:
        """
        Remove the job from TCI-CLI.

        Args:
            job_id (str): The ID of the job.

        Returns:
            None

        Raises:
            Exception: Re-raises an exception from __send_request.
        """
        try:
            self.__send_request("DELETE", f"/jobs/{job_id}", {"id": job_id})
        except Exception as exc:
            raise exc

    def get_pcap_file(self, job_id: str) -> bytes:
        """
        Download the PCAP file from TCI-CLI.

        Args:
            job_id (str): The ID of the job.

        Returns:
            bytes: bytes object containing the contents of the PCAP file.

        Raises:
            Exception: Re-raises an exception from __send_request.
        """
        try:
            return self.__send_request(
                "GET", f"/pcaps/{job_id}", {"id": job_id}, stream=True
            ).content
        except Exception as exc:
            raise exc

    def get_jobs(self) -> dict:
        """
        Get the current jobs on TCI-CLI.

        Returns:
            dict: Dictionary containing the jobs from TCI-CLI.

        Raises:
            Exception: Re-raises an exception from __send_request.

        """
        try:
            return json.loads(self.__send_request("GET", "/jobs").text)
        except Exception as exc:
            raise exc

    def get_lines(self) -> dict:
        """
        The capture lines recognized by TCI-CLI.

        Returns:
            dict: Dictionary containing the lines and their information.

        Raises:
            Exception: Re-raises an exception from __send_request.

        """
        try:
            return json.loads(self.__send_request("GET", "/lines").text)
        except Exception as exc:
            raise exc

    def get_version(self) -> dict:
        """
        The version of the master nodes and all the slaves.

        Returns:
            dict: A dictionary in the following format ``{
                      'version': 'X.Y.Z',
                      'lines': [
                          'line1': 'X.Y.Z',
                          'line2': 'X.Y.Z'
                      ]
                  }``

        Raises:
            Exception: Re-raises an exception from __send_request.
        """
        try:
            return json.loads(self.__send_request("GET", "/version").text)
        except Exception as exc:
            raise exc

    def dev_remove_all_jobs(self) -> None:
        """
        Delete all jobs from TCI-CLI.

        Currently, unused.
        """
        jobs = self.get_jobs()
        for j in jobs["jobs"]:
            self.remove_job(j)
