#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Models module
=============

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Implements all the modules for the database.
"""

from enum import Enum
from typing import List

from flask_sqlalchemy import Model
from sqlalchemy.exc import DataError, DBAPIError, IntegrityError, SQLAlchemyError

from .. import db


class Permission(int, Enum):
    """
    An enum of the different permission categories within the TCI IS. They work
    similarly to Unix permissions, based on their binary representation.
    :ref:`MODIFY_USERS` is 0000 0001, :ref:`JOB_MASTER` is 0000 1000, etc.
    The admin authorization can do everything (0011 1111). Adding new
    permissions simply requires changing the :ref:`ADMIN` permission to a
    suitable higher number, and adding more permissions under it.
    """

    #: Allows the user to edit, add, and delete other users.
    MODIFY_USERS = 1
    #: Allows the user to edit, add, and delete authorization levels.
    MODIFY_AUTHORIZATIONS = 2
    #: Allows the user to view the system log.
    VIEW_LOG = 4
    #: Allows the user to see all other user jobs, stop them, etc.
    JOB_MASTER = 8
    #: Allows the user to upload his own scripts, and use any script.
    SCRIPT_MASTER = 16
    #: The admin can do everything.
    ADMIN = 63

    @staticmethod
    def get_permission_list(permission_code: int) -> List["Permission"]:
        """
        Convert a number to a list of permissions.

        Args:
            num (int): The number to convert.

        Returns:
            List[int]: The list of permissions.
        """
        if permission_code in [None, 0]:
            return []

        permissions = []
        for permission in Permission:
            if (permission_code & permission.value) == permission.value:
                permissions.append(permission)
        return permissions

    @staticmethod
    def deflate_permission_list(permissions: List[int]) -> int:
        """
        Convert a list of permissions to a number.

        Args:
            permissions (List[int]): The list of permissions.

        Returns:
            int: Permissions converted to a number.
        """
        num = 0
        for permission in permissions:
            num += Permission[permission].value
        return num


def create_database_object(obj: Model, commit: bool = True) -> None:
    """Create a new database object for a model and commit it.

    Args:
        obj (Model): The object that should be added.
        commit (bool, optional): Whether to commit the changes to the database
            or just flush them. Defaults to True.

    Raises:
        ValueError: On DataError or IntegrityError.
        RuntimeError: On DBAPIError or SQLAlchemyError.

    .. versionadded:: 1.2.0
    .. versionchanged:: 2.1.0
        Show the real error
    """
    try:
        db.session.add(obj)
        if commit:
            db.session.commit()
        else:
            db.session.flush()
    except (DataError, IntegrityError) as err:
        db.session.rollback()
        from flask import current_app  # pylint: disable=import-outside-toplevel

        current_app.logger.info(str(err))
        raise ValueError(f"Data object error ({str(err)})") from err
    except (DBAPIError, SQLAlchemyError) as err:
        db.session.rollback()
        raise RuntimeError(f"Database backend error ({str(err)})") from err


def delete_database_object(obj: Model, commit: bool = True) -> None:
    """Delete a database object from the database.

    Args:
        obj (Model): The database object to remove.
        commit (bool, optional): Whether to commit the changes to the database
            or just flush them. Defaults to True.

    Raises:
        RuntimeError: On IntegrityError, DBAPIError, or SQLAlchemyError.

    .. versionadded:: 1.2.0
    .. versionchanged:: 2.1.0
        Show the real error
    """
    try:
        db.session.delete(obj)
        if commit:
            db.session.commit()
        else:
            db.session.flush()
    except (IntegrityError, DBAPIError, SQLAlchemyError) as err:
        raise RuntimeError(f"Database backend error ({str(err)})") from err


def update_database() -> None:
    """Update an object in the database.

    This method wraps a commit() command. Used always instead of a bare
    db.session.commit() call.

    Raises:
        ValueError: On DataError or IntegrityError.
        RuntimeError: On DBAPIError or SQLAlchemyError.

    .. versionadded:: 1.2.0
    .. versionchanged:: 2.1.0
        Show the real error
    """
    try:
        db.session.commit()
    except (DataError, IntegrityError) as err:
        db.session.rollback()
        raise ValueError(f"Data object error ({str(err)})") from err
    except (DBAPIError, SQLAlchemyError) as err:
        db.session.rollback()
        raise RuntimeError(f"Database backend error ({str(err)})") from err


from .application import Application  # noqa: E402,F401
from .authorization_level import AuthorizationLevel, Permission  # noqa: E402,F401
from .drone import Drone, DroneStatus, DroneCaptureBackend, DronePriority  # noqa: E402,F401
from .job_drone_assoc import JobDroneAssociation  # noqa: E402,F401
from .job import Job, JobStatus  # noqa: E402,F401
from .script import Script, ScriptType  # noqa: E402,F401
from .user import User  # noqa: E402,F401
from .destination import Destination  # noqa: E402,F401
