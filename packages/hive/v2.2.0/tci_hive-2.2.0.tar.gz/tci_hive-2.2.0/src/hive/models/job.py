#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# pylint: disable=redefined-builtin,no-method-argument

"""
Job model
=========

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>
"""
import contextlib
import os
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, List, Optional

from flask import current_app
from humanize import naturalsize, precisedelta
from sqlalchemy.exc import DataError, DBAPIError, IntegrityError, SQLAlchemyError

from .. import db, hive, pcap_script
from ..convert import set_local_tz
from . import (
    Permission,
    create_database_object,
    delete_database_object,
    update_database,
)
from .drone import Drone, DronePriority
from .job_drone_assoc import JobDroneAssociation
from .script import Script
from .user import User
from .destination import Destination


class JobStatus(str, Enum):
    """Represent all the different states that a job can have."""

    DONE = "Done"
    MOVED = "Done - Files moved"
    CAPTURED = "Captured"
    UPLOADING = "Uploading data"
    COLLECTING = "Collecting data"
    FAILED = "Failed"
    WAITING = "Waiting"
    STOPPED = "Stopped"
    UNKNOWN = "Unknown"
    DANGLING = "Dangling"
    TO_PROCESS = "To process"
    PROCESSING = "Processing"
    IN_PROGRESS = "In progress"
    IN_QUEUE = "In queue"
    PAUSED = "Paused"
    ARCHIVED = "Archived"

    @classmethod
    def _missing_(self, _: Any):
        return self.UNKNOWN


class Job(db.Model):
    """Represent a single capture job."""

    __tablename__ = "Job"

    #: The ID of the job. This is used in the TCI backend as the unique
    #: identifier of the job (its name in tci-cli).
    id = db.Column(db.Integer, primary_key=True)

    #: The owner of the job.
    owner = db.Column(db.String(20), db.ForeignKey("User.username"), nullable=False)

    #: The name of the capture job.
    name = db.Column(db.String(1000), nullable=False)

    #: The filter which is used for filtering the captured traffic.
    filter = db.Column(db.Text(), nullable=False, default="all")

    #: The duration of the capture in seconds. This is the maximum capture
    #: time, and the job can be stopped sooner if the maximum capture data
    #: quota is fullfilled.
    duration = db.Column(db.BigInteger, nullable=False)

    #: The maximum amount of data to capture in bytes. This is the maximum
    #: amount of data to capture, and if the maximum duration of the job is
    #: reached first, the job stops without fulfilling this quota.
    max_capture_data = db.Column(db.BigInteger, nullable=False)

    #: The last known status of the job.
    status = db.Column(db.String(20), nullable=False)

    #: A more detailed message regarding the job status.
    status_msg = db.Column(db.String(100))

    #: The time at which the capture of the job began. This is different from
    #: the time the job was created, as the job usually waits idly for the TCI
    #: backend to start capturing, or for the requested drone to be ready.
    #: Format 'YYYY-MM-DD HH:MM:SS' -> 19 chars
    start_time = db.Column(db.String(19))

    #: The time at which the job stopped capturing.
    #: Format 'YYYY-MM-DD HH:MM:SS' -> 19 chars
    end_time = db.Column(db.String(19))

    #: Remaining duration of the job when paused.
    #: Format 'YYYY-MM-DD HH:MM:SS' -> 19 chars
    paused_duration = db.Column(db.BigInteger, nullable=False, default=0)

    #: The maximum amount of data to capture in bytes when paused.
    paused_max_capture_data = db.Column(db.BigInteger, nullable=False, default=0)

    #: The name (or path?) of the PCAP file that was downloaded from the TCI
    #: backend for this job.
    output_file = db.Column(db.String(50))

    #: The name of the script to use.
    script_name = db.Column(db.String(20), db.ForeignKey("Script.name"))

    #: The arguments to launch the script with.
    script_args = db.Column(db.String(50))

    #: A destination id to which the job is associated.
    destination_id = db.Column(db.Integer, db.ForeignKey("Destination.id"))

    #: A priority for the job capture.
    priority = db.Column(db.Integer, nullable=False, default=DronePriority.NORMAL)

    #: How many bytes to trim while capturing with NDP backend.
    ndp_trim_bytes = db.Column(db.BigInteger, nullable=False, default=0)

    #: Whether to capture traffic on all DMA channels with NDP backend.
    ndp_capture_all = db.Column(db.Boolean, nullable=False, default=False)

    #: A many-to-many relation between the capture jobs and capture drones.
    drones = db.relationship("JobDroneAssociation", back_populates="job")

    #: A many-to-one relation between the script for this job, as many jobs
    #: can use a single script.
    script = db.relationship("Script", back_populates="jobs")

    #: The time at which the job was deleted/archived.
    #: Format 'YYYY-MM-DD HH:MM:SS' -> 19 chars
    archived_at = db.Column(db.String(19))

    @property
    def captured_data(self) -> int:
        """Return the amount of data captured by all the drones in this job.

        Returns:
            int: The amount of data captured by all the drones in this job.

        .. versionadded:: 2.0.0
        """
        captured = 0

        for job_drone_assoc in self.drones:
            captured += int(job_drone_assoc.captured_data)

        return captured

    def to_dict(self) -> dict:
        """Return a dictionary representation of the object.

        Returns:
            dict: A dictionary representation of the object.

        .. versionadded:: 1.2.0
        .. versionchanged:: 2.0.0
            Added the ``captured_data`` field.
            Added the ``destination_id`` field.
        .. versionchanged:: 2.1.0
            Add fields for paused parameters, priority, and extra arguments for NDP capture.

        .. todo::
            * Add support for ``processing_q`` in the :ref:`status` field.
        """
        return {
            "id": self.id,
            "owner": self.owner,
            "name": self.name,
            "filter": self.filter,
            "duration": self.duration,
            "duration_human": precisedelta(self.duration),
            "max_capture_data": self.max_capture_data,
            "max_capture_data_human": naturalsize(self.max_capture_data),
            "paused_duration": self.paused_duration,
            "paused_max_capture_data": self.paused_max_capture_data,
            "status": self.status,
            "status_msg": self.status_msg,
            "start_time": set_local_tz(self.start_time),
            "end_time": set_local_tz(self.end_time),
            "script_args": self.script_args,
            "script_name": self.script_name,
            "captured_data": self.captured_data,
            "captured_data_human": naturalsize(self.captured_data),
            "destination_id": self.destination_id,
            "priority": self.priority,
            "ndp_trim_bytes": self.ndp_trim_bytes,
            "ndp_capture_all": self.ndp_capture_all,
            "drones": [
                {
                    "name": jobDroneAsoc.drone.name,
                    "color": jobDroneAsoc.drone.color,
                    "description": jobDroneAsoc.drone.description,
                    "capture_backend": jobDroneAsoc.drone.capture_backend,
                    "captured_data": jobDroneAsoc.captured_data,
                    "captured_data_human": naturalsize(jobDroneAsoc.captured_data),
                    "status": jobDroneAsoc.status,
                    "status_msg": jobDroneAsoc.status_msg,
                }
                for jobDroneAsoc in self.drones
            ],
            "archived_at": self.archived_at,
        }

    def __str__(self) -> str:
        """Return a string representation of the object.

        Work as a wrapper around to_dict().

        Returns:
            str: A string representation of the object.

        .. versionadded:: 1.0.0

        .. versionchanged:: 1.2.0
            Works as a wrapper for :ref:`to_dict`.
        """
        return str(self.to_dict())

    def move(self) -> None:
        """Move job files to specified destination.

        .. versionadded:: 2.0.0
        """
        if self.destination_id is None:
            return

        dest = Destination.query.get(self.destination_id)
        if dest is None:
            raise ValueError(
                f"Destination with id {self.destination_id} does not exist."
            )

        file = pcap_script.get_output_file(
            self.id, pcap_script.raw_extensions + ["zip"]
        )

        if file is None:
            return

        dest.send(file)
        self.update_status(
            JobStatus.MOVED,
            f"File moved to custom destination {dest.name} ({dest.path})",
        )

    def update_status(self, status: JobStatus, msg: Optional[str] = None) -> None:
        """Update the status of the job.

        Args:
            status (JobStatus): The new status of the job.
        """
        self.status = JobStatus(status)
        self.status_msg = msg if msg else ""
        update_database()

    def init_time(self) -> None:
        """Initialize the start and end time of the job.

        .. versionadded:: 2.0.0
        """
        start_time = datetime.utcnow()
        end_time = start_time + timedelta(seconds=self.duration)

        self.start_time = start_time.isoformat(sep=" ", timespec="seconds")
        self.end_time = end_time.isoformat(sep=" ", timespec="seconds")

        update_database()

    def pause(self, duration: int, max_capture_data: int) -> None:
        """Set paused arguments for the job.

        Args:
            duration (int): The duration of the paused job.
            max_capture_data (int): The maximum amount of data to capture.

        .. versionadded:: 2.1.0
        """
        self.status = JobStatus.PAUSED
        self.paused_duration = duration
        self.paused_max_capture_data = max_capture_data
        update_database()

    def resume(self) -> None:
        """Update endtime when resuming a job.

        .. versionadded:: 2.1.0
        """
        self.end_time = (datetime.utcnow() + timedelta(seconds=self.paused_duration)).isoformat(sep=" ", timespec="seconds")
        update_database()

    @staticmethod
    def create(
        owner: str,
        name: str,
        filter: str,
        duration: int,
        max_capture_data: int,
        drones: List[str],
        script_name: Optional[str] = None,
        script_args: Optional[str] = None,
        destination_id: Optional[int] = None,
        priority: Optional[DronePriority] = DronePriority.NORMAL,
        ndp_trim_bytes: Optional[int] = 0,
        ndp_capture_all: Optional[bool] = False,
    ) -> "Job":
        """Create a new capture job and send it to TCI.

        Args:
            owner (str): The username of the job owner.
            name (str): The name of the job.
            filter (str): The capture filter to use for the job.
            duration (int): The time in seconds the job should run for.
            max_capture_data (int): The maximum amount of data to capture
                (in bytes).
            drones (List[str]): The names of the drones which should be
                used for capturing the data.
            script_name (str): The name of the script to use for the job. Can
                be ``None`` for script masters. Defaults to ``None``.
            script_args (str): The arguments with which to launch the script.
                Can be ``None`` for script masters. Defaults to ``None``.
            priority (DronePriority): The priority of the job. Defaults to ``NORMAL``.
            ndp_trim_bytes (int): The number of bytes to trim from the beginning of the capture (when using NDP).
            ndp_capture_all (bool): Whether to capture all traffic (when using NDP)

        Raises:
            ValueError: When the specified owner can't be found.
            ValueError: When the specified script can't be found.
            PermissionError: When the specified user doesn't have privileges to
                use the specified script file.
            ValueError: When no drones are specified.
            ValueError: When a specified drone can't be found.
            ValueError: When the duration is an invalid number.
            ValueError: When the max_capture_data is an invalid number.
            ValueError: On errors when adding the job to the database due to
                integrity or data errors.
            RuntimeError: On errors when adding the job to the database due to
                DB API or SQLAlchemy errors.
            RuntimeError: When creating the job with TCI causes an error.
            ValueError: On problems with commiting to the database.
            RuntimeError: On problems with commiting to the database.

        Returns:
            Job: The newly created job.

        .. versionadded:: 1.2.0
        .. versionchanged:: 2.1.0
            Added extra arguments for NDP capture and priority of a job.
        .. versionchanged:: 2.1.1
            Permit ndp_trim_bytes to be 0.

        .. important::
            Requires a working connection to TCI!
        """
        # Checking the owner
        user = User.query.get(owner)
        if not user:
            raise ValueError("The specified owner couldn't be found!")

        # Checking the script
        if not user.has_permission(Permission.SCRIPT_MASTER):
            _check_script(script_name, user)

        # Checking the drones
        drones_list = _get_drones(drones)

        # Checking the duration
        if duration <= 0:
            raise ValueError("The duration must be a natural number!")

        # Checking the max capture data
        if max_capture_data <= 0:
            raise ValueError("Max_capture_data must be a natural number!")

        if destination_id is not None:
            dest = Destination.query.get(destination_id)
            if not dest:
                raise ValueError("Destination does not exist.")

        # Checking the trim bytes value
        if ndp_trim_bytes < 0:
            raise ValueError("ndp_trim_bytes must be a positive number!")

        job = Job(
            owner=user.username,
            name=name,
            filter=filter,
            duration=duration,
            max_capture_data=max_capture_data,
            status="Unknown",
            script_args=script_args,
            script_name=script_name,
            destination_id=destination_id,
            priority=priority,
            ndp_trim_bytes=ndp_trim_bytes,
            ndp_capture_all=ndp_capture_all,
        )
        for drone in drones_list:
            job_drone_assoc = JobDroneAssociation()
            job_drone_assoc.drone = drone
            job.drones.append(job_drone_assoc)

        create_database_object(job, commit=False)

        try:
            hive.api.start_job(
                job_id=job.id,
                job_filter=job.filter,
                duration=job.duration,
                max_capture_data=job.max_capture_data,
                drones=[assoc.drone.name for assoc in job.drones],
                priority=job.priority,
                ndp_trim_bytes=ndp_trim_bytes,
                ndp_capture_all=ndp_capture_all
            )
        except ValueError:
            print(f"Job {job.id} is queued")
            job.status = JobStatus.IN_QUEUE

        try:
            db.session.commit()
        except (DataError, IntegrityError) as err:
            raise ValueError(str(err)) from err
        except (DBAPIError, SQLAlchemyError) as err:
            raise RuntimeError(str(err)) from err

        return job

    @staticmethod
    def stop(job_id: int) -> None:
        """Stops the job.

        Args:
            job_id (int): The ID of the job to stop.

        Raises:
            ValueError: When the specified job can't be found.
            RuntimeError: On communication problems with the TCI backend.
            RuntimeError: On problems when updating the job status in the DB.

        .. versionadded:: 1.2.0

        .. admonition:: TCI Connection required!

        .. todo::
            Implement a custom Hive exception.
        """

        found = Job.query.get(job_id)
        if not found:
            raise ValueError("The specified job couldn't be found!")

        try:
            hive.api.stop_job(found)
        except Exception as exc:
            raise RuntimeError(f"TCI Exception: {str(exc)}") from exc

        found.status = "Stopped"

        update_database()

    @staticmethod
    def delete(job_id: int) -> None:
        """Delete a job.

        Args:
            job_id (int): The ID of the job to delete.

        Raises:
            ValueError: When the specified job can't be found.
            AssertionError: When the job is still running.
            RuntimeError: Raised on modifying the job in the DB.
            RuntimeError: Raised during a TCIException.
            RuntimeError: On problems with commiting to the database.

        .. versionchanged:: 2.2.0
            Stop deleting job from database, set it as history instead.

        .. important::
            Requires a working connection to TCI!

        .. todo::
            Implement a custom Hive exception.
        """

        found = Job.query.get(job_id)
        if not found:
            raise ValueError("Couldn't find the specified job!")

        if found.status == "Running":
            raise AssertionError("The job is still running!")

        _delete_job_files(found)

        try:
            if found.status != JobStatus.DANGLING:
                hive.api.delete_job(found)
        except Exception as exc:
            db.session.rollback()
            raise RuntimeError(f"TCI Exception: {str(exc)}") from exc

        # for asoc in found.drones:
        #     delete_database_object(
        #         JobDroneAssociation.query.get((job_id, asoc.drone_name))
        #     )

        found.status = JobStatus.ARCHIVED
        found.archived_at = datetime.utcnow().isoformat(sep=" ", timespec="seconds")
        db.session.add(found)
        # delete_database_object(found, commit=False)

        try:
            db.session.commit()
        except (DBAPIError, SQLAlchemyError) as err:
            raise RuntimeError(str(err)) from err


    @staticmethod
    def delete_from_history(job_id: int) -> None:
        """Delete a job from the history.

        Args:
            job_id (int): The ID of the job to delete.

        Raises:
            ValueError: When the specified job can't be found.
            ValueError: When the specified job is not in history.

        .. versionadded:: 2.2.0
        """

        found = Job.query.get(job_id)
        if not found:
            raise ValueError("Couldn't find the specified job!")

        if found.status != JobStatus.ARCHIVED:
            raise ValueError("The specified job is still active and not in history!")

        try:
            for asoc in found.drones:
                delete_database_object(
                    JobDroneAssociation.query.get((job_id, asoc.drone_name))
                )
            delete_database_object(found, commit=False)
            db.session.commit()
        except Exception as exc:
            db.session.rollback()
            raise RuntimeError(f"TCI Exception: {str(exc)}") from exc


def _check_script(script_name: str, user: User) -> None:
    """
    Check permissions for the script with the specified name.

    Args:
        script_name (str): The name of the script.
        user (User): The user who is requesting the script.

    Raises:
        ValueError: When the script can't be found.
        PermissionError: When the user doesn't have sufficient permissions.
    """
    script = Script.query.get(script_name)
    if not script:
        raise ValueError("The specified script couldn't be found!")
    if script.authorization_level < user.authorization_level:
        raise PermissionError("The owner needs higher privileges to use that script!")


def _get_drones(drones: List[str]) -> List[Drone]:
    """
    Get the drones from the database.

    Args:
        drones (List[str]): The drones to get.

    Returns:
        List['Drone']: The drones from the database.

    Raises:
        ValueError: When the drones list is empty.
        ValueError: When the drone can't be found.
    """
    if len(drones) == 0:
        raise ValueError("At least one drone must be specified!")

    drones_list = []
    for drone_name in drones:
        tmp = Drone.query.get(drone_name)
        if not tmp:
            raise ValueError(f'The specified drone "{drone_name}" couldn\'t be found!')
        drones_list.append(tmp)

    return drones_list


def _delete_job_files(job: Job) -> None:
    """
    Delete all job files.
    """

    # delete raw and processed output files if they exists
    while file := pcap_script.get_output_file(
        job.id, extensions=pcap_script.raw_extensions + ["zip"]
    ):
        with contextlib.suppress(FileNotFoundError, TypeError):
            os.remove(file)

    # delete potencial unmerged files
    for file in [
        os.path.join(current_app.config["PCAP_FOLDER"], f"{job.id}-{drone_name}.pcap")
        for drone_name in [assoc.drone_name for assoc in job.drones]
    ]:
        with contextlib.suppress(FileNotFoundError, TypeError):
            os.remove(file)
