#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Destination model
=================

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>
"""

import os
import shutil
from typing import Optional

from .. import db
from . import create_database_object, delete_database_object, update_database
from .user import User


class Destination(db.Model):
    """Represent a single user destination."""

    __tablename__ = "Destination"

    #: The ID of the destination.
    id = db.Column(db.Integer, primary_key=True)
    #: The name of the destination.
    name = db.Column(db.String(30), nullable=False)
    #: The owner of the destination.
    owner = db.Column(db.String(20), db.ForeignKey("User.username"), nullable=False)
    #: The path of the destination.
    path = db.Column(db.String(128), nullable=False)

    def to_dict(self) -> dict:
        """Return a dictionary representation of the object.

        Returns:
            dict: A dictionary representation of the object.

        .. versionadded:: 1.3.0
        """
        return {
            "id": self.id,
            "owner": self.owner,
            "name": self.name,
            "path": self.path,
        }

    def __str__(self) -> str:
        """Return a string representation of the object.

        Work as a wrapper around to_dict().

        Returns:
            str: A string representation of the object.

        .. versionadded:: 1.3.0
        """
        return str(self.to_dict())

    def send(self, filepath: str) -> None:
        """Move file from its current location to the destinations location

        Args:
            filepath (str) -> the current filepath.

        Returns:
            the new filepath.
        """
        try:
            self.check_path(self.path)
            shutil.move(filepath, self.path)
        except ValueError as err:
            raise ValueError(
                f"Cannot send file to destination: {err}.\n"
                "File will stay in its default location."
            ) from err

    @staticmethod
    def check_path(path: str) -> None:
        """Check if path is usable, throw exception otherwise.

        Args:
            path (str): Path to check.

        Raises:
            ValueError: If path does not exist.
            ValueError: If path is not a directory.
            ValueError: If app does not have permissions.

        .. versionadded:: 2.0.0
        """

        if not os.path.exists(path):
            raise ValueError(f"Path {path} does not exist.")

        if not os.path.isdir(path):
            raise ValueError(f"Path {path} is not a directory.")

        if not os.access(path, os.R_OK | os.W_OK):
            raise ValueError(f"Cannot use path {path}, wrong permissions.")

    @staticmethod
    def create(
        name: str,
        owner: str,
        path: str,
    ) -> "Destination":
        """Create a new destination.

        Args:
            name (str): The name of the destination.
            owner (str): The owner of the destination.

        Returns:
            (Destination, str): Tuple containing created dest and its token.

        .. versionadded:: 2.0.0
        """
        user = User.query.get(owner)
        if not user:
            raise ValueError("User does not exist.")

        Destination.check_path(path)

        dest = Destination(
            name=name,
            owner=owner,
            path=path,
        )

        create_database_object(dest)

        return dest

    @staticmethod
    def edit(
        id: int,
        name: Optional[str] = None,
        path: Optional[str] = None,
    ) -> "Destination":
        """Edit the destination specified by ``id``.

        When an argument is ``None``, that particular attribute of the user
        will not be changed.

        Args:
            id (int): The id of the destination to edit.
            name (str, optional): The new name, defaults to None.
            path (str, optional): The new path, defaults to None.

        Raises:
            ValueError: Invalid destination, not found.

        Returns:
            Destination: The edited destination object.

        .. versionadded:: 2.0.0
        """
        dest = Destination.query.get(id)
        if dest is None:
            raise ValueError(f"Destination {id} not found.")

        if name is not None:
            dest.name = name

        if path is not None:
            Destination.check_path(path)
            dest.path = path

        update_database()

        return dest

    @staticmethod
    def delete(dest_id: int) -> None:
        """Delete an destination.

        Args:
            dest_id (int): The ID of the destination.

        .. versionadded:: 2.0.0
        """
        dest = Destination.query.get(dest_id)
        if not dest:
            raise ValueError("Destination does not exist.")

        delete_database_object(dest)
