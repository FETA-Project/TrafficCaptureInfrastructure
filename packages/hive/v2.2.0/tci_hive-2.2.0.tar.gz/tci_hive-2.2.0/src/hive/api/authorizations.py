#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Authorizations module
=====================

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Implements authorization functionality for the API.

**Functions**

.. automethod:: app.api.authorizations.get_authorizations()
.. automethod:: app.api.authorizations.get_authorization_info()
.. automethod:: app.api.authorizations.get_permissions()
.. automethod:: app.api.authorizations.new_authorization()
.. automethod:: app.api.authorizations.edit_authorization(id)
.. automethod:: app.api.authorizations.delete_authorization(id)
"""
from flask import Response, g, jsonify, request
from flask_expects_json import expects_json

from ..decorators import permission_required
from ..models import AuthorizationLevel, Permission
from . import Schemas, api, log
from .errors import bad_request, forbidden, internal_error

# from sqlalchemy.exc import SQLAlchemyError


@api.route("/authorizations")
def get_authorizations() -> Response:
    """Get all the authorization levels.

    **Example response**:

    .. code-block:: json

       [
           {
               "name": "Foo",
               "level": 123,
               "permission": 0
           },
           {
               "name": "Bar",
               "level": 321,
               "permission": 63
           }
       ]

    Returns:
        Response: A JSON containing the list of all the authorizations.

    .. versionadded:: 1.2.0

    .. :quickref: Authorization; Get all authorizations.
    """
    # log("Getting all authorizations.", debug=True)
    auths = AuthorizationLevel.query.order_by(AuthorizationLevel.level).all()
    return jsonify([auth.to_dict() for auth in auths])


@api.route("/authorizations/<int:authorization_id>")
def get_authorization_info(authorization_id: int) -> Response:
    """Get detailed info about specific authorization level.

    **Example response**:

    .. code-block:: json

       {
           "name": "Foo",
           "level": 123,
           "permission": 0
       }

    Args:
        authorization_id (int): ID of the authorization level.

    Returns:
        Response: A JSON containing the authorization info.

    .. versionadded:: 1.2.0

    .. :quickref: Authorization; Get detailed authorization info.
    """
    # log(f"Getting info about authorization {authorization_id}.", debug=True)
    auth = AuthorizationLevel.query.get_or_404(authorization_id)
    return jsonify(auth.to_dict())


@api.route("/authorizations/permissions")
def get_permissions() -> Response:
    """Get all the permissions.

    **Example response**:

    .. code-block:: json

       [
           {
               "name": "Foo",
               "value": 1
           },
           {
               "name": "Bar",
               "value": 2
           }
       ]

    Returns:
        Response: A JSON containing the list of all the permissions.

    .. versionadded:: 1.2.0

    .. :quickref: Authorization; Get all permissions.
    """
    # log("Getting all permissions.", debug=True)
    return jsonify(
        [
            {
                "name": perm.name,
                "value": int(perm),
            }
            for perm in Permission
            if perm != Permission.ADMIN
        ]
    )


@api.route("/authorizations", methods=["POST"])
@expects_json(Schemas.new_authorization_schema)
@permission_required(Permission.MODIFY_AUTHORIZATIONS)
def new_authorization() -> Response:
    """Create a new authorization.

    **Example request**:

    .. code-block:: json

       {
           "name": "NAME",
           "level": 123,
           "permissions": 63
       }

    Returns:
        Response: Created authorization as JSON or Error message.

    .. versionadded:: 1.2.0

    .. :quickref: Authorization; Create a new authorization.

    .. todo::
       Don't allow creating a permission with a predefined permission number.
       Force users to add permissions manually.
    """

    log(f"Creating a new authorization {request.json['name']}")

    if request.json["level"] < g.current_user.authorization_level:
        return forbidden(
            "Can't create an authorization with a higher level than yourself!"
        )

    try:
        auth = AuthorizationLevel.create(
            level=request.json["level"],
            name=request.json["name"],
            permissions=request.json["permissions"],
        )
    except ValueError as err:
        return bad_request(str(err))

    return jsonify(auth.to_dict())


@api.route("/authorizations/<int:authorization_id>", methods=["PUT"])
@expects_json(Schemas.edit_authorization_schema)
@permission_required(Permission.MODIFY_AUTHORIZATIONS)
def edit_authorization(authorization_id: int) -> Response:
    """Edit an existing authorization.

    If trying to edit an authorization that doesn't exist, raise 404.
    If level is in the request and it is not the same as the one in the DB,
    raise 400.

    **Example request**:

    .. code-block:: json

       {
           "name": "NEW_NAME",
           "permissions": 2
       }

    Args:
        authorization_id (int): The ID of the authorization to edit.

    Returns:
        Response: The newly edited authorization as JSON.

    .. versionadded:: 1.2.0

    .. :quickref: Authorization; Edit an authorization.

    .. todo::
       This should not be the correct way to edit authorization permissions.
       See the ``TODO`` in :func:`edit_authorization`.
    """
    if "level" in request.json:
        return bad_request("Can't edit authorization level number.")

    log(f"Editing the authorization with ID {authorization_id}")

    if authorization_id < g.current_user.authorization_level:
        return forbidden("You can't edit higher authorization levels.")

    name = None
    if "name" in request.json:
        name = request.json["name"]

    permissions = None
    if "permissions" in request.json:
        permissions = request.json["permissions"]

    for perm in Permission.get_permission_list(permissions):
        if not g.current_user.has_permission(perm):
            return forbidden(f'You don\'t have "{perm.name}" permission.')

    try:
        auth = AuthorizationLevel.edit(authorization_id, name, permissions)
    except ValueError as err:
        return bad_request(str(err))

    return jsonify(auth.to_dict())


@api.route("/authorizations/<int:authorization_id>", methods=["DELETE"])
@permission_required(Permission.MODIFY_AUTHORIZATIONS)
def delete_authorization(authorization_id: int) -> Response:
    """Delete an authorization.

    Args:
        authorization_id (int): The ID of the authorization to remove.

    Returns:
        Response: Status code or error message.

    .. versionadded:: 1.2.0

    .. :quickref: Authorization; Delete an authorization.
    """
    log(f"Deleting the authorization with ID {authorization_id}")

    if authorization_id < g.current_user.authorization_level:
        return forbidden("You can't delete higher authorization levels.")

    try:
        AuthorizationLevel.delete(authorization_id)
    except ValueError as err:
        return bad_request(str(err))
    except RuntimeError as err:
        return internal_error(str(err))

    return Response(status=204)
