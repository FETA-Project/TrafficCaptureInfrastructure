#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Scripts module
==============

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Implementation of script functionality for the API.

**Functions**

.. automethod:: app.api.scripts.get_scripts()
.. automethod:: app.api.scripts.create_script(name)
.. automethod:: app.api.scripts.download_script(name)
.. automethod:: app.api.scripts.delete_script(name)
"""

import base64

from flask import Response, g, jsonify, request
from flask_expects_json import expects_json

from ..decorators import permission_required
from ..models import Permission, Script
from . import Schemas, api, log
from .errors import bad_request, internal_error


@api.route("/scripts")
def get_scripts() -> Response:
    """Get all the scripts.

    **Example response**:

    .. code-block:: json

       [
           {
               "name": "foo",
               "description": "foodesc",
               "authorization": {
                   "level": 12,
                   "name": "Auth12"
               }
           }
       ]

    Returns:
        Response: A list of all the scripts.

    .. versionadded:: 1.2.0
    .. versionchanged:: 1.3.2
        Added script descriptions into the request.

    .. :quickref: Script; Get all scripts.
    """
    # log("Getting all scripts", debug=True)
    scripts = Script.query.order_by(Script.name).all()

    return jsonify(
        [
            script.to_dict()
            for script in scripts
            if g.current_user.authorization_level <= script.authorization_level
            and script.name != "None"
        ]
    )


@api.route("/scripts/<string:name>")
@permission_required(Permission.SCRIPT_MASTER)
def get_detailed_script_info(name: str) -> Response:
    """Get detailed script info.

    Args:
        name (str): The name of the script.

    Returns:
        File: A JSON with specific script info.

    .. versionadded:: 1.2.0

    .. :quickref: Script; Download a script.

    """
    # log(f"Getting info about script {name}", debug=True)

    found = Script.query.get(name)
    if not found:
        return bad_request("The script was not found!")

    return jsonify(found.to_dict())


@api.route("/scripts/<string:name>/file")
@permission_required(Permission.SCRIPT_MASTER)
def download_script(name: str) -> Response:
    """Download the script.

    Args:
        name (str): The name of the script to download.

    Returns:
        File: The contents of the script file encoded with Base64.

    .. versionadded:: 1.2.0

    .. :quickref: Script; Download a script.

    """
    log(f"Downloading the script {name}")

    found = Script.query.get(name)
    if not found:
        return bad_request("The script was not found!")

    return jsonify(
        {
            "filetype": found.filetype,
            "file": base64.b64encode(found.file_contents).decode("utf-8"),
        }
    )


@api.route("/scripts", methods=["POST"])
@expects_json(Schemas.new_script_schema)
@permission_required(Permission.SCRIPT_MASTER)
def create_script() -> Response:
    """Create a new script.

    The file should be sent as a Base64 encoded string. In the example request,
    the file contains only the line ``echo("This is a test script")``.

    **Example request**:

    .. code-block:: json

       {
           "name": "NewTestScript",
           "description": "FooBar",
           "authorization_level": 123,
           "file_contents": "ZWNobygiVGhpcyBpcyBhIHRlc3Qgc2NyaXB0Iik="
       }

    Returns:
        Response: Error message or the created script as JSON.

    .. versionadded:: 1.2.0
    .. versionchanged:: 1.3.2
        Added script descriptions.

    .. :quickref: Script; Create a new script.

    """
    log("Creating a script")

    try:
        script = Script.create(
            name=request.json.get("name"),
            description=request.json.get("description"),
            authorization_level=request.json.get("authorization_level"),
            file_contents=base64.b64decode(request.json.get("file_contents")).decode(
                "utf-8"
            ),
        )
    except ValueError as err:
        return bad_request(str(err))
    except RuntimeError as err:
        return internal_error(str(err))

    return jsonify(script.to_dict())


@api.route("/scripts/<string:script_name>", methods=["DELETE"])
@permission_required(Permission.SCRIPT_MASTER)
def delete_script(script_name: str) -> Response:
    """Delete a script.

    Args:
        script_name (str): The name of the script to delete.

    Returns:
        Response: Status code.

    .. versionadded:: 1.2.0

    .. :quickref: Script; Delete a script.
    """
    log(f"Deleting the script {script_name}")

    try:
        Script.delete(script_name)
    except ValueError as err:
        return bad_request(str(err))
    except RuntimeError as err:
        return internal_error(str(err))

    return Response(status=204)
