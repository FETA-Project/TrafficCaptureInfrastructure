#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
HIVE API
===========

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Implementation of API for the HIVE part of the app.

**Functions**

.. automethod:: app.hive.api.merge_pcaps(base_folder, job_id, drone_names)
.. automethod:: app.hive.api.get_file(job)
.. automethod:: app.hive.api.start_job(job)
.. automethod:: app.hive.api.stop_job(job)
.. automethod:: app.hive.api.delete_job(job)
.. automethod:: app.hive.api._get_drones(drones)
.. automethod:: app.hive.api.start_next_job(last_job)
.. automethod:: app.hive.api._dequeue_job(drones, job_id)
"""

import contextlib
from datetime import datetime, timedelta
import json
import os
import subprocess
from os import path, remove
from typing import List, Optional
from flask import current_app

from ..models import Drone, DroneStatus, DronePriority, Job, JobDroneAssociation, JobStatus
from . import log, sio


def merge_pcaps(base_folder: str, job_id: int, drone_names: List[str]) -> str:
    """
    Merge multiple pcaps of a specific job into one.

    Args:
        base_folder (str): Folder with pcaps to merge.
        job_id (int): Job id.
        drone_names (List[str]): List of drone names.

    Returns:
        str: Path of the merged pcap file

    Raises:
        ValueError: When the process did finish with non-zero return code.

    .. versionadded:: 2.0.0
    .. versionchanged:: 2.0.1
    """
    log(f"Merging pcaps for job {job_id}")

    pcaps_in = [
        path.join(base_folder, f"{job_id}-{drone_name}.pcap")
        for drone_name in drone_names
    ]
    for drone_name in drone_names:
        pcap = path.join(base_folder, f"{job_id}-{drone_name}.pcap")
        if path.getsize(pcap) == 0:
            os.remove(pcap)
        if (
            not path.isfile(pcap)
            and Drone.query.get(drone_name).status == DroneStatus.DISCONNECTED
        ):
            pcaps_in.remove(pcap)

    pcap_out = path.join(base_folder, f"{job_id}.pcap")

    args = [current_app.config["MERGECAP_BIN"], "-w", pcap_out]
    args.extend(pcaps_in)

    with subprocess.Popen(
        args,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    ) as process:
        res = process.communicate()

        if process.returncode != 0:
            raise ValueError(res[1].decode("utf-8"))  # STDERR

    for pcap in pcaps_in:
        with contextlib.suppress(FileNotFoundError, TypeError):
            remove(pcap)

    return pcap_out


def update_drones(drones: List[Drone]) -> None:
    """
    Update info from drones.

    Args:
        drones (List[Drone]): List of drones.

    .. versionadded:: 2.0.1
    """
    sio.emit("update_info", to=[drone.socketio_id for drone in drones])


def get_file(job: Job) -> None:
    """
    Download job file from drones.

    Args:
        job (Job): The job to get file from.

    Raises:
        ValueError: When there are no drones in job.

    .. versionadded:: 2.0.0
    .. versionchanged:: 2.1.1
    """
    if job.status in (JobStatus.UPLOADING, JobStatus.COLLECTING, JobStatus.DONE):
        return

    log(f"Getting files for job {job.id}")

    drones = get_drones([drone.drone_name for drone in job.drones])
    if not drones:
        raise ValueError("No drones in job.")

    for drone in drones:
        job_drone_asoc = JobDroneAssociation.query.filter_by(
            job_id=job.id,
            drone_name=drone.name,
        ).first()
        if job_drone_asoc.status in (JobStatus.UPLOADING.value, JobStatus.DONE.value):
            drones.remove(drone)  # pylint: disable=modified-iterating-list
        else:
            job_drone_asoc.update_status(JobStatus.UPLOADING, "Uploading data.")

    job.update_status(JobStatus.UPLOADING, "Uploading data from drones.")

    sio.emit(
        "get_chunk",
        json.dumps({"chunk_number": 1, "job_id": job.id}),
        to=[drone.socketio_id for drone in drones],
    )


def start_job(
    job_id: int,
    job_filter: str,
    duration: int,
    max_capture_data: int,
    drones: List[str],
    priority: Optional[DronePriority] = DronePriority.NORMAL,
    ndp_trim_bytes: Optional[int] = 0,
    ndp_capture_all: Optional[bool] = False,
) -> None:
    """Start a job on drones.

    Args:
        job_id (int): The id of the job to start.
        job_filter (str): The capture filter.
        duration (int): Max duration of capture.
        max_capture_data (int): Max capture data.
        drones (List[str]): The list of drone names to start the job on.

    Raises:
        ValueError: When there are no drones.
        ValueError: When job is not first in queue.

    .. versionadded:: 2.0.0
    .. versionchanged:: 2.1.0
        Add extra arguments for NDP capture and priority of a job.
    """
    log(f"Starting job {job_id} on drones {drones} with priority {priority}")
    if len(drones) == 0:
        raise ValueError("No drones selected.")

    drones_list = get_drones(drones)

    must_wait = []
    for drone in drones_list:
        drone.enqueue_job(job_id, priority)
        if priority == DronePriority.CRITICAL and drone.active_job is not None:
            to_pause = Job.query.get(drone.active_job)
            pause_job(to_pause)
            break
        elif priority == DronePriority.PAUSED:
            job = Job.query.get(job_id)
            job.resume()
            break
        must_wait.append(
            drone.status != DroneStatus.SLEEPING
            or (drone.active_job is not None or job_id != drone.first_in_queue())
        )

    if True in must_wait:
        log(f"Job {job_id} must wait.")
        raise ValueError("Job is not first in queue.")

    for drone in drones_list:
        drone.set_active_job(job_id)

    job = Job.query.get(job_id)
    job.init_time()
    job.update_status(JobStatus.IN_PROGRESS, "Job in progress.")

    sio.emit(
        "start_job",
        json.dumps(
            {
                "job_id": job_id,
                "filter": job_filter,
                "duration": duration,
                "max_capture_data": max_capture_data,
                "ndp_trim_bytes": ndp_trim_bytes,
                "ndp_capture_all": ndp_capture_all,
                "priority": priority,
            }
        ),
        to=[drone.socketio_id for drone in drones_list],
    )


def pause_job(job: Job) -> None:
    """Pause a job on drones (because of a critical job).

    Args:
        job (Job): The job to pause.

    .. versionadded:: 2.1.0
    """

    log(f"Pausing a job {job.id}")

    drones = get_drones([drone.drone_name for drone in job.drones])

    sio.emit(
        "pause_job",
        json.dumps({"job_id": job.id}),
        to=[drone.socketio_id for drone in drones],
    )

    for drone in drones:
        drone.pause_job(job.id)

    # set paused data
    paused_duration = datetime.utcnow() - datetime.fromisoformat(job.start_time)
    paused_max_capture_data = job.max_capture_data - job.captured_data
    job.pause(int(paused_duration.total_seconds()), paused_max_capture_data)
    start_next_job()


def stop_job(job: Job) -> None:
    """Stop the job capture on drones.

    Args:
        job (Job): The job to stop capturing.

    .. versionadded:: 2.0.0
    .. versionchanged:: 2.1.0
        Add support for pausing a job.
    .. versionchanged:: 2.1.1
        Emit "stop_job" only on drones, that dont have stopped job.
    """
    log(f"Stopping job {job.id}")
    drones = get_drones([drone.drone_name for drone in job.drones])
    if not drones:
        job.update_status(JobStatus.DANGLING, "Job is not running on any drones.")
        return

    drones_to_stop = []
    for drone in drones:
        assoc = JobDroneAssociation.query.get((job.id, drone.name))
        if assoc.status not in (JobStatus.COLLECTING.value, JobStatus.STOPPED.value, JobStatus.PAUSED.value):
            drones_to_stop.append(drone)

    sio.emit(
        "stop_job",
        json.dumps({"job_id": job.id}),
        to=[drone.socketio_id for drone in drones_to_stop],
    )

    if job.status != JobStatus.PAUSED:
        dequeue_job(drones, job.id)
        job.update_status(JobStatus.COLLECTING, "Job stopped by user.")
    else:
        job.update_status(JobStatus.PAUSED, "Job paused by critical job.")


def delete_job(job: Job) -> None:
    """Delete the job on drones.

    Args:
        job (Job): The job to delete.

    .. versionadded:: 2.0.0
    """
    log(f"Deleting job {job.id}")
    drones = get_drones([drone.drone_name for drone in job.drones])
    if not drones:
        job.update_status(JobStatus.DANGLING, "Job is not running on any drones.")
        return

    sio.emit(
        "delete_job",
        json.dumps({"job_id": job.id}),
        to=[drone.socketio_id for drone in drones],
    )

    dequeue_job(drones, job.id)


def get_drones(drones: List[str]) -> List[Drone]:
    """
    Get the drones from the database.

    Args:
        drones (List[str]): The drones to get.

    Returns:
        List['Drone']: The drones from the database.

    Raises:
        ValueError: When the drones list is empty.
        ValueError: When the drone can't be found.

    .. versionadded:: 2.0.0
    """
    if len(drones) == 0:
        raise ValueError("At least one drone must be specified!")

    drones_list = []
    for drone_name in drones:
        tmp = Drone.query.get(drone_name)
        if not tmp:
            raise ValueError(f'The specified drone "{drone_name}" couldn\'t be found!')
        drones_list.append(tmp)

    return drones_list


def start_next_job(last_job: Optional[Job] = None) -> None:
    """Start the next job in queue.

    Args:
        last_job (Optional[Job]): The last job to check for available drones.
            If None check all drones.

    .. versionadded:: 2.0.0
    .. versionchanged:: 2.1.0
        Add support for pausing a job.
    """
    log("Starting next job in queue.")

    if last_job and last_job.stauts != JobStatus.PAUSED:
        drones = get_drones([asoc.drone_name for asoc in last_job.drones])
        dequeue_job(drones, last_job.id)

    all_drones = Drone.query.all()

    log("start next")
    for drone in all_drones:
        next_id = drone.first_in_queue()
        if not next_id:
            continue

        next_job = Job.query.get(next_id)
        if not next_job:
            drone.dequeue_job(next_id)
            continue

        try:
            start_job(
                job_id=next_job.id,
                job_filter=next_job.filter,
                duration=next_job.duration,
                max_capture_data=next_job.max_capture_data,
                drones=[asoc.drone_name for asoc in next_job.drones],
            )
            log(f"Job {next_job.id} started.")
            return
        except ValueError as exc:
            log(f"Job {next_job.id} not started." f"Reason: {exc}")


def dequeue_job(drones: List[Drone], job_id: int) -> None:
    """Dequeue the job on drones.

    Args:
        drones (List[Drone]): List of drones where to dequeue the job.
        job_id (int): The id of the job to dequeue

    .. versionadded:: 2.0.0
    """
    for drone in drones:
        if drone.active_job == job_id:
            drone.set_active_job(None)
        else:
            drone.dequeue_job(job_id)


def force_disconnect(drones: List[Drone]) -> None:
    sio.emit(
        "force_disconnect",
        to=[drone.socketio_id for drone in drones],
    )
