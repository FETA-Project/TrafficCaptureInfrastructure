#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Decorators module
=================

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Implements decorators used for permission checking within the app.
"""

from functools import wraps
from typing import Union

from flask import abort, g

from .models import Permission


def permission_required(permission: Union[Permission, int]):
    """
    Decorator for requiring permissions.

    Args:
      permission (Union[Permission, int]): Authorization level
    """

    def decorator(func):
        @wraps(func)
        def decorated_function(*args, **kwargs):
            try:
                if not g.current_user.has_permission(permission):
                    abort(403)
            except Exception:  # pylint: disable=broad-except
                abort(403)
            return func(*args, **kwargs)

        return decorated_function

    return decorator
