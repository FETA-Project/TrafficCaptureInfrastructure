#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
HIVE package
===========

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Contains the implementation of the HIVE part of the app.
Provides the communication between the web app and the drones.
"""

from flask import current_app, Blueprint
from .. import db, sio  # noqa: F401

hive_blueprint = Blueprint("hive", __name__)


def log(msg: str, debug: bool = False) -> None:
    """Create a new log message for the current user.

    Args:
        msg (str): The message to be logged.

    .. versionadded:: 2.0.0
    .. versionchanged:: 2.0.1
    """
    logger = current_app.logger.debug if debug else current_app.logger.info

    logger(f"HIVE - {msg}")


class Schemas:
    """Contains the definitions of the expected JSON formats for SIO endpoints.

    These formats are based on the JSON Schema version 7, which can be found
    here: https://json-schema.org/understanding-json-schema/index.html
    """

    # JSON Schema for SIO endpoint connect
    drone_auth_schema = {
        "type": "object",
        "properties": {
            "token": {"type": "string"},
        },
        "required": ["token"],
    }

    # JSON Schema for SIO endpoint drone_init
    capture_backend_schema = {
        "type": "object",
        "properties": {
            "capture_backend": {"type": "string"},
        },
        "required": ["capture_backend"],
    }

    # JSON Schema for SIO endpoint upload_chunk
    upload_info_schema = {
        "type": "object",
        "properties": {
            "chunk_number": {"type": "integer"},
            "chunk_bytes": {},  # NOTE: maybe should be base64 string?
            "job_id": {"type": "integer"},
            "total_number_of_chunks": {"type": "integer"},
        },
        "required": ["chunk_number", "chunk_bytes", "job_id", "total_number_of_chunks"],
    }

    # JSON Schema for SIO endpoint on_drone_update_status
    drone_info_schema = {
        "type": "object",
        "properties": {
            "status": {"type": "string"},
            "active_job": {
                "id": {"type": "integer"},
                "captured": {"type": "integer"},
                "status": {"type": "string"},
                "status_msg": {"type": "string"},
            },
        },
        "required": ["status"],
    }

    # JSON Schema for SIO endpoint job_update
    job_info_schema = {
        "type": "object",
        "properties": {
            "id": {"type": "integer"},
            "status": {"type": "string"},
            "status_msg": {"type": "string"},
        },
        "required": ["id", "status"],
    }


from . import endpoints, api  # noqa: F401,E401,E402
