#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
HIVE ENDPOINTS
===========

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Implementation of socketio endpoints for the HIVE part of the app.

**Functions**

.. automethod:: app.hive.endpoints.on_drone_connect(data)
.. automethod:: app.hive.endpoints.on_drone_init(capture_backend)
.. automethod:: app.hive.endpoints.on_drone_disconnect()
.. automethod:: app.hive.endpoints.upload_chunk(upload_info)
.. automethod:: app.hive.endpoints.on_drone_update_status(drone_info)
.. automethod:: app.hive.endpoints._stop_job(job)
.. automethod:: app.hive.endpoints.on_job_update(job)
.. automethod:: app.hive.endpoints.on_error_default(data)
"""

import json
from base64 import b64decode
from datetime import datetime
from os import path
from typing import Tuple

import jsonschema
from flask import current_app, request

from ..models import (
    Drone,
    DroneCaptureBackend,
    DroneStatus,
    Job,
    JobDroneAssociation,
    JobStatus,
    update_database,
)
from . import Schemas, api, log, sio


@sio.on("connect")
def on_drone_connect(data: dict) -> Tuple[int, str]:
    """Handle a new drone connection.

    Args:
        data (dict): The authentication message sent by the drone.

    .. versionadded:: 2.0.0
    """
    log(f'A new drone with SID "{request.sid}" connected.')

    # Validate the authentication message. If the message is not valid,
    # the drone is disconnected.
    try:
        jsonschema.validate(instance=data, schema=Schemas.drone_auth_schema)
    except jsonschema.ValidationError:
        log(
            "A drone attempted to connect with an invalid authentication "
            f"header {data}"
        )
        return 400, "Invalid authentication header."

    # Check if the drone exists in the database. If it does, update
    # its socketio_id.
    drone = Drone.find_by_token(data.get("token"))
    if drone is not None:
        log(f"Updating the SID of existing drone {drone.name}")
        drone.socketio_id = request.sid
        # drone.status = DroneStatus.PENDING
        update_database()
    else:
        log(
            "Unable to find a drone with token "
            f"\"{data.get('token')}\" in the DB, rejecting connection."
        )
        return 400, "Invalid token."
    return 200, "OK."


@sio.on("drone_init")
def on_drone_init(jsondata: str) -> bool:
    """Init the drone on hive.

    Args:
        jsondata: The capture backend used by the drone.

    .. versionadded:: 2.0.0
    """
    try:
        data = json.loads(jsondata)
        jsonschema.validate(instance=data, schema=Schemas.capture_backend_schema)
    except (jsonschema.ValidationError, json.decoder.JSONDecodeError):
        log(
            "A drone attempted to initialize with an invalid capture backend "
            f"{jsondata}"
        )
        return False

    current_app.logger.debug(Drone.query.first().to_dict())

    drone = Drone.query.filter_by(socketio_id=request.sid).first()
    if drone is None:
        log(
            f"A drone (with socketio id: {request.sid}) "
            "attempted to initialize without being authenticated."
        )
        return False

    drone.capture_backend = DroneCaptureBackend(data["capture_backend"])

    log(f"Drone init - name {drone.name}, backend {drone.capture_backend}")
    update_database()
    return True


@sio.on("disconnect")
def on_drone_disconnect() -> None:
    """Handle a drone disconnect event.

    Set the socketio_id to None and set the status to Disconnected.

    .. versionadded:: 2.0.0
    """
    drone = Drone.query.filter_by(socketio_id=request.sid).first()
    log(
        f'Drone "{drone.name}" with SID "{request.sid}" disconnected, '
        "updating the database object."
    )
    drone.socketio_id = None
    drone.status = DroneStatus.DISCONNECTED
    update_database()


@sio.on("upload")
def upload_chunk(jsondata: str) -> Tuple[int, str]:  # pylint: disable=too-many-branches
    """
    Ask for all chunks of specified file on drone
    until its downloaded completely.
    Event is invoked by drone uploading chunk of file.

    ** Example data **

    .. code-block:: json
        {
            "chunk_number": 1,
            "chunk_bytes": content_in_bytes,
            "job_id": 42,
            "total_number_of_chunks": 1000
        }

    Args:
        data: Information about the upload.

    Returns:
        int, str: Return code and
            error message when there is a problem with upload
            or success message when the whole file has been uploaded.

    .. versionadded:: 2.0.0
    .. versionchanged:: 2.0.1
    .. versionchanged:: 2.1.1
        Dequeue job if all uploaded.
    """
    try:
        data = json.loads(jsondata)
        jsonschema.validate(instance=data, schema=Schemas.upload_info_schema)
    except (jsonschema.ValidationError, json.decoder.JSONDecodeError):
        log("A drone attempted to upload a chunk with an invalid header " f"{jsondata}")
        return 400, "Invalid upload header"

    log("A drone attempted to upload a chunk")

    chunk_number = data["chunk_number"]
    chunk_bytes = b64decode(data["chunk_bytes"].encode("utf-8"))
    job_id = data["job_id"]
    total_number_of_chunks = data["total_number_of_chunks"]

    job = Job.query.get(job_id)
    if job is None:
        log(f"JOB ERROR: Job {job_id} not found.")
        return 400, f"Invalid job id {job_id}"

    job_drone_assoc = JobDroneAssociation.query.filter_by(
        job_id=job_id,
        drone_name=Drone.query.filter_by(socketio_id=request.sid).first().name,
    ).first()

    mode = "ab"
    if chunk_number == 1:
        mode = "wb"
        log(f'Started uploading job "{job_id}"')

    filepath = path.join(
        current_app.config["PCAP_FOLDER"], f"{job_id}-{job_drone_assoc.drone_name}.pcap"
    )

    try:
        with open(filepath, mode) as file:
            progress = int((chunk_number / total_number_of_chunks) * 100)
            job_drone_assoc.update_status(
                JobStatus.UPLOADING, f"Uploading data - [{progress:02d}%]."
            )
            file.write(chunk_bytes)
            file.flush()
            if progress == 100:  # noqa: PLR2004
                job_drone_assoc.update_status(JobStatus.DONE, "Data Uploaded.")

                # check if job on all drones is done
                all_uploaded = False
                for assoc in job.drones:
                    if (
                        assoc.status != JobStatus.DONE
                        and assoc.drone.status != DroneStatus.DISCONNECTED
                    ):
                        break
                else:
                    all_uploaded = True

                if all_uploaded:
                    api.dequeue_job(
                        api.get_drones([asoc.drone_name for asoc in job.drones]),
                        job.id,
                    )
                    job.update_status(
                        JobStatus.UPLOADING, "Data uploaded. Merging files."
                    )
                    api.merge_pcaps(
                        base_folder=current_app.config["PCAP_FOLDER"],
                        job_id=job_id,
                        drone_names=[asoc.drone_name for asoc in job.drones],
                    )
                    if job.script_name is not None:
                        job.update_status(
                            JobStatus.TO_PROCESS,
                            "Data uploaded. Waiting for processing.",
                        )
                    else:
                        job.update_status(JobStatus.DONE, "Data uploaded.")
                        job.move()
    except Exception as exc:  # pylint: disable=broad-except
        msg = f"Error writing chunk {chunk_number} " f'of file for job "{job_id}": '
        if isinstance(exc, OSError):
            msg += f"OSError({exc.errno}): {exc.strerror}"
        else:
            msg += str(exc)
        log(msg)
        return 400, job_id

    if progress == 100:  # noqa: PLR2004
        log(f'Finished uploading job "{job_id}"')
        return 200, job_id

    sio.emit(
        "get_chunk",
        json.dumps({"chunk_number": chunk_number + 1, "job_id": job_id}),
        to=request.sid,
    )
    return 202, job_id


@sio.on("drone_update_status")
def on_drone_update_status(jsondata: str) -> tuple[int, str]:
    """Update drone status in database.
        And check hive constraints of its active job.

    ** Example data **

    .. code-block:: json

        {
            status: "Capturing",
            active_job: {
                id: 42,
                captured: 256,
                status: "In progress",
                status_msg: "Capturing data - [50%].",
            }
        }

    Args:
        jsondata: The drone current status and its active job.

    .. versionadded:: 2.0.0
    .. versionchanged:: 2.0.1
    """

    try:
        data = json.loads(jsondata)
        jsonschema.validate(instance=data, schema=Schemas.drone_info_schema)
    except (jsonschema.ValidationError, json.decoder.JSONDecodeError):
        log(
            "A drone attempted to update its status with an invalid header "
            f"{jsondata}"
        )
        return 400, "Invalid update status header"

    status = data["status"]
    active_job = None
    if "active_job" in data and data["active_job"] != {}:
        active_job = {
            "id": data["active_job"]["id"],
            "captured": data["active_job"]["captured"],
            "status": data["active_job"]["status"],
            "status_msg": data["active_job"]["status_msg"],
        }

    drone = Drone.query.filter_by(socketio_id=request.sid).first()
    try:
        if drone:
            log(f"Drone {drone.name} changed status to {status}.")
            drone.update_status(status)
    except ValueError:
        log(f"Drone {drone.name} sent an invalid status change request: " f"{status}")
        drone.update_status(DroneStatus.ERROR)

    if active_job:
        job = Job.query.get(active_job["id"])
        job_drone_assoc = JobDroneAssociation.query.filter_by(
            job_id=job.id, drone_name=drone.name
        ).first()
        if job_drone_assoc and job:
            job_drone_assoc.captured_data = active_job.get("captured")
            job_drone_assoc.update_status(
                active_job.get("status"), active_job.get("status_msg")
            )

            time_now = datetime.utcnow().isoformat(sep=" ", timespec="seconds")

            # constraints from hive
            if job.captured_data >= job.max_capture_data or time_now >= job.end_time:
                _stop_job(job)

    if drone.status == DroneStatus.SLEEPING:
        api.start_next_job()
    return 200, "Status updated."


def _stop_job(job: Job) -> None:
    """Stop job on drones and dequeue on hive.

    Args:
        job (Job): The job to stop.

    .. versionadded:: 2.0.0
    """
    drones = api.get_drones([asoc.drone_name for asoc in job.drones])
    sio.emit(
        "stop_job",
        json.dumps({"job_id": job.id}),
        to=[drone.socketio_id for drone in drones],
    )
    api.dequeue_job(drones, job.id)


@sio.on("job_update")
def on_job_update(jsondata: str) -> tuple[int, str]:
    """Update job status from drone in database.
        Check the job status and start the next capture or get captured file.

    ** Example data **

    .. code-block:: json

        {
            id: 42,
            status: "Capturing",
            status_msg: "Capturing data - [50%].",
        }

    Args:
        data: Dictionary representing the job.

    .. versionadded:: 2.0.0
    .. versionchanged:: 2.1.0
        Add support for pausing a job.
    """

    try:
        data = json.loads(jsondata)
        jsonschema.validate(instance=data, schema=Schemas.job_info_schema)
    except (jsonschema.ValidationError, json.decoder.JSONDecodeError):
        log("A drone attempted to update a job with an invalid header " f"{jsondata}")
        return 400, "Invalid update job header"

    job_id = data["id"]
    status = data["status"]
    status_msg = data.get("status_msg", None)
    captured = data.get("captured")

    found = Job.query.get(job_id)
    if not found:
        log(f"Job with id {job_id} not found.")
        return 400, "Job not found"

    found_assoc = JobDroneAssociation.query.filter_by(
        job_id=found.id,
        drone_name=Drone.query.filter_by(socketio_id=request.sid).first().name,
    ).first()

    if found_assoc.status != JobStatus.UPLOADING:
        found_assoc.update_status(status, status_msg)

    found_assoc.captured_data = captured
    # TODO: include the possibility of a job failing on drone
    if found_assoc.status in (JobStatus.STOPPED, JobStatus.CAPTURED):
        for assoc in found.drones:
            if assoc.status != found_assoc.status:
                break
        else:
            found.update_status(found_assoc.status)

    if found.status == JobStatus.FAILED:
        api.start_next_job(found)
    elif found.status in (JobStatus.CAPTURED, JobStatus.STOPPED):
        log(f"Getting job {found.id} file")
        api.get_file(found)
    elif found.status == JobStatus.PAUSED:
        api.start_next_job()
    return 200, "Updated job."


@sio.on_error_default
def on_error_default(data: dict) -> None:
    """Log an error message.

    Args:
        data: Data coming from a drone.

    .. versionadded:: 2.0.0
    """
    current_app.logger.error(str(data))
