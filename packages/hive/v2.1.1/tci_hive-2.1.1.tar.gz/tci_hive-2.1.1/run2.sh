#!/bin/sh

HOST=0.0.0.0
PORT=8080
THREADS=8

gunicorn -k eventlet -w 1 --threads $THREADS tcigui:app -b $HOST:$PORT
