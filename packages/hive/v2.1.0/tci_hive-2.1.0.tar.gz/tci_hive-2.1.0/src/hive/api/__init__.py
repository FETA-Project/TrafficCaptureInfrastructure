#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
API package
===========

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Contains the implementation of the API part of the web app.
"""

from typing import Generator
from flask import Blueprint, current_app, g

api = Blueprint("api", __name__)
api_public_routes = ["api.get_token", "api.refresh_token", "api.get_file"]


def log(msg: str, log_username: bool = True, debug: bool = False) -> None:
    """Create a new log message for the current user.

    Args:
        msg (str): The message to be logged.
        log_username (bool): Whether to log the current user Username. Defaults to True.

    .. versionadded:: 1.2.0
    .. versionchanged:: 2.0.1
    """
    logger = current_app.logger.debug if debug else current_app.logger.info

    if log_username:
        logger(f"API - USER {g.current_user.username} - {msg}")
    else:
        logger(f"API - PUBLIC - {msg}")


def read_file_chunks(path: str) -> Generator:
    """Read a file in chunks.

    Used for streaming large files.

    Args:

    """
    chunk_size = 8192
    with open(path, "rb") as file:
        while 1:
            buf = file.read(chunk_size)
            if buf:
                yield buf
            else:
                break


class Schemas:
    """Contains the definitions of the expected JSON formats for API endpoints.

    These formats are based on the JSON Schema version 7, which can be found
    here: https://json-schema.org/understanding-json-schema/index.html
    """

    #: dict: JSON Schema for POST /application
    new_application = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
        },
        "required": ["name"],
    }

    #: dict: JSON schema for POST /authorizations
    new_authorization_schema = {
        "type": "object",
        "properties": {
            "level": {"type": "integer"},
            "name": {"type": "string"},
            "permissions": {"type": "integer"},
        },
        "required": ["level", "name", "permissions"],
    }

    #: dict: JSON schema for PUT /authorizations/<int:id>
    edit_authorization_schema = {
        "type": "object",
        "properties": {"name": {"type": "string"}, "permissions": {"type": "integer"}},
    }

    #: dict: JSON schema for POST /destinations
    new_destination_schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "path": {"type": "string"},
        },
        "required": ["name", "path"],
    }

    #: dict: JSON schema for PUT /destinations/<int:id>
    edit_destination_schema = {
        "type": "object",
        "properties": {"name": {"type": "string"}, "path": {"type": "string"}},
    }

    new_drone_schema = {
        "type": "object",
        "properties": {"name": {"type": "string"}, "description": {"type": "string"}},
    }

    """JSON schema for PATH /drone/<string:drone_name>"""
    edit_drone_color_schema = {
        "type": "object",
        "properties": {"color": {"type": "string"}},
        "required": ["color"],
    }

    #: dict: JSON schema for POST /jobs
    new_job_schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "filter": {"type": "string"},
            "duration": {"type": "integer", "minimum": 1},
            "max_capture_data": {"type": "integer", "minimum": 1},
            "script_name": {"type": ["string", "null"]},
            "script_args": {"type": ["string", "null"]},
            "drones": {"type": "array", "items": {"type": "string"}},
            "destination_id": {"type": "integer"},
            "priority": {"type": "integer"},
        },
        "required": ["name", "filter", "duration", "max_capture_data", "drones"],
    }

    #: dict: JSON schema for PUT /jobs
    edit_job_schema = {
        "type": "object",
        "properties": {"action": {"type": "string"}},
        "required": ["action"],
    }

    #: dict: JSON schema for POST /users
    new_user_schema = {
        "type": "object",
        "properties": {
            "username": {"type": "string"},
            "email": {"type": "string"},
            "authorization_level": {"type": "integer", "minimum": 1},
            "password": {"type": "string"},
        },
        "required": ["username", "email", "password"],
    }

    #: dict: JSON schema for PUT /users/<string:username>
    edit_user_schema = {
        "type": "object",
        "properties": {"email": {"type": "string"}, "password": {"type": "string"}},
    }

    #: dict: JSON schema for POST /scripts
    new_script_schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "description": {"type": ["string", "null"]},
            "authorization_level": {"type": "integer", "minimum": 1},
            "file_contents": {
                "type": "string",
                "contentMediaType": "text",
                "contentEncoding": "base64",
            },
        },
        "required": ["name", "authorization_level", "file_contents"],
    }


from . import (  # noqa: E402, F401
    applications,
    authentication,
    authorizations,
    drones,
    errors,
    jobs,
    logs,
    scripts,
    users,
    destinations,
)
