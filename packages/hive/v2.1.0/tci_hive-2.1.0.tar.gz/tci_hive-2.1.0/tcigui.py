#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# pylint: disable=import-outside-toplevel, too-many-branches, unused-import

"""
TCIGUIModule
============

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

The main entry point for the Flask application.
"""

import os
import sys
import ssl

import click
from flask import send_from_directory
from flask_migrate import Migrate, stamp, upgrade
from sqlalchemy.exc import OperationalError
from werkzeug.exceptions import NotFound

COV = None
if os.environ.get("FLASK_COVERAGE"):
    import coverage

    COV = coverage.coverage(branch=True, include="app/*")
    COV.start()


from src.hive import (
    create_app,
    db,
    hive,
)  # noqa: E402,F401 pylint: disable=unused-import

app = create_app(os.environ.get("FLASK_CONFIG") or "default")
migrate = Migrate(app, db)


@app.before_first_request
def init_drone_queues():
    """Prepare the drone queues."""
    from src.hive.models import Drone

    app.logger.info("Initializing drone queues")
    Drone.init_drones()


@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def route_path(path):
    """Route paths to angular static files"""
    try:
        return send_from_directory("static", path)
    except NotFound:
        return send_from_directory("static", "index.html")


@app.cli.command("test", help="Run unit tests and generate coverage info.")
@click.argument("test_cases", nargs=-1)
@click.option("--html/--no-html", default=False)
@click.option("--xml/--no-xml", default=False)
def test(test_cases, html, xml):
    """Run unittests.

    Args:
        test_cases (List[str]): The dotted names of the tests that should run.
                                More info here:
                                https://docs.python.org/3/library/unittest.html
                                #unittest.TestLoader.loadTestsFromName"
        html (bool): Whether to output a HTML Coverage report.
        xml (bool): Whether to output a JUnit XML Coverage report.
    """
    import subprocess

    if not os.environ.get("FLASK_COVERAGE"):
        os.environ["FLASK_COVERAGE"] = "1"
        sys.exit(subprocess.call(sys.argv))

    import unittest

    if xml:
        import xmlrunner
    if html:
        from HTMLTestRunner.runner import HTMLTestRunner

    if xml:
        # Running the tests
        if test_cases:
            discovered = unittest.TestLoader().loadTestsFromNames(test_cases)
        else:
            discovered = unittest.TestLoader().discover("tests")
        with open("tests.xml", "wb") as output_file:
            xmlrunner.XMLTestRunner(output=output_file).run(discovered)

    if html:
        # Running the tests
        if test_cases:
            discovered = unittest.TestLoader().loadTestsFromNames(test_cases)
        else:
            discovered = unittest.TestLoader().discover("tests")
        HTMLTestRunner(
            title="TCI Test Suite",
            description="A test suite of the TCI IS.",
            tested_by="Gitlab CI",
            add_traceback=True,
            log=False,
            output="test_report",
        ).run(discovered)

    if not xml and not html:
        # Running the tests
        if test_cases:
            discovered = unittest.TestLoader().loadTestsFromNames(test_cases)
        else:
            discovered = unittest.TestLoader().discover("tests")
        unittest.TextTestRunner(verbosity=2).run(discovered)

    if COV:
        COV.stop()
        COV.save()
        # Outputting the report
        try:
            if html:
                COV.html_report(directory="coverage_report")
            if xml:
                COV.xml_report()
            COV.report(show_missing=True)
        except coverage.misc.CoverageException as exc:
            sys.exit(str(exc))


def create_dirs():
    """Create necessary directories for running hive.

    .. versionadded:: 2.0.2
    """

    for directory in (
        app.config["PCAP_FOLDER"],
        app.config["TMP_FOLDER"],
        app.config["LOG_DIR"],
    ):
        try:
            app.logger.log(f"Making sure folder {directory} exists.")
            os.makedirs(directory, exist_ok=True)
        except OSError as err:
            app.logger.error(f"Could not create folder {directory}: {str(err)}")
            sys.exit(-1)


@app.cli.command("deploy", help="Setup the app to be ready for deployment.")
def deploy():
    """Setup the application for deployment.

    Setup attempts to upgrade the database to the latest migration version. If this
    upgrade fails, stamp the database so that it can be used. Furthermore, create the
    administrator authorization level and account. Also create the System account.
    """

    # Database migration
    try:
        app.logger.info("Attempting to upgrade the database...")
        upgrade()
    except OperationalError:
        app.logger.warning(
            "The database probably doesn't need upgrading, "
            "accepting its current revision..."
        )
        stamp()

    # Insert admin users and authorizations
    from src.hive.models import AuthorizationLevel, User  # noqa: E402

    _ = AuthorizationLevel.insert_authorizations()
    _ = User.insert_users()


if __name__ == "__main__":
    ssl_context = None

    if not app.config["INSECURE"]:
        ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
        ssl_context.verify_mode = ssl.CERT_REQUIRED
        try:
            ssl_context.load_verify_locations(app.config["CA_CERT"])
            ssl_context.load_cert_chain(app.config["CERT"])
        except FileNotFoundError as exc:
            app.logger.error(f"Unable to load TLS certificates: {exc}")
            sys.exit(1)

    create_dirs()

    app.run(
        host=app.config["HOST"],
        port=app.config["PORT"],
        threaded=app.config["THREADED"],
        use_reloader=False,
        ssl_context=ssl_context,
    )
