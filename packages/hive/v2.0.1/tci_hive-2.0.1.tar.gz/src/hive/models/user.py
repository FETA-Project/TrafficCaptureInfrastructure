#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
User model
==========

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>
"""

from typing import List, Union

from flask import current_app
from flask_login import UserMixin
from ldap3 import ALL, Connection, Server
from ldap3.core.exceptions import LDAPBindError
from werkzeug.security import generate_password_hash, check_password_hash

from .. import db, jwt
from . import (
    Permission,
    create_database_object,
    delete_database_object,
    update_database,
)
from .authorization_level import AuthorizationLevel


class User(UserMixin, db.Model):
    """Represent a single user."""

    __tablename__ = "User"

    #: The username of the user.
    #: .. versionadded:: 1.0.0
    username = db.Column(db.String(20), primary_key=True)
    #: The email of the user.
    #: .. versionadded:: 1.0.0
    email = db.Column(db.String(70), unique=True, nullable=False)
    #: The authorization level of the user.
    #: .. versionadded:: 1.0.0
    authorization_level = db.Column(
        db.Integer, db.ForeignKey("AuthorizationLevel.level"), nullable=False
    )
    #: The password of the user.
    #: .. versionadded:: 1.0.0
    password_hash = db.Column(db.String(128), default=None)
    #: Whether the user was created using an LDAP connection.
    #: .. versionadded:: 1.2.0
    uses_ldap = db.Column(db.Boolean, nullable=False, default=False)

    #: int: The minimum acceptable length of a user password.
    MIN_PASSWORD_LENGTH: int = 8
    #: int: The maximum acceptable length of a user password.
    MAX_PASSWORD_LENGTH: int = 500

    def to_dict(self) -> dict:
        """Return a dictionary representation of the object.

        Returns:
            dict: A dictionary representation of the object.

        .. versionadded:: 1.2.0
        """
        return {
            "username": self.username,
            "email": self.email,
            "authorization_level": self.authorization_level,
        }

    def __str__(self) -> str:
        """Return a string representation of the object.

        Work as a wrapper around to_dict().

        Returns:
            str: A string representation of the object.

        .. versionadded:: 1.0.0

        .. versionchanged:: 1.2.0
            Works as a wrapper for :ref:`to_dict`.
        """
        return str(self.to_dict())

    def get_id(self) -> str:
        """
        Return the username for the current User.

        Returns:
            str: Username of User.

        .. versionadded:: 1.0.0
        """
        return self.username

    @property
    def password(self):
        """
        Raise an error when reading a non-readable attribute.

        Raises:
            AttributeError: Reading a non-readable attribute password.

        .. versionadded:: 1.0.0
        """
        raise AttributeError("Password is not a readable attribute!")

    @password.setter
    def password(self, password: str) -> None:
        """
        Set the current User password to the input string.

        Args:
            password (str): The new password.

        Raises:
            ValueError: When the password is not of the required length.

        .. versionadded:: 1.0.0

        .. versionchanged:: Check the length of the password before setting it.
        """

        if (
            len(password) < self.MIN_PASSWORD_LENGTH
            or len(password) > self.MAX_PASSWORD_LENGTH
        ):
            raise ValueError(
                "The password length must be between "
                f"{self.MIN_PASSWORD_LENGTH} and {self.MAX_PASSWORD_LENGTH}"
            )
        self.password_hash = generate_password_hash(password)

    def verify_password(self, password: str) -> bool:
        """
        Verify the current User password.

        Args:
            password (str): The password to check against the User password.

        Returns:
            bool: The password is yes/no.

        .. versionadded:: 1.0.0
        """
        return check_password_hash(self.password_hash, password)

    def has_permission(self, perm: Union[Permission, int]) -> bool:
        """
        Check if the User can access a permission.

        Args:
            perm (int): Attribute from Permission.

        Returns:
            bool: Does the user have the permission? yes/no.

        .. versionadded:: 1.0.0
        """
        return AuthorizationLevel.query.get(self.authorization_level).has_permission(
            perm
        )

    @staticmethod
    def insert_users() -> List["User"]:
        """
        Used to add an Admin and a System user to the database.

        Returns:
            List[User]: A list of the added users.

        .. versionadded:: 1.2.0
        """
        users = [
            User(
                username="System",
                email="",
                authorization_level=1,
                password="systempassword",
            ),
            User(
                username="Admin",
                email="admin@email.com",
                authorization_level=1,
                password="adminpassword",
            ),
        ]

        inserted_users = []

        for user in users:
            found = User.query.filter_by(username=user.username).first()
            if found is None:
                create_database_object(user)
                inserted_users.append(user)

        return inserted_users

    @staticmethod
    def create(
        username: str,
        email: str,
        authorization_level: int,
        uses_ldap: bool = False,
        password: str = None,
    ) -> "User":
        """Create a new user.

        Args:
            username (str): The username of the new user.
            email (str): The email of the new user.
            authorization_level (int): The authorization level of the new user.
            uses_ldap (bool, optional): Whether to use LDAP for authentication.
                Defaults to False.
            password (str, optional): The password for the new user. Defaults
                to None.

        Raises:
            ValueError: When ``uses_ldap`` is set to True but the password is
                also set.
            ValueError: When ``uses_ldap`` is set to False and the password is
                not set.
            ValueError: When creating a user with a duplicate username.
            ValueError: When creating a user with a duplicate email.
            ValueError: When creating a user with an unknown authorization
                level.
            ValueError: On problems with commiting to the database.
            RuntimeError: On problems with commiting to the database.

        Returns:
            User: The newly created User instance.

        .. versionadded: 1.2.0
        """

        if password is not None and uses_ldap:
            raise ValueError("Can't set the password for a remote LDAP user!")

        if password is None and not uses_ldap:
            raise ValueError("A non LDAP user must have a password!")

        if username == "@me":
            raise ValueError("The username @me is reserved!")

        found = User.query.get(username)
        if found:
            raise ValueError("Duplicate username!")

        found = User.query.filter_by(email=email).first()
        if found:
            raise ValueError("Duplicate email!")

        found = AuthorizationLevel.query.get(authorization_level)
        if found is None:
            raise ValueError("Unknown authorization level!")

        user = User(
            username=username,
            email=email,
            authorization_level=authorization_level,
            password=password,
            uses_ldap=uses_ldap,
        )

        create_database_object(user)

        return user

    @staticmethod
    def delete(username: str) -> None:
        """Delete the user specified by ``username``.

        Args:
            username (str): The username of the user to delete.

        Raises:
            ValueError: The specified user doesn't exist.
            RuntimeError: On problems with commiting to the database.

        .. versionadded:: 1.2.0
        """

        user = User.query.get(username)
        if user is None:
            raise ValueError("Couldn't find the specified user!")

        delete_database_object(user)

    @staticmethod
    def edit(
        username: str,
        email: str = None,
        password: str = None,
        authorization_level: int = None,
    ) -> "User":
        """Edit the user specified by ``username``.

        When an argument is ``None``, that particular attribute of the user
        will not be changed.

        Args:
            username (str): The username of the user to edit.
            email (str, optional): The new email, defaults to None.
            password (str, optional): The new password, defaults to None.
            authorization_level (int, optional): The new authorization level,
                defaults to none.

        Raises:
            ValueError: The specified user could not be found.
            ValueError: The new email is already taken by another user.
            ValueError: The new authorization level was not found.
            ValueError: On problems with commiting to the database.
            RuntimeError: On problems with commiting to the database.

        Returns:
            User: The edited user object.

        .. versionadded:: 1.2.0
        """

        user = User.query.get(username)
        if user is None:
            raise ValueError("Couldn't find the specified user!")

        if email is not None:
            found = User.query.filter_by(email=email).first()
            if found:
                raise ValueError("The specified email is already taken!")
            user.email = email

        if password is not None:
            user.password = password

        if authorization_level is not None:
            found = AuthorizationLevel.query.get(authorization_level)
            if not found:
                raise ValueError(
                    "The specified authorization level not found!"
                )  # noqa: E501
            user.authorization_level = authorization_level

        update_database()

        return user

    @staticmethod
    def login(username: str, password: str) -> "User":
        """Verify the username and password combination for a user.

        Firstly, attempt to find an instance of :ref:`User` in the database
        based on the provided password. If an instance is found, and it has the
        :ref:`uses_ldap` flag set to ``False``, check the provided password
        using :ref:`verify_password`.

        However, if a local instance of :ref:`User` is not found, or if it has
        the :ref:`uses_ldap` flag set to ``True``, attempt to create a
        connection to the configured LDAP server with the provided username and
        password. If the username and password combination is not
        accepted by the server, it must be incorrect.

        If it is accepted by the server, and a local :ref:`User` has been
        found, the user can be logged in, and the instance of the found
        :ref:`User` is returned. However, it the database doesn't contain a
        :ref:`User` with the specified username, it is created and committed to
        the DB before its instance is returned.

        Raises:
            PermissionError: When attempting to log in as the System user.
            ValueError: Wrong password for a local user.
            ValueError: Wrong credentials for an existing instance of a remote
                LDAP user.
            ValueError: Wrong credentials for a non-existing instance of a
                remote LDAP user.
            RuntimeError: Other issues with binding to the LDAP server.
            PermissionError: When the newly created user is not in the
                ``tci-users`` group.

        Returns:
            User: The user object from the database.

        .. note::
            When a new user is created with information from the remote LDAP
            server, his/her authorization level is set to the lowest available
            authorization level in the database. The administrator needs to
            manually set the authorization level if a higher level is required.

        .. warning::
            When a user gets removed from the ``tci-users`` group on the remote
            LDAP server, his local account is not deleted! That must be done
            manually by the administrator or a user with the correct
            permissions.

        .. versionadded:: 1.2.0
        .. versionchanged:: 1.3.2
            Removed helper function.

        .. todo::
            When using the ``User.create`` function here, it returns an error
            of ``NoneType has no attribute encode``.
        """

        user = User.query.get(username)

        if username == "System":
            raise PermissionError("Cannot log in as the system user!")

        # If the user exists in the database and IS NOT a remote LDAP user,
        # check the username and password combination
        if user is not None and not user.uses_ldap:
            if user.verify_password(password):
                return user
            raise ValueError("Wrong password for user!")

        server = Server(f"{current_app.config['LDAP_SERVER_URI']}", get_info=ALL)

        # Try to connect to the LDAP server. If the user is able to connect
        # and exists in the database, return its instance.
        try:
            conn = Connection(
                server,
                f"uid={username},ou=People,dc=liberouter,dc=org",
                password,
                auto_bind=True,
            )
        except LDAPBindError as err:
            if "invalidCredentials" in str(err):
                if user is None:
                    raise ValueError("Wrong credentials for remote LDAP user!") from err
                raise ValueError("Wrong credentials for user!") from err
            raise RuntimeError(f"Error contacting the LDAP server: {str(err)}") from err

        if user is not None:
            return user

        # Get info about the user from the LDAP server.
        conn.search(
            "dc=liberouter,dc=org",
            f"(uid={username})",
            attributes=["cn", "mail", "memberOf"],
        )
        user_info = conn.entries[0]

        # Make sure that the user is in the tci-users group.
        is_tci_user = False
        for group in user_info.memberOf:
            if "tci-users" in group:
                is_tci_user = True
                break

        if not is_tci_user:
            raise PermissionError(
                "You are not in the group 'tci-users'! "
                "Ask your administrator for help."
            )

        user = User(
            username=username,
            email=user_info.mail,
            authorization_level=AuthorizationLevel.query.order_by(
                AuthorizationLevel.level.desc()
            )
            .first()
            .level,
            uses_ldap=True,
        )

        create_database_object(user)

        return user


@jwt.user_identity_loader
def user_identity_lookup(username):
    """
    Register a callback function that takes whatever object is passed in as the
    identity when creating JWTs and converts it to a JSON serializable format.
    """
    return username


@jwt.user_lookup_loader
def user_lookup_callback(_jwt_header, jwt_data):
    """
    Register a callback function that loads a user from your database whenever
    a protected route is accessed. This should return any python object on a
    successful lookup, or None if the lookup failed for any reason (for example
    if the user has been deleted from the database).
    """
    identity = jwt_data["sub"]
    return User.query.get(identity)
