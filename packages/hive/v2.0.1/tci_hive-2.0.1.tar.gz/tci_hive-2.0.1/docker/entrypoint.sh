#!/bin/sh

mkdir -p "${OUTPUT_FOLDER}"

mkdir -p "${LOG_DIR}"
touch "${LOG_DIR}/hive.log"

mkdir -p /etc/tci/hive
touch /etc/tci/hive/config.toml
printf "[db]\n\
user = \"${DB_USER}\"\n\
pass = \"${DB_PASS}\"\n\
host = \"${DB_HOST}\"\n\
path = \"${DB_PATH}\"\n\
type = \"${DB_TYPE}\"\n\
options = \"${DB_OPTIONS}\"\n\
[gui]\n\
host = \"${HOST}\"\n\
port = \"${PORT}\"\n\
[ldap]\n\
uri = \"${LDAP_URI}\"\n\
[processing]\n\
pcap_folder = \"${OUTPUT_FOLDER}\"\n\
tmp_folder = \"${TMP_FOLDER}\"\n\
use_docker = false\n\
[tls]\n\
insecure = true\n\
[log]\n\
directory = \"${LOG_DIR}\"\n" > /etc/tci/hive/config.toml

cd /hive
FLASK_APP=tcigui flask deploy

gunicorn -k eventlet -w 1 tcigui:app -b ${HOST}:${PORT}
