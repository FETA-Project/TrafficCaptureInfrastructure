#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script model
============

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>
"""

from base64 import b64encode
from enum import Enum
from typing import Optional

import magic

from .. import db
from . import create_database_object, delete_database_object, update_database
from .authorization_level import AuthorizationLevel


class ScriptType(str, Enum):
    """Represent supported filetypes in MIME format"""

    #: str: A shell script type.
    SHELL = "text/x-shellscript"
    #: str: An unknown string type.
    UNKNOWN = "unknown"

    @classmethod
    def _missing_(cls, _):
        return cls.UNKNOWN

    def __str__(self):
        return self.value


class Script(db.Model):
    """Represent a single user script."""

    __tablename__ = "Script"

    #: The name of the script.
    name = db.Column(db.String(20), primary_key=True)
    #: Description string of the script
    #: to reduce overly descriptive and long file names.
    description = db.Column(db.Text())
    #: The actual script file.
    file_contents = db.Column(
        db.LargeBinary(length=(2**20) - 1), nullable=False
    )  # 1MB max
    #: The authorization level which is required for this script file to be
    #: accessible to the user.
    authorization_level = db.Column(
        db.Integer, db.ForeignKey("AuthorizationLevel.level"), nullable=False
    )
    #: Making sure that we can access the jobs using this script from the
    #: script itself.
    jobs = db.relationship("Job", back_populates="script")

    @property
    def filetype(self) -> Optional[ScriptType]:
        """Filetype of a script

        .. versionadded:: 1.2.1
        """

        if self.name == "None":
            return None

        decoded_content = self.file_contents.decode("utf-8")
        filetype = magic.from_buffer(decoded_content, mime=True)

        return ScriptType(filetype)

    # @filetype.setter
    # def filetype(self, filetype: str) -> None:
    #     raise AttributeError("Filetype is defined by file contents!")

    def to_dict(self) -> dict:
        """Return a dictionary representation of the object.

        Returns:
            dict: A dictionary representation of the object.

        .. versionadded:: 1.2.0
        """
        return {
            "name": self.name,
            "description": self.description,
            "authorization_level": self.authorization_level,
            "file_contents": b64encode(self.file_contents).decode(
                "utf-8"
            ),  # noqa: E501
            "filetype": str(self.filetype),
        }

    def __str__(self) -> str:
        """Return a string representation of the object.

        Work as a wrapper around to_dict().

        Returns:
            str: A string representation of the object.

        .. versionadded:: 1.0.0

        .. versionchanged:: 1.2.0
            Works as a wrapper for :ref:`to_dict`.
        """
        return str(self.to_dict())

    @staticmethod
    def insert_scripts() -> None:
        """
        Add a 'None' script for Authorization 1,
        making it possible to not process a pcap.

        .. versionadded:: 1.2.0
        """

        scripts = [Script(name="None", file_contents=b"", authorization_level=1)]

        inserted_scripts = []

        for script in scripts:
            found = Script.query.filter_by(name=script.name).first()
            if found is None:
                create_database_object(script)
                inserted_scripts.append(script)

        return inserted_scripts

    @staticmethod
    def create(
        name: str, file_contents: str, authorization_level: int, description: str = None
    ) -> "Script":
        """Create a new script object.

        Args:
            name (str): The name of the script.
            file_contents (str): The contents of the file as string.
            authorization_level (int): The authorization level that will be
                required to have access to this script.
            description (str): Description of the script. Defaults to None.

        Raises:
            ValueError: Unknown or unsupported file type.
            ValueError: When a duplicate username for a script is found.
            ValueError: When the authorization level is not found.
            ValueError: Problems with encoding the file contents.
            ValueError: On problems with committing to the database.
            RuntimeError: On problems with committing to the database.

        Returns:
            Script: The created script object.

        .. versionadded:: 1.2.0

        .. versionchanged:: 1.3.0
            Checking the file type instead of file extension.

        .. versionchanged:: 1.3.2
            Added script description argument.

        """

        found = Script.query.get(name)
        if found:
            raise ValueError("Duplicate script name!")

        found = AuthorizationLevel.query.get(authorization_level)
        if not found:
            raise ValueError("Unknown authorization level!")

        try:
            file_contents.encode("utf-8")
        except UnicodeEncodeError as err:
            raise ValueError("Problems encoding the file contents!") from err

        script = Script(
            name=name,
            description=description,
            file_contents=file_contents.encode("utf-8"),
            authorization_level=authorization_level,
        )

        if script.filetype == ScriptType.UNKNOWN:
            raise ValueError(
                f"Unknown or unsupported script filetype: {script.filetype}"
            )

        create_database_object(script)

        return script

    @staticmethod
    def edit(name: str, authorization_level: int) -> None:
        """Edit an authorization level.

        Raises:
            ValueError: Authorization level not valid.
            ValueError: Script not found.
            ValueError: On problems with committing to the database.
            RuntimeError: On problems with committing to the database.

        .. versionadded:: 1.2.0
        """

        found = AuthorizationLevel.query.get(authorization_level)
        if not found:
            raise ValueError("Authorization level not found!")

        found = Script.query.get(name)
        if not found:
            raise ValueError("Script not found!")

        found.authorization_level = authorization_level

        update_database()
        return found

    @staticmethod
    def delete(name: str) -> None:
        """Delete a script.

        Args:
            name (str): The name of the script to delete.

        Raises:
            ValueError: Not a known script name.
            ValueError: When the script is still used by some jobs.
            RuntimeError: On problems with committing to the database.

        .. versionadded:: 1.2.0
        """

        found = Script.query.get(name)
        if not found:
            raise ValueError("Script not found!")

        if found.jobs:
            raise ValueError("The script is still used by some jobs! Cannot delete.")

        delete_database_object(found)
