#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
JobDroneAssociation model
========================

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>
"""

# pylint: disable=missing-class-docstring

from typing import Optional
from .. import db, models


class JobDroneAssociation(db.Model):
    __tablename__ = "JobDroneAssociation"

    #: The ID of the job to which the Drones belong.
    job_id = db.Column(db.Integer, db.ForeignKey("Job.id"), primary_key=True)

    #: The name of the drone on which the traffic is captured.
    drone_name = db.Column(db.String(30), db.ForeignKey("Drone.name"), primary_key=True)

    #: The amount of captured data.
    captured_data = db.Column(db.String(100), default=0)

    #: The status of the drone.
    status = db.Column(db.String(30), default="Waiting")

    #: The status message of the drone.
    status_msg = db.Column(db.String(100), default="Just created.")

    #: Back reference relationships to the two tables.
    job = db.relationship("Job", back_populates="drones")
    drone = db.relationship("Drone", back_populates="jobs")

    def to_dict(self) -> dict:
        """Return a dictionary representation of the object.

        Returns:
            dict: A dictionary representation of the object.

        .. versionadded:: 1.2.0
        """
        return {
            "job_id": self.job_id,
            "drone_name": self.drone_name,
            "captured_data": self.captured_data,
            "status": self.status,
            "status_msg": self.status_msg,
        }

    def __str__(self) -> str:
        """Return a string representation of the object.

        Work as a wrapper around to_dict().

        Returns:
            str: A string representation of the object.

        .. versionadded:: 1.0.0

        .. versionchanged:: 1.2.0
            Works as a wrapper for :ref:`to_dict`.
        """
        return str(self.to_dict())

    def update_status(
        self, status: "models.JobStatus", msg: Optional[str] = None
    ) -> None:
        """Update the status of the job.

        Args:
            status (JobStatus): The new status of the job.
        """
        self.status = models.JobStatus(status)
        self.status_msg = msg if msg else ""
        models.update_database()
