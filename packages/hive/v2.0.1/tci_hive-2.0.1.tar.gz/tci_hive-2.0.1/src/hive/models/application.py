#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Application model
=================

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>
"""

from secrets import token_urlsafe
from typing import Optional, Tuple

from werkzeug.security import check_password_hash, generate_password_hash

from .. import db
from . import create_database_object, delete_database_object, update_database
from .user import User


class Application(db.Model):
    """Represent a single user application."""

    __tablename__ = "Application"

    def generate_token() -> str:  # pylint: disable=no-method-argument
        """Generate new application token.

        Returns:
            str: The new token.

        .. versionadded:: 1.3.0
        """

        return token_urlsafe(32)

    #: The ID of the application.
    id = db.Column(db.Integer, primary_key=True)
    #: The name of the application.
    name = db.Column(db.String(30), nullable=False)
    #: The owner of the application.
    owner = db.Column(db.String(20), db.ForeignKey("User.username"), nullable=False)
    #: The token used to access the API.
    token_hash = db.Column(
        db.String(128),
        nullable=False,
    )

    def to_dict(self) -> dict:
        """Return a dictionary representation of the object.

        Returns:
            dict: A dictionary representation of the object.

        .. versionadded:: 1.3.0
        """
        return {
            "id": self.id,
            "name": self.name,
            "owner": self.owner,
        }

    def __str__(self) -> str:
        """Return a string representation of the object.

        Work as a wrapper around to_dict().

        Returns:
            str: A string representation of the object.

        .. versionadded:: 1.3.0
        """
        return str(self.to_dict())

    def regenerate_token(self) -> str:
        """Generate new token for the application.

        Returns:
            str: The new token.

        .. versionadded:: 1.3.0
        """

        _token = Application.generate_token()
        self.token_hash = generate_password_hash(_token)
        update_database()
        return _token

    @staticmethod
    def create(name: str, owner: str) -> Tuple["Application", str]:
        """Create a new application.

        Args:
            name (str): The name of the application.
            owner (str): The owner of the application.

        Returns:
            (Application, str): Tuple containing created app and its token.

        .. versionadded:: 1.3.0
        """
        user = User.query.get(owner)
        if not user:
            raise ValueError("User does not exist.")

        _token = Application.generate_token()
        app = Application(
            name=name, owner=owner, token_hash=generate_password_hash(_token)
        )

        create_database_object(app)

        return app, _token

    @staticmethod
    def delete(app_id: int) -> None:
        """Delete an application.

        Args:
            app_id (int): The ID of the application.

        .. versionadded:: 1.3.0
        """
        app = Application.query.get(app_id)
        if not app:
            raise ValueError("Application does not exist.")

        delete_database_object(app)

    @staticmethod
    def find_by_token(token: str) -> Optional["Application"]:
        """Find an application from a token.

        Args:
            token (str): The token of the application.

        Returns:
            Application: The application.

        .. versionadded:: 1.3.0
        """

        all_apps = Application.query.all()
        for app in all_apps:
            if check_password_hash(app.token_hash, token):
                return app

        return None
