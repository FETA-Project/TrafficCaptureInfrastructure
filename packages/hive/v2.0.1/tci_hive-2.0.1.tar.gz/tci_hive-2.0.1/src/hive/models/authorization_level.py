#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
AuthorizationLevel model
========================

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>
"""

from typing import List, Union

from .. import db
from . import (
    Permission,
    create_database_object,
    delete_database_object,
    update_database,
)

# from .script import Script
# from .user import User


class AuthorizationLevel(db.Model):
    """Represent a single authorization level."""

    __tablename__ = "AuthorizationLevel"

    #: The level of this authorization. The application uses reverse levels,
    #: where level 1 is perceived to be a higher authorization then level 2,
    #: etc. This is done so that the administrator level with level 1 is
    #: always the highest authorization.
    level = db.Column(db.Integer, primary_key=True)
    #: The name of the authorization.
    name = db.Column(db.String(20), nullable=False, unique=True)
    #: The permissions allowed to the authorization level. These permissions
    #: are defined in :ref:`Permission`.
    permissions = db.Column(db.Integer, nullable=False, default=0)

    def to_dict(self) -> dict:
        """Return a dictionary representation of the object.

        Returns:
            dict: A dictionary representation of the object.

        .. versionadded:: 1.2.0
        """
        return {"name": self.name, "level": self.level, "permissions": self.permissions}

    def __str__(self) -> str:
        """Return a string representation of the object.

        Work as a wrapper around to_dict().

        Returns:
            str: A string representation of the object.

        .. versionadded:: 1.2.0

        .. versionchanged:: 1.0.0
            Works as a wrapper for :ref:`to_dict`.
        """
        return str(self.to_dict())

    def add_permission(self, perm: Union[Permission, int]) -> None:
        """
        Add a permission to this AuthorizationLevel.

        Args:
            perm (int): An attribute from Permission.

        .. versionadded:: 1.0.0
        """
        if not self.has_permission(perm):
            self.permissions += int(perm)

    def add_permissions(self, perms: List[Union[Permission, int]]) -> None:
        """
        Add many permissions to this AuthorizationLevel.

        Works as a wrapper over add_permission.

        Args:
            perms (List[int]): A list of attributes from Permission.

        .. versionadded:: 1.0.0
        """
        for permission in perms:
            self.add_permission(permission)

    def remove_permission(self, perm: Union[Permission, int]) -> None:
        """
        Remove a permission from the AuthorizationLevel.

        Args:
            perm (int): An attribute from Permission.

        .. versionadded:: 1.0.0
        """
        if self.has_permission(perm):
            self.permissions -= perm

    def reset_permissions(self) -> None:
        """
        Reset all the permissions of this AuthorizationLevel.

        This sets the permission attribute to zero.

        .. versionadded:: 1.0.0
        """
        self.permissions = 0

    def has_permission(self, perm: Union[Permission, int]) -> bool:
        """
        Check if the current AuthorizationLevel has a permission.

        Uses bitwise operator & to check the permission.

        Args:
            perm (int): An attribute from Permission.

        Returns:
            bool: AuthorizationLevel has the permission, yes/no.

        .. versionadded:: 1.0.0
        """
        return self.permissions & perm == perm

    @staticmethod
    def insert_authorizations() -> List["AuthorizationLevel"]:
        """
        Used to add a default admin authorization into the database.

        Returns:
            List[AuthorizationLevel]: A list of the inserted levels.

        .. versionadded:: 1.2.0
        """
        levels = [
            AuthorizationLevel(level=1, name="Admin", permissions=int(Permission.ADMIN))
        ]

        inserted_levels = []

        for level in levels:
            found = AuthorizationLevel.query.filter_by(level=level.level).first()
            if found is None:
                create_database_object(level)
                inserted_levels.append(level)

        return inserted_levels

    @staticmethod
    def create(
        level: int, name: str, permissions: int = 0
    ) -> "AuthorizationLevel":  # noqa: E501
        """Create a new authorization level.

        Args:
            level (int): The level of the authorization.
            name (str): The name of the authorization.
            permissions (int, optional): The permissions of the authorization.
                Defaults to 0.

        Raises:
            ValueError: When a duplicate level is supplied.
            ValueError: When a duplicate name is supplied.
            ValueError: On problems with commiting to the database.
            RuntimeError: On problems with commiting to the database.

        Returns:
            AuthorizationLevel: The newly created authorization level.

        .. versionadded:: 1.2.0

        .. todo::
            * Check, whether :ref:`permissions` is valid.
        """

        found = AuthorizationLevel.query.get(level)
        if found:
            raise ValueError("Can't create a duplicate authorization level!")

        found = AuthorizationLevel.query.filter_by(name=name).first()
        if found:
            raise ValueError("Can't create a duplicate authorization name!")

        auth = AuthorizationLevel(level=level, name=name, permissions=permissions)

        create_database_object(auth)

        return auth

    @staticmethod
    def delete(level: int) -> None:
        """Delete an authorization level.

        Args:
            level (int): The level of the authorization to delete.

        Raises:
            ValueError: Invalid authorization level, not found.
            RuntimeError: On problems with commiting to the database.

        .. versionadded:: 1.2.0
        """

        found = AuthorizationLevel.query.get(level)
        if not found:
            raise ValueError("Authorization level not found!")

        delete_database_object(found)

    @staticmethod
    def edit(
        level: int, name: str = None, permissions: int = None
    ) -> "AuthorizationLevel":
        """Edit an existing authorization level.

        Args:
            level (int): The level of the authorization to change.
            name (str, optional): The new name of the authorization.
                Changes only if set, defaults to None.
            permissions (int, optional): The new permission level of the
                authorization. Changes only if set, defaults to None.

        Raises:
            ValueError: Invalid authorization level, not found.
            ValueError: Duplicate authorization level name specified.
            ValueError: On problems with commiting to the database.
            RuntimeError: On problems with commiting to the database.

        Returns:
            AuthorizationLevel: The edited authorization level object.

        .. versionadded:: 1.2.0

        .. todo::
            Make sure that :ref:`permissions` is the correct value.
        """

        auth = AuthorizationLevel.query.get(level)
        if auth is None:
            raise ValueError(f"Auth level {level} not found.")

        if name is not None:
            found = AuthorizationLevel.query.filter_by(name=name).first()
            if found and found.level != level:
                raise ValueError("Duplicate authorization level name!")
            auth.name = name

        if permissions is not None:
            auth.permissions = permissions

        update_database()

        return auth
