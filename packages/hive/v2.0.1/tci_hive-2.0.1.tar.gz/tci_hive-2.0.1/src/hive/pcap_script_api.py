#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
PCAP API module
===============

**Author**

- David Beneš <benesdavid@cesnet.cz>

**Description**

Contains the object used for processing raw pcap files with script.
"""

import os
import shutil
import subprocess
from glob import glob
from typing import Optional

from flask import current_app
from werkzeug.utils import secure_filename

import docker


def log(msg: str):
    """Create a new log message for PCAP SCRIPT.

    Args:
        msg (str): The message to be logged.

    .. versionadded:: 1.2.0
    """
    current_app.logger.info(f"PCAP_SCRIPT - {msg}")


class PCAPScriptException(Exception):  # noqa: N818
    """
    Represent a PCAPScript exception

    Args:
        status_code (int): Status code
        error_message (str): Error message
    """

    def __init__(self, status_code: int, error_message: str):
        self.status_code = status_code
        self.error_message = error_message
        super().__init__(self.error_message)

    def __str__(self) -> str:
        """
        Represent exception as string

        Returns:
          str: string representation of PCAPException
        """
        return f"Status code {self.status_code}: {self.error_message}"


class PCAPScriptDockerException(PCAPScriptException):
    """Represent a Docker-specific exception."""

    status_code = 1010

    def __init__(self, error_message: str):
        super().__init__(self.status_code, error_message)

    def __str__(self) -> str:
        return f"Status code {self.status_code}: {self.error_message}"


class PCAPScriptShellException(PCAPScriptException):
    """Represent a Shell-specific exception."""

    status_code = 1020

    def __init__(self, ret_code: int, error_message: str):
        self.ret_code = ret_code
        super().__init__(self.status_code, error_message)

    def __str__(self) -> str:
        return (
            f"Status code {self.status_code}: "
            f"({self.ret_code}) {self.error_message}"
        )


class PCAPScript:
    """Used for interacting with the Docket containers."""

    def init(
        self,
        pcap_folder: str,
        tmp_folder: str,
        use_docker: bool = True,
        raw_extensions=None,
    ):
        """
        Process pcap files and run scripts on them

        Args:
            pcap_folder (str): Folder that stores pcap files
            tmp_folder (str): Folder that stores temporary files
            use_docker (bool): Run scripts in docker. Defaults to True.
            raw_extensions (bool): Defaults to None.

        .. versionchanged: 1.2.0
            Added support for changing tmp_folder

        .. todo::
            Update raw_extensions docstring.
        """
        if raw_extensions is None:
            raw_extensions = ["pcap", "pcapng"]
        if use_docker:
            self.docker_client = docker.from_env()

        self.pcap_folder = pcap_folder
        self.tmp_folder = tmp_folder

        self.use_docker = use_docker

        self.raw_extensions = raw_extensions

    def get_output_file(self, filename: str, extensions=None) -> Optional[str]:
        """
        Get first file from pcap folder named filename.

        Searches for all files with filename in pcap folder that have one of
        extension in extensions list.

        Args:
            filename (str): Name of a file to search without extension
            extensions (List): List of extensions of file
                               If not set, uses filename.*

        Returns:
            Optional[str]: Name of the file if found, otherwise None.
        """
        # try to find a file to return, keep the first one found
        if extensions is None:
            extensions = ["*"]
        for ext in extensions:
            files = glob(os.path.join(self.pcap_folder, f"{filename}.{ext}"))
            if files:
                return files[0]

        return None

    def process(self, job, run_script: bool = True) -> None:
        """
        Download pcap file from tci-api and save it to disk

        If run_script is True run script on the downloaded file

        Args:
          job (Job): ORM Job to process
          run_script (bool, optional): if True, run script on pcap file
                                       from job, defaults to True
        """

        log(f"Processing job {job.id}")
        job.update_status("Processing", "Processing job.")

        # Create pcap folder if it does not exist
        if not os.path.isdir(self.pcap_folder):
            log(f"Creating pcap folder {self.pcap_folder}")
            os.mkdir(self.pcap_folder)

        # Job already processed
        if self.get_output_file(job.id, ["zip"]):
            log(f"...job {job.id} is already processed")
            job.update_status("Done", "Processed.")
            return

        # Find clean pcap, if it does not exist download it from tci
        file = self.get_output_file(job.id, self.raw_extensions)
        if file is None:
            log(f"...pcap file for job {job.id} not found")
            job.update_status(
                "To process", "Could not find PCAP file. Waiting for processing."
            )
            raise PCAPScriptException(1001, "Clean PCAP file not found")

        script = None
        args = None

        if run_script:
            # Set script if found
            if job.script is not None and job.script.file_contents != b"":
                script = job.script.file_contents
                args = job.script_args
            self.run(job, script, args if args is not None else "", file)
        else:
            job.update_status("To Process", "Waiting for processing.")

    def _start_script(self, job, args: str, working_dir: str) -> None:
        """Run script on downloaded pcap!

        Args:
            job (Job): id of job
            args (str): arguments of shell script
            working_dir (str): directory in which to find pcap and script

        .. caution::
            Should not be used alone, only through the ``run()`` method.

        .. todo::
            Prefer using /bin/bash in docker as opposed to /bin/sh.

        .. versionchanged:: 2.0.1
        """

        # file needs to be executable tho
        if self.use_docker:
            log(f"Running script for job {job.id} in container")
            try:
                self.docker_client.containers.run(
                    "alpine",
                    "/bin/sh script.sh input.pcap output_dir/" + str(args),
                    name=f"job_{str(job.id)}",
                    volumes={working_dir: {"bind": "/working_dir", "mode": "rw"}},
                    working_dir="/working_dir",
                    remove=True,
                    privileged=True,
                )
            except Exception as exc:
                job.update_status("Failed", "Running script in docker failed.")
                raise PCAPScriptDockerException(str(exc)) from exc
        else:
            log(f"Running script for job {job.id} in shell")
            ret = subprocess.run(
                args=[
                    "PATH=\"$PATH:/usr/local/bin:/usr/bin:/usr/local/sbin\";"
                    "/bin/bash script.sh input.pcap output_dir/ " + str(args)
                ],
                shell=True,
                capture_output=True,
                cwd=working_dir,
                check=False,
            )
            if ret.returncode != 0:
                job.update_status("Failed", "Runnning script in shell failed.")
                raise PCAPScriptShellException(ret.returncode, ret.stderr.decode())

    def run(self, job, script, args: str, pcap: str) -> None:
        """
        Run script on a pcap file

        Creates docker container.
        Runs script in the container.
        Deletes docker container.

        Args:
            job (Job): The job that generated pcap file
            script (Script): Shell script to run on pcap file
            args (str): Arguments for shell script
            pcap (str): Path to a raw pcap file

        Raises:
            Exception: Raises a Docker SDK exception.
            PCAPScriptException: Raises exception if shell script did
                not create any output pcap file.

        .. versionchanged:: 2.0.1
        """

        log(f"Preparing to run script on job {job.id}")

        job_id = str(job.id)

        if job.status != "Processing":
            job.update_status("Processing", "Processing job.")

        if not os.path.isdir(self.tmp_folder):
            log(f"...creating tmp folder {self.tmp_folder}")
            os.mkdir(self.tmp_folder)

        working_dir = os.path.join(self.tmp_folder, job_id)
        if os.path.isdir(working_dir):
            log(f"...cleaning working directory for job {job_id}")
            shutil.rmtree(working_dir)

        log(f"...creating working directory for job {job_id}" " and copying pcap file")
        os.mkdir(working_dir)
        shutil.move(pcap, os.path.join(working_dir, "input.pcap"))

        output_dir = os.path.join(working_dir, "output_dir")
        log(f"...creating output directory for job {job_id}")
        os.mkdir(output_dir)

        if script is not None:
            log(f"...downloading script for job {job_id}")
            with open(os.path.join(working_dir, "script.sh"), "wb") as file:
                file.write(script)

            try:
                self._start_script(job, args, working_dir)
            except PCAPScriptException as exc:
                shutil.move(os.path.join(working_dir, "input.pcap"), pcap)
                raise exc
        else:
            log(
                f"No script was set for job {job_id}."
                " Skipping script and moving pcap to output folder"
            )
            shutil.move(
                os.path.join(working_dir, "input.pcap"),
                os.path.join(output_dir, "output.pcap"),
            )

        log(f"Preparing output files for job {job_id}")
        if len(list(os.listdir(output_dir))) != 0:
            if os.path.isfile(os.path.join(output_dir, "output.pcap")):
                log(
                    f"...renaming output.pcap of job {job_id} to"
                    f" {secure_filename(job.name)}.pcap"
                )
                shutil.move(
                    os.path.join(output_dir, "output.pcap"),
                    os.path.join(output_dir, f"{secure_filename(job.name)}.pcap"),
                )

            log(
                f"...adding files from output folder of job {job_id} to zip."
                " And deleting working directory"
            )
            shutil.make_archive(
                os.path.join(self.pcap_folder, job_id),
                "zip",
                root_dir=output_dir,
                base_dir="./",
            )
            shutil.rmtree(working_dir)
            job.update_status("Done", "Processing finished. Output file created")
            job.move()
        else:
            shutil.rmtree(working_dir)
            job.update_status("Failed", "No output file created.")
            raise PCAPScriptException(1000, "Script did not generate any output files.")
