#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Destinations module
=====================

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Implements destination functionality for the API.

**Functions**

.. automethod:: app.api.authorizations.get_destinations()
.. automethod:: app.api.authorizations.get_destination(id)
.. automethod:: app.api.authorizations.delete_destination(id)
"""
from flask import Response, g, jsonify, request
from flask_expects_json import expects_json

from ..decorators import permission_required
from ..models import Destination, Permission
from . import Schemas, api, log
from .errors import bad_request, internal_error

# from sqlalchemy.exc import SQLAlchemyError


@api.route("/destinations")
def get_destinations() -> Response:
    """Get all the destinations.

    **Example response**:

    .. code-block:: json

       [
           {
               "id": 1,
               "name": "Foo",
               "owner": "user1",
               "path": "/data/dir1/"
           },
           {
               "id": 321,
               "name": "Bar",
               "owner": "temp",
               "path": "/path/to/dir/"
           }
       ]

    Returns:
        Response: A JSON containing the list of all the destinations.

    .. versionadded:: 2.0.0

    .. :quickref: Destination; Get all destinations.
    """
    log("Getting all destinations.", debug=True)
    dests = Destination.query.all()
    return jsonify(
        [dest.to_dict() for dest in dests if dest.owner == g.current_user.username]
    )


@api.route("/destinations/<int:destination_id>")
def get_destination(destination_id: int) -> Response:
    """Get detailed info about specific destination.

    **Example response**:

    .. code-block:: json

       {
           "id": 123,
           "name": "Foo",
           "owner": "user",
           "path": "/dir"
       }

    Args:
        destination_id (int): ID of the destination.

    Returns:
        Response: A JSON containing the destination info.

    .. versionadded:: 1.2.0

    .. :quickref: Destination; Get detailed destination info.
    """
    log(f"Getting info about destination {destination_id}.", debug=True)

    dest = Destination.query.get_or_404(destination_id)

    return jsonify(dest.to_dict())


@api.route("/destinations", methods=["POST"])
@expects_json(Schemas.new_destination_schema)
@permission_required(Permission.SCRIPT_MASTER)
def new_destination() -> Response:
    """Create a new destination.

    **Example request**:

    .. code-block:: json

       {
           "name": "NAME",
           "owner": "user",
           "path": "/dir"
       }

    Returns:
        Response: Created destination as JSON or Error message.

    .. versionadded:: 2.0.0

    .. :quickref: Destination; Create a new destination.
    """

    log(f"Creating a new destination {request.json['name']}")

    try:
        dest = Destination.create(
            name=request.json["name"],
            owner=g.current_user.username,
            path=request.json["path"],
        )
    except ValueError as err:
        return bad_request(str(err))

    return jsonify(dest.to_dict())


@api.route("/destinations/<int:destination_id>", methods=["PUT"])
@expects_json(Schemas.edit_destination_schema)
@permission_required(Permission.SCRIPT_MASTER)
def edit_destination(destination_id: int) -> Response:
    """Edit an existing destination.

    If trying to edit an destination that doesn't exist, raise 404.
    If id is in the request and it is not the same as the one in the DB,
    raise 400.

    **Example request**:

    .. code-block:: json

       {
           "name": "NEW_NAME",
           "path": "/new/path"
       }

    Args:
        destination_id (int): The ID of the destination to edit.

    Returns:
        Response: The newly edited destination as JSON.

    .. versionadded:: 2.0.0

    .. :quickref: Destination; Edit an destination.
    """
    if "id" in request.json:
        return bad_request("Can't edit authorization level number.")

    log(f"Editing the destination with ID {destination_id}")

    name = None
    if "name" in request.json:
        name = request.json["name"]

    path = None
    if "path" in request.json:
        path = request.json["path"]

    try:
        dest = Destination.edit(destination_id, name, path)
    except ValueError as err:
        return bad_request(str(err))

    return jsonify(dest.to_dict())


@api.route("/destinations/<int:destination_id>", methods=["DELETE"])
@permission_required(Permission.SCRIPT_MASTER)
def delete_destination(destination_id: int) -> Response:
    """Delete a destination.

    Args:
        destination_id (int): The ID of the destination to remove.

    Returns:
        Response: Status code or error message.

    .. versionadded:: 2.0.0

    .. :quickref: Destination; Delete a destination.
    """
    log(f"Deleting the destination with ID {destination_id}")

    try:
        Destination.delete(destination_id)
    except ValueError as err:
        return bad_request(str(err))
    except RuntimeError as err:
        return internal_error(str(err))

    return Response(status=204)
