#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Errors module
=============

**Author**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Implementation of common HTTP errors for the API.
"""

from flask import Response, jsonify


def bad_request(message: str) -> Response:
    """Create a "bar request" response.

    Args:
        message (str): Custom message.

    Returns:
        Response with custom message and 400 error code.
    """
    response = jsonify({"error": "bad request", "message": message})
    response.status_code = 400
    return response


def unauthorized(message: str) -> Response:
    """Create an "unauthorized" response.

    Args:
        message (str): Custom message.

    Returns:
        Response with custom message and return code 401.
    """
    response = jsonify({"error": "unauthorized", "message": message})
    response.status_code = 401
    return response


def forbidden(message: str) -> Response:
    """Create a "forbidden" response.

    Args:
        message (str): Custom message.

    Returns:
        Response with custom message and return code 403.
    """
    response = jsonify({"error": "forbidden", "message": message})
    response.status_code = 403
    return response


def internal_error(message: str) -> Response:
    """Create a "internal error" response.

    Args:
        message (str): Custom message.

    Returns:
        Response with custom message and return code 500.
    """
    response = jsonify({"error": "internal", "message": message})
    response.status_code = 500
    return response
