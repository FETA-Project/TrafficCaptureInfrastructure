#/bin/sh

HOST=0.0.0.0
PORT=8080

cd /usr/bin/tci/hive/
/opt/tci/hive/venv/bin/gunicorn -k eventlet -w 1 tcigui:app -b $HOST:$PORT