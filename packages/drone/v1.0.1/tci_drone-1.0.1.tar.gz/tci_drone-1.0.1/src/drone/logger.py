# -*- coding: utf-8 -*-
"""
Logger module
=============

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Logging configuration for the TCI Drone.
"""

import logging
import sys
from os import path
from typing import Any, List

from config import Config

_log_file = path.join(Config.LOG_DIR, Config.LOG_NAME)
_file_handler = logging.FileHandler(filename=_log_file)
_stdout_handler = logging.StreamHandler(stream=sys.stdout)
_handlers: List[Any] = [_file_handler, _stdout_handler]

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s - %(message)s",
    handlers=_handlers,
)

logger = logging.getLogger()
