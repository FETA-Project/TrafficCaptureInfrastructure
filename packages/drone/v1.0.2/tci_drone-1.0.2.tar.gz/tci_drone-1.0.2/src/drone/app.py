# -*- coding: utf-8 -*-
"""
TCI Drone Module
================

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

The main entry point for the TCI Drone.
"""

import signal
import sys
from random import random
from time import sleep
from types import FrameType
from typing import Optional

import socketio
from config import Config
from logger import logger
from models import Drone, DroneCaptureBackend

drone = Drone(
    name=Config.NAME,
    description=Config.DESCRIPTION,
    capture_backend=Config.CAPTURE_BACKEND,
)

sio = drone.sio

from endpoints import *  # pylint: disable=wildcard-import,wrong-import-position  # noqa: E501,E402,F403


def graceful_shutdown(signal_id: int, _: Optional[FrameType]) -> None:
    """Gracefully shutdown the drone.

    .. versionadded:: 1.0.0
    .. versionchanged:: 1.0.1
        Set default filter when using NDP.
    """
    drone.log(
        f"\rCaught signal {signal.Signals(signal_id).name},"
        "cleaning up and shutting down."
    )
    sio.disconnect()
    if drone.capture_backend == DroneCaptureBackend.NDP:
        drone.log("Setting default filter.")
        drone.capture_source.set_default_filter()
    sys.exit(0)


def run() -> None:
    """Entrypoint of the drone app."""
    for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, graceful_shutdown)

    logger.info(f"Drone initialized with config ({Config.__path__}): {drone.to_dict()}")
    logger.debug(drone.to_dict())
    while True:
        try:
            sio.connect(
                Config.HIVE_URL,
                auth={"token": Config.TOKEN},
            )
            sio.wait()
        except socketio.exceptions.ConnectionError:
            sleep((random() * 100) % 5)


if __name__ == "__main__":
    run()
