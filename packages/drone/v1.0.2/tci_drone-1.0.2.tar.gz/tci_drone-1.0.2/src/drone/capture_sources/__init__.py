# -*- coding: utf-8 -*-
"""
CaptureSource Module
====================

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

The implementation of the network capture source for the backend.
"""

import os
import shutil
import signal
import subprocess
from threading import Thread
from time import sleep
from typing import Any, Callable, List, Optional, Union

from config import Config
from logger import logger


class CaptureSource:
    """The base class for all capture sources.

    .. versionadded:: 1.0.0
    """

    def __init__(self, drone_name: str) -> None:
        #: The capture process in os.
        self.process: Optional[subprocess.Popen[Any]] = None
        #: The path to captured pcap file.
        self.pcap_path: Optional[os.PathLike[str]] = None
        #: The captured data.
        self.captured: int = 0
        #: Flag showing if the process should stop.
        self._stop: bool = False
        #: Flag showing if there is dma overflow.
        self.dma_overflow: bool = False
        #: The name of the drone that uses this capture source.
        self._drone_name: str = drone_name

    def _process_update_captured(
        self,
        poll: int,
        output_path: str,
        max_size: int,
        on_restriction_reached: Callable,
        check_dma_overflow: Optional[Callable] = None,
    ) -> None:
        """Update the information about capture process.

        Args:
            poll (int): Time to wait until the next update.
            output_path (str): Path to output file.
            max_size (int): Max size of capture.
            on_restriction_reached (Callable): Function to be called
                when restriction (maximum captured data/size of file) is reached.
            check_dma_overflow (Optional[Callable]): Function for checking
                dma overflow.

        .. versionadded:: 1.0.0
        .. versionchanged:: 1.0.1
            Set max_size to Config.CAPTURE_LIMIT before the loop.
            Fix check_dma_overflow() check.
            on_restriction_reached is not mandatory.
        """
        logger.debug("Starting update thread")

        if 0 < Config.CAPTURE_LIMIT < max_size:
            max_size = Config.CAPTURE_LIMIT

        while not self._stop:
            try:
                self.captured = self.get_file_size(output_path)

                if 0 < max_size <= self.captured:
                    if self.process is not None:
                        self.process.send_signal(signal.SIGINT)
                    self._stop = True

                if check_dma_overflow is not None and check_dma_overflow():
                    if self.process is not None:
                        self.process.send_signal(signal.SIGINT)
                    self._stop = True
                    self.dma_overflow = True
            except OSError:
                pass
            sleep(poll)

        self.captured = self.get_file_size(output_path)
        self._stop = False
        on_restriction_reached()

    def _process_timeout(self, timeout: int, on_timeout: Optional[Callable]) -> None:
        """Stop process after timeout.

        Args:
            timeout (int): Time to wait until stopping the process.
            on_timeout (Optional[Callable]): Function to call on timeout.

        .. versionadded:: 1.0.0
        """
        try:
            if self.process is not None:
                self.process.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            if self.process is not None:
                self.process.send_signal(signal.SIGINT)
            self._stop = True
            if on_timeout:
                on_timeout()

    def log(self, msg: str, capture_backend: str) -> None:
        """Log the message.

        Args:
            msg (str): Message to log.
            capture_backend (str): Capture backend.

        .. versionadded:: 1.0.0
        """
        logger.info("%s - %s - %s", self._drone_name, capture_backend, msg)

    def cleanup(self) -> None:
        """Clean the CaptureSource

        .. versionadded:: 1.0.0
        """
        self.process = None
        self.pcap_path = None
        self.captured = 0
        self._stop = False
        self.dma_overflow = False

    def create_process(
        self,
        command: List[str],
        output_path: str,
        on_restriction_reached: Callable,
        timeout: Optional[int] = 0,
        max_size: Optional[int] = 0,
        check_dma_overflow: Optional[Callable] = None,
    ) -> None:
        """Create the capture process in the OS.

        Args:
            command (List[str]): Command to run in the process.
            output_path (str): Path to output file.
            timeout (Optional[int]): The timeout of the process in seconds.
            on_restriction_reached (Callable): Function to be called
                when restriction is reached.
            max_size (int): Max size of capture.
            check_dma_overflow (Optional[Callable]): Function for checking
                dma overflow.

        .. versionadded:: 1.0.0
        .. versionchanged:: 1.0.1

        .. todo:: Use check_dma_overflow. See todo in NDP.
        """
        # pylint: disable=unused-argument,consider-using-with

        self.dma_overflow = False

        # create empty output file
        open(output_path, "w").close()

        self.process = subprocess.Popen(
            command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        Thread(
            target=self._process_update_captured,
            args=(
                Config.UPDATE_CAPTURED_INTERVAL,
                output_path,
                max_size,
                on_restriction_reached,
                check_dma_overflow,
            ),
        ).start()

        if timeout is not None and timeout > 0:
            Thread(
                target=self._process_timeout, args=(timeout, on_restriction_reached)
            ).start()

    @staticmethod
    def get_exec_path(path: str) -> str:
        """Check whether the given path can be used.

        Args:
            path: The path to the desired executable, eg. "tcpdump" or
                "/usr/bin/tcpdump".

        Returns:
            str: The real path to the executable.

        Raises:
            OSError: when the path to the executable can't be found.
            PermissionError: when there are insufficient permissions to execute
                the file.

        .. versionadded:: 1.0.0
        """
        # Get the real path of the executable
        # (eg. "tcpdump" -> "/usr/bin/tcpdump").
        # This is equivalent to running "which" in the shell.
        real_path = shutil.which(path)
        # Check if the executable can be found
        if real_path is None:
            raise OSError(f'The executable "{path}" could not be found.')
        # Check if we have privileges to execute it
        if not os.access(real_path, os.X_OK):
            raise PermissionError(f'Insufficient permissions to execute "{real_path}".')
        return real_path

    @staticmethod
    def get_file_size(path: Union[str, os.PathLike[str]]) -> int:
        """Get the size of a file.

        Args:
            path (os.Pathlike[str]): Path to a file.

        Returns:
            int: The size of the file.

        Raises:
            OSError: When the path is not a file.

        .. versionadded:: 1.0.0
        """
        if not os.path.isfile(path):
            raise OSError("The path is not a file.")
        return os.stat(path).st_size


# fmt: off
from .ndp import NDP  # pylint: disable=wrong-import-position  # noqa: E501,E402,F401,C0413
from .tcpdump import TCPDump  # pylint: disable=wrong-import-position  # noqa: E501,E402,F401,C0413
