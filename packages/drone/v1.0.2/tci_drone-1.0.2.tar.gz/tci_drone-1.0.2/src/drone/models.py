# -*- coding: utf-8 -*-

# pylint: disable=redefined-builtin

"""
Models module
=============

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Implements all the objects for the Drone.
"""

import functools
import json
from enum import Enum
from os import path
from threading import Thread
from time import sleep
from typing import Any, Callable, Dict, Optional
import requests

import socketio
from pydantic import ValidationError

from capture_sources import NDP, TCPDump
from config import Config
from logger import logger
from validators import EndpointValidator


def get_filepath(drone_name: str, job_id: int) -> str:
    """Create the path to a job PCAP.

    Args:
        drone_name (str): The name of the drone.
        job_id (int): The ID of the job.

    Returns:
        The path to the PCAP.

    .. versionadded:: 1.0.0
    """
    return path.join(Config.OUTPUT_FOLDER, f"{job_id}-{drone_name}.pcap")


class DroneCaptureBackend(str, Enum):
    """The possible capture types of the drone.

    .. versionadded:: 1.0.0
    """

    UNKNOWN = "unknown"
    TCPDUMP = "tcpdump"
    NDP = "ndp"

    @classmethod
    def _missing_(cls, _: Any) -> "DroneCaptureBackend":
        return cls.UNKNOWN


class DroneStatus(str, Enum):
    """The possible states of the drones.

    .. graphviz::
        :caption: DroneStatus state diagram.

        digraph StateDiagram {
            node [style=filled];
            Created [shape=Mdiamond];

            Created -> Pending [label=" The drone was created,\n waiting for first connection."];
            Pending -> Sleeping [label=" The drone connected and\n is waiting for commands."];

            Sleeping -> Working [label=" A new capture\n command was issued."];
            Sleeping -> Disconnected [label=" Unable to communicate\n with the drone."];
            Sleeping -> Error [label=" Error on the side\n of the drone."];

            Working -> Sleeping [label=" Capture command\n finished, waiting."];
            Working -> Disconnected [label=" Unable to communicate\n with the drone."];
            Working -> Error [label=" Error on the side\n of the drone."];

            Disconnected -> Sleeping [label=" Drone reconnected,\n sleeping."];
            Disconnected -> Error [label=" Drone reconnected,\n but raised an error."];
        }

    .. versionadded:: 1.0.0
    """  # noqa: E501,C0301  # pylint: disable=line-too-long

    ERROR = "Error"
    PENDING = "Pending"
    SLEEPING = "Sleeping"
    WORKING = "Working"
    DISCONNECTED = "Disconnected"
    UNKNOWN = "Unknown"

    @classmethod
    def _missing_(cls, _: Any) -> "DroneStatus":
        return cls.UNKNOWN


class SocketioClientWrapper(socketio.Client):  # pylint: disable=too-few-public-methods
    """A custom wrapper for the socketio.Client model."""

    @staticmethod
    def parse(model: Optional[EndpointValidator] = None) -> Callable:
        """Parse the incoming SocketIO data into the selected model.

        When parsing the data into JSON fails or if validating the model fails, the
        decorator returns a 406 error with the error string.

        Args:
            model (Optional[EndpointValidator]): The model to parse the data into
                If this model is None, the data is returned as a dictionary.

        Returns:
            The decorator function.

        .. todo::
            Add automatic parsing based on the type annotation of the function, using
            inspect.signature.
        """

        def decorator(func: Callable) -> Callable:
            @functools.wraps(func)
            def wrapper(data: str) -> Any:
                # Parsing the data
                try:
                    json_data = json.loads(data)
                    if model is not None:
                        validated_model = model(**json_data)
                        return func(validated_model)
                    return func(json_data)
                except json.JSONDecodeError as err:
                    return 406, json.dumps(err)
                except ValidationError as err:
                    return 406, err.json()

            return wrapper

        return decorator


class Drone:
    """The Drone object.
    .. versionadded:: 1.0.0
    """

    # pylint: disable=too-many-instance-attributes
    # The number of attributes seem reasonable. Reducing the number just for the
    # sake of reducing it does not seem right.

    def __init__(
        self, name: str, description: str, capture_backend: DroneCaptureBackend
    ):
        #: The name of the drone
        self.name: str = name
        #: The drone description
        self.description: str = description
        #: The capture backend used by the drone
        #: ie. TCPDUMP, NDP, etc...
        self.capture_backend = DroneCaptureBackend(capture_backend)

        #: The current status of the drone
        self.status: DroneStatus = DroneStatus.PENDING

        #: The current active job
        self.active_job: Optional[Job] = None
        #: The job history. Used for getting files of finished jobs.
        self.job_history: list[Job] = []
        #: Initializing capture source based on the capture backend.
        if self.capture_backend == DroneCaptureBackend.TCPDUMP:
            self.capture_source = TCPDump(
                drone_name=self.name,
                interface=Config.TCPDUMP_IFC,
            )
        elif self.capture_backend == DroneCaptureBackend.NDP:
            self.capture_source = NDP(
                drone_name=self.name,
                device=Config.NDP_DEVICE,
                dma_have=Config.NDP_DMA_HAVE,
                cores=Config.NDP_CORES,
            )
        else:
            self.capture_backend = DroneCaptureBackend.UNKNOWN
            raise ValueError(f"Invalid capture backend {capture_backend}")

        #: The socketio client used for communicating with the hive.
        http_session = None

        if not Config.INSECURE:
            http_session = requests.Session()
            http_session.cert = Config.CERT
            http_session.verify = Config.CA_CERT

        self.sio = SocketioClientWrapper(http_session=http_session)

    def log(self, msg: str, error: bool = False) -> None:
        """Log a message with the drone name.

        .. versionadded:: 1.0.0
        """
        if error:
            logger.error("%s - %s", self.name, msg)
        else:
            logger.info("%s - %s", self.name, msg)

    def to_dict(self) -> dict:
        """Return a dictionary representation of the object.

        Returns:
            dict: A dictionary representation of the object.

        .. versionadded:: 1.0.0
        """
        return {
            "name": self.name,
            "description": self.description,
            "backend": self.capture_backend,
            "status": self.status,
            "active_job": self.active_job,
        }

    def _job_update_captured(self) -> None:
        """Update the captured data of the active job.

        .. versionadded:: 1.0.0
        """
        while self.active_job:
            self.active_job.captured = self.capture_source.captured
            self.update_info()
            sleep(1)

    def _job_restriction_reached(self) -> Optional[str]:
        """Callback for when the capture restrictions are reached.
            Update the job with info about reached restriction.

        Returns:
            Optional[str]: Error message if there is no active job.

        .. versionadded:: 1.0.0
        .. versionchanged:: 1.0.1
            Stop capture when restrictions are reached. Don't wait for hive.

        """
        if self.active_job is None:
            self.log("No active job to stop.", error=True)
            return "No active job"

        self.capture_source.stop_capture()

        self.active_job.captured = self.capture_source.captured
        if self.capture_source.dma_overflow:
            status_msg = "Filter expression overloads the metering point"
        elif self.active_job.captured >= self.active_job.max_capture_data:
            status_msg = "Max capture data reached."
        else:
            status_msg = "Max capture time reached."

        self.update_status(DroneStatus.WORKING)

        if self.active_job:
            self.active_job.update_status(JobStatus.CAPTURED, status_msg)
        self.update_job()
        return None

    def get_info(self) -> dict:
        """Return current status of drone.

        Returns:
            dict: A dictionary containing the current status of the drone.

        .. versionadded:: 1.0.0
        """
        info: Dict[str, Any] = {"status": self.status.value, "active_job": {}}
        if self.active_job:
            info.update({"active_job": self.active_job.to_dict()})

        return info

    def update_status(self, new_status: DroneStatus) -> None:
        """Update the status of the drone and send the update to the hive.

        Args:
            new_status (DroneStatus): The new status of the drone.

        .. versionadded:: 1.0.0
        """
        self.status = DroneStatus(new_status)
        self.update_info()

    def start_job(self, job: "Job") -> Optional[str]:
        """Start the job capture with appropriate capture backend.

        Args:
            job (Job): The job to start.

        Returns:
            Optional[str]: An error message if the job could not be started.

        .. versionadded:: 1.0.0
        """
        self.log(f"Starting job {job.id}")
        if self.active_job is not None:
            return f"Cannot start job {job.id}. Another job is running."

        self.active_job = job

        self.capture_source.cleanup()

        self.capture_source.start_capture(
            output_path=get_filepath(self.name, self.active_job.id),
            timeout=self.active_job.duration,
            max_size=self.active_job.max_capture_data,
            on_restriction_reached=self._job_restriction_reached,
            capture_filter=self.active_job.filter,
        )
        self.log(f"Capture process started - {self.capture_source.process.pid}")

        Thread(target=self._job_update_captured).start()

        self.update_status(DroneStatus.WORKING)
        self.active_job.update_status(JobStatus.IN_PROGRESS, "Capturing.")
        self.update_job()
        return None

    def stop_job(self, job_id: Optional[int] = None) -> Optional[str]:
        """Stop the job capture.

        Args:
            job_id (Optional[int]): The id of the job to stop. If None, use the
                active job.

        Returns:
            Optional[str]: An error message if the job could not be stopped.

        .. versionadded:: 1.0.0
        """
        self.log("Stopping job")
        if self.active_job is None or self.active_job.id != job_id:
            self.log("No active job to stop.", error=True)
            return f"{job_id} is not active job"

        self.log(f"Stopping job {job_id or self.active_job.id}")

        self.capture_source.stop_capture()
        self.update_status(DroneStatus.WORKING)

        if self.active_job:
            self.active_job.update_status(JobStatus.STOPPED, "Stopped by user.")
        self.update_job()

        if self.active_job:
            self.job_history.append(self.active_job)
        self.active_job = None

        return None

    def update_info(self) -> None:
        """Send current drone status to hive.

        .. versionadded:: 1.0.0
        """
        self.log(f"Updating status in hive: {self.get_info()}")
        try:
            self.sio.emit("drone_update_status", json.dumps(self.get_info()))
        except (ConnectionError, socketio.exceptions.BadNamespaceError) as err:
            self.log(f"Could not update status in hive: {str(err)}", error=True)

    def update_job(self, job_id: Optional[int] = None) -> Optional[str]:
        """Send job status to hive.

        Args:
            job_id (Optional[int]): The id of the job to update. If None use
                the active job.

        Returns:
            Optional[str]: Error message if the job could not be found.

        .. versionadded:: 1.0.0
        """
        self.log("Updating job status in hive.")
        if job_id is None:
            active_job = self.active_job
        else:
            for job in self.job_history:
                if job.id == job_id:
                    active_job = job
                    break
            else:
                self.log("Could not find job to update.", error=True)
                return f"Could not find job {job_id}"

        if active_job is None:
            self.log("No active job to update.", error=True)
            return "No active job to update."

        self.log(
            f"Updating job {active_job.id} status " f"in hive: {active_job.status}"
        )

        try:
            self.sio.emit("job_update", json.dumps(active_job.to_dict()))
        except (ConnectionError, socketio.exceptions.BadNamespaceError) as err:
            self.log(f"Could not update job status in hive: {str(err)}", error=True)

        return None


class JobStatus(str, Enum):
    """Represent all the different states that a job can have.

    .. versionadded:: 1.0.0
    """

    CAPTURED = "Captured"
    COLLECTING = "Collecting"
    FAILED = "Failed"
    IN_PROGRESS = "In progress"
    STOPPED = "Stopped"
    UNKNOWN = "Unknown"
    WAITING = "Waiting"

    @classmethod
    def _missing_(cls, _: Any) -> "JobStatus":
        return cls.UNKNOWN


class Job:
    """Represent a job.

    .. versionadded:: 1.0.0
    """

    def __init__(
        self, id: int, filter: str, duration: int, max_capture_data: int
    ):  # noqa: C0103  # pylint: disable=invalid-name
        super().__init__()

        #: The id of the job.
        self.id = id  # noqa: C0103,W0622  # pylint: disable=invalid-name
        #: The capture filter.
        self.filter = filter  # noqa: W0622
        #: The max duration of capture.
        self.duration = duration
        #: The max capture data.
        self.max_capture_data = max_capture_data

        #: Current captured data.
        self.captured = 0

        #: The current status of the job.
        self.status = JobStatus.WAITING
        #: The status message.
        self.status_msg = "Just Created."

    def to_dict(self) -> dict:
        """Return a dictionary representation of the object.

        Returns:
            dict: A dictionary representation of the object.

        .. versionadded:: 1.0.0
        """
        return {
            "id": self.id,
            "filter": self.filter,
            "duration": self.duration,
            "max_capture_data": self.max_capture_data,
            "captured": self.captured,
            "status": self.status.value,
            "status_msg": self.status_msg,
        }

    def update_status(
        self, status: JobStatus, status_msg: Optional[str] = None
    ) -> None:
        """Update status of the job.

        Args:
            status (JobStatus): The new status.
            status_msg (Optional[str]): The new status message.
                If None use empty string.

        .. versionadded:: 1.0.0
        """
        self.status = JobStatus(status)
        self.status_msg = status_msg if status_msg else ""
