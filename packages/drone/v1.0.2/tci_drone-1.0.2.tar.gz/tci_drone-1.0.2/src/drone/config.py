# -*- coding: utf-8 -*-
"""
Configuration module
====================

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Contains all the main configuration options for the TCI Drone.
"""

import argparse
import os

import toml

parser = argparse.ArgumentParser()
parser.add_argument(
    "-c", "--config", default="config", help="config name (without .toml)"
)
args = parser.parse_args()

# default toml config file path
_toml_conf_name = f"{args.config}.toml"  # pylint: disable=invalid-name
_toml_conf_paths = [
    os.path.join(os.path.dirname(os.path.dirname(__file__)), _toml_conf_name),
    os.path.join("/etc/tci/drone/", _toml_conf_name),
]

# load the config file (gets the first file that exists)
_toml_conf = {}
_used_config = None  # pylint: disable=invalid-name
for path in _toml_conf_paths:
    try:
        _toml_conf = toml.load(path)
        _used_config = path
        break
    except FileNotFoundError:
        continue

if not _toml_conf:
    print("No configuration file found in %s", _toml_conf_paths)

# set default values (empty dictionaries)
_conf = {
    "tls": _toml_conf.get("tls", {}),
    "hive": _toml_conf.get("hive", {}),
    "drone": _toml_conf.get("drone", {}),
    "tcpdump": _toml_conf.get("tcpdump", {}),
    "ndp": _toml_conf.get("ndp", {}),
    "log": _toml_conf.get("log", {}),
}


class Config:  # pylint: disable=too-few-public-methods
    """
    The base configuration options of the TCI DRONE.

    .. versionadded:: 1.0.0
    """

    __path__ = _used_config

    #: str: The url of hive.
    HIVE_URL = _conf["hive"].get("url", "http://localhost:8080/hive/v1")
    #: str: The token used for connecting to hive.
    TOKEN = _conf["hive"].get("token", "")

    CERT = _conf["tls"].get("cert", "localhost.pem")
    CA_CERT = _conf["tls"].get("ca_cert", "rootCA.crt")
    INSECURE = _conf["tls"].get("insecure", False)

    #: str: The name of the drone.
    NAME = _conf["drone"].get("name", "drone")
    #: str: The description of the drone.
    DESCRIPTION = _conf["drone"].get("description", "")
    #: str: The folder for output files.
    OUTPUT_FOLDER = _conf["drone"].get("output_folder", "../output/")
    #: str: Capture backend to use.
    CAPTURE_BACKEND = _conf["drone"].get("capture_backend", "tcpdump").lower()
    #: int: The maximum size of the captured data in bytes.
    CAPTURE_LIMIT = _conf["drone"].get("capture_limit", 0)
    #: float: Poll rate of checking the captured data
    UPDATE_CAPTURED_INTERVAL = _conf["drone"].get("update_captured_interval", 0.05)

    LOG_DIR = _conf["log"].get("directory", "/var/log/tci/drone/")
    LOG_NAME = _conf["log"].get("default_name", f"tci_drone_{NAME}.log")

    #: str: The interface to use with tcpdump.
    TCPDUMP_IFC = _conf["tcpdump"].get("ifc", "eth0")
    #: str: The path to tcpdump bin.
    TCPDUMP_BIN = _conf["tcpdump"].get("tcpdump_path", "tcpdump")

    #: str: The path to filterctl bin.
    FILTERCTL_BIN = _conf["ndp"].get("filterctl_path", "filterctl")
    #: str: The path to ndp-receive bin.
    NDP_RECEIVE_BIN = _conf["ndp"].get("ndp-receive_path", "ndp-receive")
    #: str: The path to nfb-dma bin.
    NFB_DMA_BIN = _conf["ndp"].get("nfb-dma_path", "nfb-dma")
    #: str: The path to nfb-bus bin.
    NFB_BUS_BIN = _conf["ndp"].get("nfb-bus_path", "nfb-bus")
    #: str: The card dev path.
    NDP_DEVICE = _conf["ndp"].get("device", "")
    #: int: The number of DMA the ndp device has.
    NDP_DMA_HAVE = _conf["ndp"].get("dma_have", 0)
    #: int: The number of cores the ndp device has.
    NDP_CORES = _conf["ndp"].get("cores", 2)
