# -*- coding: utf-8 -*-
"""
Endpoint Validators
===================
"""
# pylint: disable=too-few-public-methods

from typing import Optional, Union, TypeVar
from pydantic import BaseModel


class ChunkInfo(BaseModel):
    """Chunk Info Validator."""

    chunk_number: int
    job_id: int


class JobInfo(BaseModel):
    """Job Info Validator."""

    job_id: int
    filter: str
    duration: int
    max_capture_data: int
    ndp_trim_bytes: int = 0
    capture_all: bool = False
    priority: Optional[int] = 0


class JobId(BaseModel):
    """Job ID Validator."""

    job_id: int


class StopJobInfo(BaseModel):
    """Stop Job Info Validator"""

    job_id: int
    paused: Optional[bool] = False


EndpointValidator = TypeVar("EndpointValidator", bound=Union[ChunkInfo, JobInfo, JobId])
