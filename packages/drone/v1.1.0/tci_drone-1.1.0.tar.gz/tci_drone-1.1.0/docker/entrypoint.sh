#!/bin/sh

if [ "$1" = "-a" ]; then
    access_token="$(curl -u 'admin:adminpassword' -L $HIVE_URL/api/v1/token | grep '\"access_token\"' | cut -d ':' -f2 | tr -d ' ,\"')"
    TOKEN="$(curl -H "Content-Type: application/json" -H "Authorization: Bearer $access_token" -X POST $HIVE_URL/api/v1/drones -d '{"name": "drone-'$HOSTNAME'", "description": "tci drone from docker"}' | grep '\"token\"' | cut -d ':' -f2 | tr -d ' ,\"')"
fi

mkdir -p "${OUTPUT_FOLDER}"
mkdir -p "${LOG_DIR}"

mkdir -p /etc/tci/drone
touch /etc/tci/drone/config.toml
printf "[hive]\n\
url = \"${HIVE_URL}\"\n\
token = \"${TOKEN}\"\n\
[drone]\n\
output_folder = \"${OUTPUT_FOLDER}\"\n\
capture_backend = \"tcpdump\"\n\
mergecap_path = \"${MERGECAP_PATH}\"\n\
[tcpdump]\n\
ifc = \"${NETWORK_INTERFACE}\"\n\
tcpdump_path = \"${TCPDUMP_PATH}\"\n\
[log]\n\
directory = \"${LOG_DIR}\"\n\
[tls]\n\
insecure = true" > /etc/tci/drone/config.toml

python3.9 /drone/src/drone/app.py
