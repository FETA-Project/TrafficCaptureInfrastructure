# -*- coding: utf-8 -*-
"""
CaptureSource Module
====================

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

The implementation of the network capture source for the backend.
"""

import contextlib
from enum import Enum
import glob
import os
import pathlib
import shutil
import signal
import subprocess
import sys
import tempfile
from threading import Thread
from time import sleep
from typing import Any, Callable, List, Optional, Union

from config import Config
from logger import logger

def create_dirs() -> None:
    """Create necessary directories for running drone.

    .. versionadded:: 1.0.3
    """

    for directory in (Config.OUTPUT_FOLDER, Config.LOG_DIR):
        try:
            logger.info(f"Making sure folder {directory} exists.")
            os.makedirs(directory, exist_ok=True)
        except OSError as err:
            logger.error(f"Could not create folder {directory}: {str(err)}", error=True)
            sys.exit(-1)


class CaptureBackend(str, Enum):
    """The possible capture types of the drone.

    .. versionadded:: 1.0.0
    .. versionchanged:: 1.2.2
    """

    UNKNOWN = "unknown"
    TCPDUMP = "tcpdump"
    NDP = "ndp"
    NDP_DUMMY = "ndp_dummy"


    @classmethod
    def _missing_(cls, _: Any) -> "CaptureBackend":
        return cls.UNKNOWN


def init_capture_source(
    drone_name: str,
    capture_backend: CaptureBackend,
    *args
):
    """Initialize the capture source.

    Args:
        drone_name (str): The name of the drone.
        capture_backend (CaptureBackend): The type of the capture backend.
        **args: Additional arguments if needed.

    Returns:
        CaptureSource: The initialized capture source.

    .. versionadded:: 1.2.2
    """
    if capture_backend == CaptureBackend.TCPDUMP:
        return TCPDump(drone_name=drone_name)
    elif capture_backend == CaptureBackend.NDP:
        return NDP(drone_name=drone_name)
    elif capture_backend == CaptureBackend.NDP_DUMMY:
        return NDP(drone_name=drone_name, dummy_mode=True)
    else:
        raise ValueError(f"Invalid capture backend {capture_backend}")


class CaptureSource:
    """The base class for all capture sources.

    .. versionadded:: 1.0.0
    """

    def __init__(self, drone_name: str, ndp_dummy: bool = False) -> None:
        #: The capture process in os.
        self.process: Optional[subprocess.Popen[Any]] = None
        #: The path to captured pcap file.
        self.pcap_path: Optional[os.PathLike[str]] = None
        #: The captured data.
        self.captured: int = 0
        #: Flag showing if the process should stop.
        self._stop: bool = False
        #: Flag showing if there is dma overflow.
        self.dma_overflow: bool = False
        #: The name of the drone that uses this capture source.
        self._drone_name: str = drone_name
        self._ndp_dummy: bool = ndp_dummy
        self._ndp_dummy_dma: int = 4

    def _process_update_captured(
        self,
        poll: int,
        output_path: str,
        max_size: int,
        on_restriction_reached: Callable,
        check_dma_overflow: Optional[Callable] = None,
        ndp_capture_all: bool = False,
    ) -> None:
        """Update the information about capture process.

        Args:
            poll (int): Time to wait until the next update.
            output_path (str): Path to output file.
            max_size (int): Max size of capture.
            on_restriction_reached (Callable): Function to be called
                when restriction (maximum captured data/size of file) is reached.
            check_dma_overflow (Optional[Callable]): Function for checking
                dma overflow.

        .. versionadded:: 1.0.0
        .. versionchanged:: 1.0.1
            Set max_size to Config.CAPTURE_LIMIT before the loop.
            Fix check_dma_overflow() check.
            on_restriction_reached is not mandatory.
        .. versionchanged:: 1.1.0
            Add parametr for capturing on all dma channels
            (so it can calculate capture size)
        .. versionchanged:: 1.1.1
        """
        logger.debug("Starting update thread")

        if 0 < Config.CAPTURE_LIMIT < max_size:
            max_size = Config.CAPTURE_LIMIT

        while not self._stop:
            try:
                self.captured = self.get_file_size(
                    output_path, ndp_capture_all,
                    self._ndp_dummy, self._ndp_dummy_dma
                )

                if 0 < max_size <= self.captured:
                    if self.process is not None:
                        self.process.send_signal(signal.SIGTERM)
                        self.process.wait()
                    self._stop = True

                if check_dma_overflow is not None and check_dma_overflow():
                    if self.process is not None:
                        self.process.send_signal(signal.SIGTERM)
                        self.process.wait()
                    self._stop = True
                    self.dma_overflow = True
            except OSError:
                pass
            sleep(poll)

        self.captured = self.get_file_size(
            output_path, ndp_capture_all,
            self._ndp_dummy, self._ndp_dummy_dma
        )
        self._stop = False
        on_restriction_reached()

    def _process_timeout(self, timeout: int, on_timeout: Optional[Callable]) -> None:
        """Stop process after timeout.

        Args:
            timeout (int): Time to wait until stopping the process.
            on_timeout (Optional[Callable]): Function to call on timeout.

        .. versionadded:: 1.0.0
        """
        try:
            if self.process is not None:
                self.process.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            if self.process is not None:
                self.process.send_signal(signal.SIGTERM)
                self.process.wait()
            self._stop = True
            if on_timeout:
                on_timeout()

    def log(self, msg: str, capture_backend: str) -> None:
        """Log the message.

        Args:
            msg (str): Message to log.
            capture_backend (str): Capture backend.

        .. versionadded:: 1.0.0
        """
        logger.info("%s - %s - %s", self._drone_name, capture_backend, msg)

    def cleanup(self) -> None:
        """Clean the CaptureSource

        .. versionadded:: 1.0.0
        """
        self.process = None
        self.pcap_path = None
        self.captured = 0
        self._stop = False
        self.dma_overflow = False

    def create_process(
        self,
        command: List[str],
        output_path: Union[str, os.PathLike[str]],
        on_restriction_reached: Callable,
        timeout: Optional[int] = 0,
        max_size: Optional[int] = 0,
        check_dma_overflow: Optional[Callable] = None,
        ndp_capture_all: Optional[bool] = False,
    ) -> None:
        """Create the capture process in the OS.

        Args:
            command (List[str]): Command to run in the process.
            output_path (str): Path to output file.
            timeout (Optional[int]): The timeout of the process in seconds.
            on_restriction_reached (Callable): Function to be called
                when restriction is reached.
            max_size (int): Max size of capture.
            check_dma_overflow (Optional[Callable]): Function for checking
                dma overflow.

        .. versionadded:: 1.0.0
        .. versionchanged:: 1.0.1
        .. versionchanged:: 1.1.0
        .. versionchanged:: 1.1.1

        .. todo:: Use check_dma_overflow. See todo in NDP.
        """
        # pylint: disable=unused-argument,consider-using-with

        self.dma_overflow = False

        # create empty output file
        create_dirs()
        with open(output_path, "w", encoding="utf8"):
            pass

        self.pcap_path = output_path

        self.process = subprocess.Popen(
            command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        Thread(
            target=self._process_update_captured,
            args=(
                Config.UPDATE_CAPTURED_INTERVAL,
                output_path,
                max_size,
                on_restriction_reached,
                check_dma_overflow,
                ndp_capture_all,
            ),
        ).start()

        if timeout is not None and timeout > 0:
            Thread(
                target=self._process_timeout, args=(timeout, on_restriction_reached)
            ).start()

    def collect_capture(self, ndp_capture_all: bool = False) -> None:
        """Collect the capture. Merge all necesarry files

        Args:
            ndp_capture_all (bool): Collect files that were created on all DMA channels.

        .. versionadded:: 1.1.1
        """

        if ndp_capture_all:
            if self._ndp_dummy:
                os.rename(self.pcap_path, f"{self.pcap_path}.0")
                for i in range(1, 4):
                    shutil.copy(f"{self.pcap_path}.0", f"{self.pcap_path}.{i}")
            all_files = self.get_all_files(self.pcap_path)
            self.merge_files(all_files, self.pcap_path)

        self.merge_paused()


    @staticmethod
    def get_exec_path(path: str) -> str:
        """Check whether the given path can be used.

        Args:
            path: The path to the desired executable, eg. "tcpdump" or
                "/usr/bin/tcpdump".

        Returns:
            str: The real path to the executable.

        Raises:
            OSError: when the path to the executable can't be found.
            PermissionError: when there are insufficient permissions to execute
                the file.

        .. versionadded:: 1.0.0
        """
        # Get the real path of the executable
        # (eg. "tcpdump" -> "/usr/bin/tcpdump").
        # This is equivalent to running "which" in the shell.
        real_path = shutil.which(path)
        # Check if the executable can be found
        if real_path is None:
            raise OSError(f'The executable "{path}" could not be found.')
        # Check if we have privileges to execute it
        if not os.access(real_path, os.X_OK):
            raise PermissionError(f'Insufficient permissions to execute "{real_path}".')
        return real_path

    def merge_paused(self) -> None:
        """Merge pcap files for paused job.

        .. versionadded:: 1.1.0
        .. versionchanged:: 1.1.1
        """
        logger.info("Merging paused (output path: %s)", self.pcap_path)

        if not pathlib.Path(self.pcap_path).is_file():
            return

        files = [self.pcap_path] + glob.glob(f"{self.pcap_path}.paused")
        CaptureSource.merge_files(files, self.pcap_path)

    @staticmethod
    def get_all_files(path) -> list[str]:
        """Get all files matching a pattern.

        Args:
            path (str): Path to a file.

        Returns:
            list[str]: List of file paths matching the pattern.

        .. versionadded:: 1.1.0
        .. versionchanged:: 1.1.1
        """

        return glob.glob(f"{path}.[0-9]*")

    @staticmethod
    def merge_files(file_list: List[str], out_path: str) -> None:
        """
        Merge multiple pcaps of a specific job into one.

        Args:
            file_list (List[str]): List of files to merge.
            out_path (str): Output path.

        Raises:
            ValueError: When the process did finish with non-zero return code.

        .. versionadded:: 1.1.0
        .. versionchanged:: 1.1.1
        .. versionchanged:: 1.1.2
        """

        logger.info(f"Merging files [{','.join(file_list)}]")

        if len(file_list) == 0:
            return
        elif len(file_list) == 1:
            if not pathlib.Path(file_list[0]).is_file():
                return
            os.rename(file_list[0], out_path)
            return

        temp_file = out_path + tempfile._get_candidate_names().characters
        args = [Config.MERGECAP_BIN, "-w", temp_file]
        args.extend(file_list)

        with subprocess.Popen(
            args,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        ) as process:
            res = process.communicate()
            process.wait()

            if process.returncode != 0:
                raise ValueError(res[1].decode("utf-8"))  # STDERR

        for file in file_list:
            with contextlib.suppress(FileNotFoundError, TypeError):
                os.remove(file)

        os.rename(temp_file, out_path)

    @staticmethod
    def get_file_size(
        path: Union[str, os.PathLike[str]], ndp_capture_all: bool = False,
        ndp_dummy: bool = False, ndp_dummy_dma: int = 4,
    ) -> int:
        """Get the size of a file.

        Args:
            path (os.Pathlike[str]): Path to a file.

        Returns:
            int: The size of the file.

        Raises:
            OSError: When the path is not a file.

        .. versionadded:: 1.0.0
        .. versionchanged:: 1.1.0
            Add support for NDP capture on all channels.
        .. versionchanged:: 1.1.1
        """
        size = 0

        if ndp_dummy:
            files = [path]
        else:
            files = CaptureSource.get_all_files(path) if ndp_capture_all else [path]
        files = files + glob.glob(f"{path}.paused")

        if len(files) == 0:
            raise OSError("The path is not a file.")

        for file in files:
            if os.path.isfile(file):
                size += os.stat(file).st_size

        if ndp_dummy and ndp_capture_all:
            size *= ndp_dummy_dma
        return size


# fmt: off
from .ndp import NDP  # pylint: disable=wrong-import-position  # noqa: E501,E402,F401,C0413
from .tcpdump import TCPDump  # pylint: disable=wrong-import-position  # noqa: E501,E402,F401,C0413
