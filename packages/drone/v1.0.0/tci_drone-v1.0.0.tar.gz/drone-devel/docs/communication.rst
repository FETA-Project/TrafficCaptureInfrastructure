Communication with Hive
=======================

.. note:: Will be filled when `apidocs` work.