
Capture Backends
================

This module is used for controlling network capture tools.

Config <modules/drone>


The drone supports a couple of these tools:

Network Development Platform (NDP)
----------------------------------

Used for capturing with high speed network cards.

Required utilities:
^^^^^^^^^^^^^^^^^^^

- `Network Devepoment Kit (NDK)`_
    - filterctl
    - ndp-recieve
    - nfb-dma
    - nfb-bus

TCPDump
-------

The only requirement for capturing with this backend is a working network interface.

Required utilities:
^^^^^^^^^^^^^^^^^^^

- TCPDump_

.. _Network Devepoment Kit (NDK): https://www.liberouter.org/ndk/
.. _TCPDump: http://www.tcpdump.org/