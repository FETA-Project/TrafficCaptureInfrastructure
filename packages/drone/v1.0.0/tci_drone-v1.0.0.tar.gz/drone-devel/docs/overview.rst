Drone overview
==============

Basic functionality
-------------------

Drone is a module, that runs on end devices and according to commands from the central server (Hive),
starts capturing network traffic.
The captured traffic is then sent to the Hive for processing.


Drone Status state diagram
-------------------------

.. graphviz::
    :caption: DroneStatus state diagram.

    digraph StateDiagram {
        node [style=filled];
        Created [shape=Mdiamond];

        Created -> Pending [label=" The drone was created,\n waiting for first connection."];
        Pending -> Sleeping [label=" The drone connected and\n is waiting for commands."];

        Sleeping -> Working [label=" A new capture\n command was issued."];
        Sleeping -> Disconnected [label=" Unable to communicate\n with the drone."];
        Sleeping -> Error [label=" Error on the side\n of the drone."];

        Working -> Sleeping [label=" Capture command\n finished, waiting."];
        Working -> Disconnected [label=" Unable to communicate\n with the drone."];
        Working -> Error [label=" Error on the side\n of the drone."];

        Disconnected -> Sleeping [label=" Drone reconnected,\n sleeping."];
        Disconnected -> Error [label=" Drone reconnected,\n but raised an error."];
    }
