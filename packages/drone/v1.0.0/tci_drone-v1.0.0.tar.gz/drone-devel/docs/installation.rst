Installation
============

For installation you can use the RPMs we provide or build it from source.

Using the generated RPMs
-------------------------

.. note::
    Will be filled in when we generate RPMs.

Building from source
----------------------

For building from source you need to have `python3.9` installed.
Needed python packages are located in `requirements.txt` file.
You can install them by using `pip3 install -r requirements.txt` command.

For configuration you can copy the `config.toml.example`
to `/etc/tci_drone/config.toml` and edit it.

You can run the application by using `python3 ./src/drone/app.py`.

The whole installation could be as follows:

.. code-block:: bash

    python3 -m venv venv
    venv/bin/pip3 install -r requirements/run.txt
    cp config.toml.example /etc/tci_drone/config.toml
    # edit /etc/tci_drone/config.toml
    venv/bin/python3 src/drone/app.py

Example config file `config.toml`:

.. literalinclude:: ../src/config.toml.example
   :language: toml


Running as a system service
---------------------------

.. note::
    Will be filled in when we generate RPMs.

Example systemd service file `tci_drone.service`:

.. literalinclude:: ../src/tci_drone.service
   :language: ini