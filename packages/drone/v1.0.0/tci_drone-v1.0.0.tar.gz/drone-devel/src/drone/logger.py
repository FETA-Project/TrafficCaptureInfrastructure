# -*- coding: utf-8 -*-
"""
Logger module
=============

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Logging configuration for the TCI Drone.
"""

import logging
import sys
from typing import Any, List

_file_handler = logging.FileHandler(filename="../../drone.log")
_stdout_handler = logging.StreamHandler(stream=sys.stdout)
_handlers: List[Any] = [_file_handler, _stdout_handler]

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s - %(message)s",
    handlers=_handlers,
)

logger = logging.getLogger()
