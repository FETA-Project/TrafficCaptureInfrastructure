# -*- coding: utf-8 -*-
"""
Endpoint Validators
===================
"""
# pylint: disable=too-few-public-methods

from typing import Union, TypeVar
from pydantic import BaseModel


class ChunkInfo(BaseModel):
    """Chunk Info Validator."""

    chunk_number: int
    job_id: int


class JobInfo(BaseModel):
    """Job Info Validator."""

    id: int
    filter: str
    duration: int
    max_capture_data: int


class JobId(BaseModel):
    """Job ID Validator."""

    job_id: int


EndpointValidator = TypeVar("EndpointValidator", bound=Union[ChunkInfo, JobInfo, JobId])
