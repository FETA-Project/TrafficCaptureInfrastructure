# -*- coding: utf-8 -*-
"""
NDP capture source
==================

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>
"""

import signal
import subprocess
from typing import Callable, List, Optional, Tuple

from config import Config
from logger import logger

from . import CaptureSource

# .. warning:: These constants are from legacy code.
#             Not sure about their functionality.
NDP_DEFAULT_DMA_ID = 0
NDP_TS_PARAMETER = "header:32"
NDP_OVERFLOW_THRESHOLD = 0.90  # % of modulus (bitmask size + 1 from ndp-dma) value
NDP_WATCHER_SLEEP = Config.UPDATE_CAPTURED_INTERVAL  # seconds
NDP_OVERFLOW_TIME_THRESHOLD = 5  # seconds
NDP_MAX_SAMPLE_CNT = int(NDP_OVERFLOW_TIME_THRESHOLD / NDP_WATCHER_SLEEP)


class NDP(CaptureSource):
    """NDP Capture Source
    .. todo:: support for extra job options: no_dma_check, sample, discard
    .. warning: This class is not tested yet. Some legacy code is used.

    .. versionadded:: 1.0.0
    """

    def __init__(
        self,
        drone_name: str,
        device: str,
        dma_have: int,
        cores: int,
    ):
        super().__init__(drone_name=drone_name)

        #: The path to the NDP device.
        self.__device = device
        #: Number of dma the device has.
        self.__dma_have = dma_have
        #: Number of cores the device has.
        self.__cores = cores

        #: Legacy variable, not sure about its functionality.
        self._ptr_diff_samples: List[int] = []

    def _create_filter_file(self, capture_filter: Optional[str]) -> str:
        """Create a filter file from capture filter.

        Args:
            capture_filter (str): The capture filter.

        Returns:
            str: Path to the created capture file.

        .. versionadded:: 1.0.0
        """
        self.log("Creating filter file...")

        full_filter = f"default allow 1-{self.__dma_have - 1}\n"
        if capture_filter is not None:
            full_filter += f"if {capture_filter} then allow {NDP_DEFAULT_DMA_ID}\n"

        filter_file = "filter.txt"
        with open(filter_file, "w", encoding="utf-8") as file:
            file.write(full_filter)
        return filter_file

    def _set_filter(self, core_id: str, capture_filter: Optional[str]) -> None:
        """Set filter on the device core.

        Args:
            core_id (str): The core id to set the filter on.
            capture_filter (str): The capture filter.

        .. versionadded:: 1.0.0
        """

        self.log(f"Setting filter on core {core_id}...")

        filter_file = self._create_filter_file(capture_filter)

        args = [
            Config.FILTERCTL_BIN,
            "-d",
            self.__device,
            "-c",
            core_id,
            "-F",
            filter_file,
        ]

        with subprocess.Popen(
            args,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        ) as process:
            process.communicate()

            if (
                self.process is not None
                and process.returncode is not None
                and process.returncode != 0
            ):
                stderr: bytes = process.stderr.read()  # type: ignore
                raise RuntimeError(f"Failed running tcpdump: {stderr.decode('utf-8')}")

        process.communicate()

    def log(self, msg: str, capture_backend: str = "NDP") -> None:
        """Log a message.

        Args:
            msg (str): The message to log.
            capture_backend (str): The name of the backend to be used for capture.
                Defaults to "NDP".

        .. versionadded:: 1.0.0
        """
        super().log(msg, capture_backend)

    def start_capture(
        self,
        output_path: str,
        timeout: int = 0,
        max_size: int = 0,
        on_restriction_reached: Optional[Callable] = None,
        capture_filter: Optional[str] = None,
    ) -> None:
        """Start the capture process in the OS.

        Args:
            output_path (str): Path to output file.
            timeout (int): Max time of capture.
            max_size (int): Max size of capture.
            on_restriction_reached (Optional[Callable]): Function to be called
                when restriction is reached.
            capture_filter (Optional[str]): The HANIC filter used for capturing.

        .. versionadded:: 1.0.0

        .. todo:: Support for extra job options: no_dma_check, discard.
                  no_dma_check(), nfb_set_discard()
        """
        self.log(f"Starting capture (path: {output_path})...")

        for core_id in range(self.__cores):
            self._set_filter(str(core_id), capture_filter=capture_filter)

        args = [
            Config.NDP_RECIEVE_BIN,
            "-d",
            self.__device,
            "-i",
            str(NDP_DEFAULT_DMA_ID),
            "-f",
            output_path,
            "-t",
            NDP_TS_PARAMETER,
        ]

        self.log("Creating process...")
        # Executing the command
        self.create_process(
            args,
            output_path=output_path,
            timeout=timeout,
            max_size=max_size,
            on_restriction_reached=on_restriction_reached,
            check_dma_overflow=self.check_dma_overflow,
        )

        if (
            self.process is not None
            and self.process.returncode is not None
            and self.process.returncode != 0
        ):
            stderr: bytes = self.process.stderr.read()  # type: ignore
            raise RuntimeError(f"Failed running ndp-recieve: {stderr.decode('utf-8')}")

    def stop_capture(self) -> None:
        """Stop the capture process.

        .. versionadded:: 1.0.0
        """
        self.log("Terminating the process")
        if self.process is not None:
            self.process.send_signal(signal.SIGINT)
        self._stop = True

    def _nfb_read_dma_stats(self) -> Tuple[bool, str]:
        """
        Read DMA channel stats.

        .. versionadded:: 1.0.0
        """
        self.log("Reading DMA channel stats...")

        args = [
            Config.NFB_DMA_BIN,
            "-d",
            self.__device,
            "-i",
            str(NDP_DEFAULT_DMA_ID),
            "-v",
            "-r",
        ]

        with subprocess.Popen(
            args,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        ) as process:
            result = process.communicate()

            ret = process.returncode == 0  # True if success
            stats = (
                result[0].decode("utf8") if ret else result[1].decode("utf8")
            )  # STDOUT or STDERR

        return ret, stats

    def check_dma_overflow(self) -> bool:
        """
        Check if DMA channel is overwhelmed.

        Returns:
            True if overwhelmed.

        .. warning:: This is a legacy function.
            Not sure about its functionality.
        .. versionadded:: 1.0.0
        """
        self.log("Checking if DMA channel is overwhelmed...")

        ret, stats = self._nfb_read_dma_stats()

        if ret:
            lines = stats.split("\n")
            try:
                sw_ptr = int(lines[3].split(":")[1], 16)
                hw_ptr = int(lines[4].split(":")[1], 16)
                mod = int(lines[5].split(":")[1], 16) + 1
                ptr_diff = hw_ptr - sw_ptr
                if ptr_diff < 0:
                    ptr_diff += mod
            except ValueError as err:
                logger.error(
                    "Unable to check if filter overloads the DMA - "
                    "unable to parse value %s",
                    err,
                )
                return False

            self._ptr_diff_samples.append(ptr_diff)
            sample_cnt = len(self._ptr_diff_samples)
            excessive_elem_cnt = sample_cnt - NDP_MAX_SAMPLE_CNT
            if excessive_elem_cnt > 0:
                # Remove older samples
                del self._ptr_diff_samples[0:excessive_elem_cnt]
                sample_cnt = len(self._ptr_diff_samples)

            avg = sum(self._ptr_diff_samples) / sample_cnt
            if sample_cnt >= NDP_MAX_SAMPLE_CNT and avg >= mod * NDP_OVERFLOW_THRESHOLD:
                return True
        else:
            logger.error(
                "Unable to check if filter overloads the dma"
                " - execution of nfb-dma command failed"
            )
            return False
        return False
