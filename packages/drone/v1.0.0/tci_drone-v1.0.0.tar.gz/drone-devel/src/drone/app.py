# -*- coding: utf-8 -*-
"""
TCI Drone Module
================

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

The main entry point for the TCI Drone.
"""

import signal
import sys
from time import sleep
from types import FrameType
from typing import Optional

import socketio
from config import Config
from logger import logger
from models import Drone

drone = Drone(
    name=Config.NAME,
    description=Config.DESCRIPTION,
    capture_backend=Config.CAPTURE_BACKEND,
)

sio = drone.sio

from endpoints import *  # pylint: disable=wildcard-import,wrong-import-position  # noqa: E501,E402,F403


def graceful_shutdown(signal_id: int, _: Optional[FrameType]) -> None:
    """Gracefully shutdown the drone.

    .. versionadded:: 1.0.0
    """
    drone.log(f"\rCaught signal {signal.Signals(signal_id).name}, shutting down.")
    sio.disconnect()
    sys.exit(0)


if __name__ == "__main__":
    signal.signal(signal.SIGINT, graceful_shutdown)
    signal.signal(signal.SIGTERM, graceful_shutdown)

    logger.debug(drone.to_dict())
    while True:
        try:
            sio.connect("http://localhost:8080/hive/v1", auth={"token": Config.TOKEN})
            sio.wait()
        except socketio.exceptions.ConnectionError:
            sleep(1)
