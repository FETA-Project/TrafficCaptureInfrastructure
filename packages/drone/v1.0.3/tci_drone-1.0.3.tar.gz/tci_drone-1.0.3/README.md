# TCI - Drone

---

A drone for the Traffic Capture Infrastructure system.

Sole purpose of a drone is to capture network traffic with a specified filter
and send the data back to hive, that controls it.

## Capture Backend

Drone can use couple of tools, that do the capturing.

### TCPDump

The simplest capturing.
Select the appropriate network interface in `config.toml`

#### Required Tools

* [tcpdump](https://www.tcpdump.org/)

### NDP

Used for capturing with high speed network cards.

#### Required Tools

* [Network Development Kit](https://github.com/CESNET/ndk-sw)
  * filterctl
  * ndp-receive
  * nfb-dma
  * nfb-bus
