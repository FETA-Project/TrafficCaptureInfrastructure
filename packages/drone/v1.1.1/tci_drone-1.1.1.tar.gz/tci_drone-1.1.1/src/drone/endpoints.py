# -*- coding: utf-8 -*-
"""
Drone endpoints module
======================

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>

**Description**

Implementation of socketio endpoints for the Drone.

**Functions**

.. automethod:: drone.endpoints.connect()
.. automethod:: drone.endpoints.connect_error(data)
.. automethod:: drone.endpoints.disconnect()
.. automethod:: drone.endpoints._handle_upload_response(res, job_id)
.. automethod:: drone.endpoints.get_chunk(chunk_info)
.. automethod:: drone.endpoints.start_job(job_info)
.. automethod:: drone.endpoints.stop_job(id)
.. automethod:: drone.endpoints.delete_job(id)
"""

import json
import os
from base64 import b64encode
from http import HTTPStatus
from math import ceil
from typing import Any, Optional, Tuple

from app import drone
from logger import logger
from models import DroneStatus, Job, JobStatus, get_filepath
from validators import ChunkInfo, JobId, JobInfo, StopJobInfo

sio = drone.sio


def _handle_upload_response(res: int, job_id: int) -> None:
    """Auxiliary function to handle the response of the upload event.
        Delete the job and its files if upload was successful.

    Args:
        res (int): The response code.
        job_id (int): The job id.

    .. versionadded:: 1.0.0
    """
    if res == HTTPStatus.OK:
        file = get_filepath(drone.name, job_id)
        drone.log(f'Finished uploading file "{file}"')

        delete_job(json.dumps({"job_id": job_id}))

        if drone.active_job == job_id:
            drone.capture_source.cleanup()
            drone.active_job = None
        # drone.capture_source.cleanup()
        drone.update_status(DroneStatus.SLEEPING)


@sio.on("*")
def catch_all(event: Any, data: Any) -> None:
    """Catch all unknown events and print them.

    Args:
        event: The event name.
        data: The event data.

    .. versionadded:: 1.0.0
    """
    logger.debug("*: %s - %s", event, data)


@sio.on("connect")
def connect() -> None:
    """Init drone and update its status when connected to hive.

    .. versionadded:: 1.0.0
    """
    drone.log("Connected to hive and updating drone status.")

    sio.emit("drone_init", json.dumps({"capture_backend": drone.capture_backend.value}))

    drone.update_status(
        DroneStatus.WORKING if drone.active_job else DroneStatus.SLEEPING
    )


@sio.on("connect_error")
def connect_error(data: Any) -> None:
    """Handle connection error.

    Args:
        data: The error data.

    .. versionadded:: 1.0.0
    """
    drone.log(f'The connection to hive failed "{data}", retrying...')
    drone.status = DroneStatus.ERROR


@sio.on("disconnect")
def disconnect() -> None:
    """Set status to disconnected when disconnected from hive.

    .. versionadded:: 1.0.0
    """
    drone.log("Disconnected from hive.")
    drone.status = DroneStatus.DISCONNECTED


@sio.on("update_info")
def update_info() -> None:
    """
    Update drone info to hive.

    .. versionadded:: 1.0.0
    """
    drone.log("Updating drone info to hive.")
    drone.update_info()


@sio.on("get_chunk")
@sio.parse(ChunkInfo)
def get_chunk(data: ChunkInfo) -> None:
    """
    Get a chunk of a file and upload it to hive.

    ** Example data: **

    .. code-block:: json

        {
            "chunk_number": 1,
            "job_id": 24,
        }

    Args:
        data: The information about specific chuck of a file.

    .. versionadded:: 1.0.0
    .. versionchanged:: 1.1.1
        Account for new job status.
        Remove active job when started uploading.
    """
    # 1 MB of data
    chunk_size = 700_000

    drone.log(f"Get chunk: {data}")

    if data.chunk_number <= 0:
        raise ValueError("Chunk number must be greater than 0.")

    file: str = get_filepath(drone.name, data.job_id)
    if (
        not os.path.isfile(file)
        and data.chunk_number == 1
        and drone.capture_source.captured == 0
    ):
        with open(file, "w", encoding="utf-8") as out_file:
            out_file.write("")

    file_size = os.stat(file).st_size
    total_number_of_chunks = (
        1 if file_size <= chunk_size else ceil(file_size / chunk_size)
    )

    if data.chunk_number == 1:
        drone.log(f'Started uploading file "{file}"')
        # FIXME: this is a hack to stop multiple uploads  # pylint: disable=fixme
        if drone.active_job and drone.active_job.id == data.job_id:
            drone.job_history.append(drone.active_job)
            drone.active_job = None

        for job in drone.job_history:
            if job.id == data.job_id:
                if job.status == JobStatus.UPLOADING:
                    drone.log(f"Job {data.job_id} is already uploading.")
                    return
                elif job.status == JobStatus.COLLECTING:
                    drone.log(f"Job {data.job_id} is still collecting cannot start upload.")
                    return
                job.status = JobStatus.UPLOADING
                break

    with open(file, "rb") as in_file:
        in_file.seek((data.chunk_number - 1) * chunk_size)
        chunk_bytes = in_file.read(chunk_size)

    sio.emit(
        "upload",
        json.dumps(
            {
                "chunk_number": data.chunk_number,
                "chunk_bytes": b64encode(chunk_bytes).decode("utf-8"),
                "job_id": data.job_id,
                "total_number_of_chunks": total_number_of_chunks,
            }
        ),
        # callback=lambda res, job_id: _handle_upload_response(res, job_id),
        callback=_handle_upload_response,
    )


@sio.on("start_job")
@sio.parse(JobInfo)
def start_job(data: JobInfo) -> Optional[Tuple[int, str]]:
    """Start a job.

    ** Example data: **

    .. code-block:: json

        {
            "id": 1,
            "filter": "port 80",
            "duration": 600,
            "max_capture_data": 1000000
        }

    Args:
        data: A dictionary containing necessary information about
            job capture.

    Returns:
        Optional[str]: A string containing an error message if the job failed
            to start.

    .. versionadded:: 1.0.0
    .. versionchanged:: 1.1.0
        Add parameters for NDP capture.
    .. versionchanged:: 1.1.1
    """
    drone.log(f"start_job from hive: {data.dict()}")
    if drone.active_job is not None and data.job_id == drone.active_job.id:
        return None

    CRITICAL = -99
    if data.priority == CRITICAL and drone.active_job is not None:
        drone.active_job.update_status(JobStatus.PAUSED, "Paused by critical job.")
        drone.stop_job(drone.active_job.id, paused=True)

    job = Job(
        id=data.job_id,
        filter=data.filter,
        duration=data.duration,
        max_capture_data=data.max_capture_data,
        ndp_trim_bytes=data.ndp_trim_bytes,
        ndp_capture_all=data.ndp_capture_all,
    )
    for history_job in drone.job_history:
        if history_job.id == job.id:
            drone.job_history.remove(history_job)

    drone.log(f"Creating job: {job.to_dict()}")

    ret = drone.start_job(job)
    if ret:
        logger.error(ret)
        return 400, ret

    return None


@sio.on("stop_job")
@sio.parse(StopJobInfo)
def stop_job(data: StopJobInfo) -> Optional[Tuple[int, str]]:
    """Stop a job.

    Args:
        data: The id of the job to stop.

    .. versionadded:: 1.0.0
    .. versionchanged:: 1.1.0
        Add support for pausing job from hive.
    .. versionchanged:: 1.1.1
        Don't stop a job if it's paused/stopped/collecting/uploading.
    """
    drone.log(f"Stopping job {data.job_id}")
    if not drone.active_job or drone.active_job.id != data.job_id:
        logger.error("%s - stop_job - job %s is not running.", drone.name, data.job_id)
        return 400, f"Job {data.job_id} is not running."

    drone.log(f"Active job status: {drone.active_job.status}")
    if drone.active_job.status in (JobStatus.PAUSED, JobStatus.STOPPED, JobStatus.COLLECTING, JobStatus.UPLOADING):
        return 400, f"Job {data.job_id} is not running."

    drone.stop_job(data.job_id, data.paused)

    return None


@sio.on("pause_job")
@sio.parse(JobId)
def pause_job(data: JobId) -> Optional[Tuple[int, str]]:
    """Pause a job

    Stop a job and move caputured file to *.paused, so that it can be resumed later.

    Args:
        data: The id of the job to pause.

    .. versionadded:: 1.1.0
    """
    drone.log(f"Pausing job {data.job_id}")
    stop_job(json.dumps({"job_id": data.job_id, "paused": True}))
    filepath = get_filepath(drone.name, data.job_id)
    try:
        os.rename(filepath, f"{filepath}.paused")
    except OSError as exc:
        logger.error(
            "%s - pause_job - job %s cannot be renamed", drone.name, data.job_id
        )
        return exc.errno, exc.strerror

    return None


@sio.on("delete_job")
@sio.parse(JobId)
def delete_job(data: JobId) -> Optional[Tuple[int, str]]:
    """Delete a job and all its files.

    Args:
        data: The id of the job to delete.

    Returns:
        Optional[str]: A string containing an error message
            if the job is running.

    .. versionadded:: 1.0.0
    """
    if drone.active_job and drone.active_job.id == data.job_id:
        msg = f"Cannot delete job {data.job_id} while it is running."
        logger.error(msg)
        return 400, msg

    drone.log(f"Deleting job {data.job_id}")
    try:
        for job in drone.job_history:
            if job.id == data.job_id:
                drone.job_history.remove(job)
                break
        os.remove(get_filepath(drone.name, data.job_id))
    except (FileNotFoundError, TypeError):
        pass

    return None
