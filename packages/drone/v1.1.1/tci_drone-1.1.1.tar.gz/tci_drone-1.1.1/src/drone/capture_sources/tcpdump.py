# -*- coding: utf-8 -*-
"""
TCPDUMP capture source
======================

**Authors**

- Lukáš Hejcman <hejcman@cesnet.cz>

- David Beneš <benesdavid@cesnet.cz>
"""

import signal
from typing import Callable, Optional

from config import Config
from logger import logger

from . import CaptureSource


class TCPDump(CaptureSource):
    """TCPDump Capture Source.

    .. versionadded:: 1.0.0
    """

    def __init__(self, drone_name: str, interface: str = "eth0"):
        super().__init__(drone_name=drone_name)

        #: str: The path to the ``tcpdump`` executable.
        self.__tcpdump_path: str = self.get_exec_path(Config.TCPDUMP_BIN)
        #: str: The name of the network interface.
        self.__interface = interface

    def log(self, msg: str, capture_backend: str = "TCPDump") -> None:
        """Log the message.

        Args:
            msg (str): Message to log.

        .. versionadded:: 1.0.0
        """
        super().log(msg, capture_backend)

    def start_capture(
        self,
        output_path: str,
        on_restriction_reached: Callable,
        timeout: int = 0,
        max_size: int = 0,
        capture_filter: Optional[str] = None,
    ) -> None:
        """Start the capture process in the OS.

        Args:
            output_path (str): Path to output file.
            timeout (int): Max time of capture.
            max_size (int): Max size of capture.
            on_restriction_reached (Callable): Function to be called
                when restriction is reached.
            capture_filter (Optional[str]): The capture filter.

        .. versionadded:: 1.0.0
        .. versionchanged:: 1.0.1
        """
        self.log(f"Starting capture (output_path: {output_path})")
        # Preparing the command
        args = [self.__tcpdump_path, "-i", self.__interface, "-w", output_path]
        if capture_filter is not None:
            args.append(capture_filter)

        self.log("Creating a process...")
        # Executing the command
        self.create_process(
            args,
            output_path=output_path,
            timeout=timeout,
            max_size=max_size,
            on_restriction_reached=on_restriction_reached,
        )

        logger.debug("Communicating with the process")

        if (
            self.process is not None
            and self.process.returncode is not None
            and self.process.returncode != 0
        ):
            stderr: bytes = self.process.stderr.read()  # type: ignore
            raise RuntimeError(f"Failed running tcpdump: {stderr.decode('utf-8')}")

    def stop_capture(self) -> None:
        """Stop the capture process.

        .. versionadded:: 1.0.0
        .. versionchanged:: 1.1.0
            Merge files if the capture was paused.
        .. versionchanged:: 1.1.1
            Remove merging files (added to collect_capture()).
        """
        self.log("Terminating the process")
        if self.process is not None:
            self.process.send_signal(signal.SIGINT)
        self._stop = True
